--- STEAMODDED HEADER
--- MOD_NAME: JJNMod
--- MOD_ID: JJNMod
--- MOD_AUTHOR: [JJN]
--- MOD_DESCRIPTION: The JJNMod mod
--- MOD_VERSION: 1.0.0

-- you can have shared helper functions
function shakecard(self) --visually shake a card
    G.E_MANAGER:add_event(Event({
        func = function()
            self:juice_up(0.5, 0.5)
            return true
        end
    }))
end

local msg_dictionary={
    -- do note that when using messages such as: 
    -- message = localize{type='variable',key='a_xmult',vars={current_xmult}},
    -- that the key 'a_xmult' will use provided values from vars={} in that order to replace #1#, #2# etc... in the localization file.

    a_chips="+#1#",
    a_chips_minus="-#1#",
    a_hands="+#1# Hands",
    a_handsize="+#1# Hand Size",
    a_handsize_minus="-#1# Hand Size",
    a_mult="+#1# Mult",
    a_mult_minus="-#1# Mult",
    a_remaining="#1# Remaining",
    a_sold_tally="#1#/#2# Sold",
    a_xmult="X#1# Mult",
    a_xmult_minus="-X#1# Mult",
}    

local mod_name = 'JJNMod' -- Put your mod name here!

local jokers = {
    first_card = {
        name = "first_card",
        text = {
            "Retrigger",
            "each played",
            "{C:attention}Jack{}, {C:attention}Queen{}, {C:attention}King{}, or {C:attention}Ace{} 4 times",
        },
        config = { repetitions = 4 },
        pos = { x = 0, y = 0 },
        rarity = 1,
        cost = 2,
        blueprint_compat = true,
        eternal_compat = false,
        unlocked = true,
        discovered = true,
        negative = true,
        effect = nil,
        atlas = nil,
        soul_pos = nil,

        calculate = function(self, context)
            if self.debuff then return nil end
            if context.cardarea == G.play and context.repetition and (
                context.other_card:get_id() == 11 or 
                context.other_card:get_id() == 12 or 
                context.other_card:get_id() == 13 or 
                context.other_card:get_id() == 14) then
                return {
                    message = localize('k_again_ex'),
                    repetitions = self.ability.repetitions,
                    card = self
                }
            end
        end,

        loc_def = function(self)
            return { }
        end
    },
    second_card = {
    name = "second_card",
    text = {
            "This Joker gives {X:mult,C:white} X#1# {} Mult",
            "for each time you've played this {C:attention}hand",
        },
        config = { extra = { x_mult = 0.5 } },
        pos = { x = 0, y = 0 },
        rarity = 1,
        cost = 1,
        blueprint_compat = true,
        eternal_compat = true,
        unlocked = true,
        discovered = true,
        negative = true,
        effect = nil,
        atlas = nil,
        soul_pos = nil,

        calculate = function(self, context)
            if self.debuff then return nil end
            if context.joker_main and context.cardarea == G.jokers and context.scoring_name then
                local current_hand_times = (G.GAME.hands[context.scoring_name].played or 0) -- how many times has the player played the current type of hand. (pair, two pair. etc..)
                local current_xmult = 1 + (current_hand_times * self.ability.extra.x_mult)
                
                return {
                    message = localize{type='variable',key='a_xmult',vars={current_xmult}},
                    colour = G.C.RED,
                    x_mult = current_xmult
                }

                -- you could also apply it to the joker, to do it like the sample wee, but then you'd have to reset the card and text every time the previewed hand changes.
            end
        end,

        loc_def = function(self)
            return { self.ability.extra.x_mult }
        end
    },
    third_card = {
    name = "third_card",
    text = {
            "This Joker gives {X:mult,C:white} X#1# {} Mult",
            "for each time you've played this {C:attention}hand",
        },
        config = { extra = { x_mult = 1 } },
        pos = { x = 0, y = 0 },
        rarity = 3,
        cost = 3,
        blueprint_compat = true,
        eternal_compat = true,
        unlocked = true,
        discovered = true,
        effect = nil,
        atlas = nil,
        soul_pos = nil,
        
        on_create = function(self, card)
        -- Apply the negative edition trait to this card
        card:set_edition({ negative = true }, nil, true)
        end,

        calculate = function(self, context)
            if self.debuff then return nil end
            if context.joker_main and context.cardarea == G.jokers and context.scoring_name then
                local current_hand_times = (G.GAME.hands[context.scoring_name].played or 0) -- how many times has the player played the current type of hand. (pair, two pair. etc..)
                local current_xmult = 1 + (current_hand_times * self.ability.extra.x_mult)
                
                return {
                    message = localize{type='variable',key='a_xmult',vars={current_xmult}},
                    colour = G.C.RED,
                    x_mult = current_xmult
                }

                -- you could also apply it to the joker, to do it like the sample wee, but then you'd have to reset the card and text every time the previewed hand changes.
            end
        end,

        loc_def = function(self)
            return { self.ability.extra.x_mult }
        end
    },
    fourth_card = {
    name = "fourth_card",
    text = {                                             --description text. each line is a new line, try to keep to 5 lines.            
            "This Joker gains",
            "{C:chips}+#2#{} Chips when each",
            "played {C:attention}Ace{} is scored",
            "{C:inactive}(Currently {C:chips}+#1#{C:inactive} Chips)",
		},
		config = { extra = { chips = 10, chip_mod = 10 } },    --variables used for abilities and effects.
		pos = { x = 0, y = 0 },                              --pos in spritesheet 0,0 for single sprites or the first sprite in the spritesheet.
        rarity = 1,                                          --rarity 1=common, 2=uncommen, 3=rare, 4=legendary
        cost = 1,                                            --cost to buy the joker in shops.
        blueprint_compat=true,                               --does joker work with blueprint.
        eternal_compat=true,                                 --can joker be eternal.
        unlocked = true,                                     --is joker unlocked by default.
        discovered = true,                                   --is joker discovered by default.
        negative = true,    
        effect=nil,                                          --you can specify an effect here eg. 'Mult'
        soul_pos=nil,                                        --pos of a soul sprite.

        calculate = function(self,context)                   --define calculate functions here
            if self.debuff then return nil end               --if joker is debuffed return nil
            if context.individual and context.cardarea == G.play then -- if we are in card scoring phase, and we are on individual cards
                if not context.blueprint then -- blueprint/brainstorm don't get to add chips to themselves
                    if context.other_card:get_id() == 14 then -- played card is a ace by rank
                        self.ability.extra.chips = self.ability.extra.chips + self.ability.extra.chip_mod -- add configurable amount of chips to joker
                        
                        return { -- shows a message under the specified card (self) when it triggers, k_upgrade_ex is a key in the localization files of Balatro
                            extra = {focus = self, message = localize('k_upgrade_ex')},
                            card = self,
                            colour = G.C.CHIPS
                        }
                    end
                end
            end
            if context.joker_main and context.cardarea == G.jokers then
                return { -- returns total chips from joker to be used in scoring, no need to show message in joker_main phase, game does it for us.
                    chips = self.ability.extra.chips, 
                    colour = G.C.CHIPS
                }
            end
        end,

        loc_def = function(self)                              --defines variables to use in the UI. you can use #1# for example to show the chips variable
            return {self.ability.extra.chips, self.ability.extra.chip_mod}
        end
	},
}

local decks = {
    mydeck = {
	name = "my_deck",
	text = {
        "Start with 10000$ and X0.01mult",
        "the jokers blueprint, brainstorm",
        "and the custom jokers first card and fourth card"
    },  
	order = 17,
    unlocked = true,
    discovered = true,
	config = {
        dollars=10000,
        jokers = {'j_blueprint','j_brainstorm','j_fourth_card','j_first_card'},
        mult_mod = 0.01
    },
	pos = { x = 0, y = 0 },
	atlas = "mydeck",
    }
}

function SMODS.INIT.JJNMod()
    --localization for the info queue key
    G.localization.descriptions.Other["your_key"] = {
        name = "Example",
        text = {
            "TEXT L1",
            "TEXT L2",
            "TEXT L3"
        }
    }
    init_localization()

    --Create and register jokers
    for k, v in pairs(jokers) do --for every joker in 'jokers'
        local joker = SMODS.Joker:new(v.name, k, v.config, v.pos, { name = v.name, text = v.text }, v.rarity, v.cost,
        v.unlocked, v.discovered, v.blueprint_compat, v.eternal_compat, v.effect, v.atlas, v.soul_pos)
        joker:register()

        if not v.atlas then --if atlas=nil then use single sprites. In this case you have to save your sprite as slug.png (for example j_sample_wee.png)
            SMODS.Sprite:new("j_" .. k, SMODS.findModByID(mod_name).path, "j_" .. k .. ".png", 71, 95, "asset_atli")
                :register()
        end

        SMODS.Jokers[joker.slug].calculate = v.calculate
        SMODS.Jokers[joker.slug].loc_def = v.loc_def

        --if tooltip is present, add jokers tooltip
        if (v.tooltip ~= nil) then
            SMODS.Jokers[joker.slug].tooltip = v.tooltip
        end
    end

    -- Register Decks
    for k, v in pairs(decks) do
        local deck = SMODS.Deck:new(
            v.name, k, v.config, v.pos, 
            { name = v.name, text = v.text },
            v.rarity, v.unlocked, v.discovered, v.boss_relic_pool
        )
        deck:register()

        if not v.atlas then
            SMODS.Sprite:new("d_" .. k, SMODS.findModByID(mod_name).path, "d_" .. k .. ".png", 71, 95, "asset_atli")
                :register()
        end
    end


    --Create sprite atlas
    SMODS.Sprite:new("JJN", SMODS.findModByID(mod_name).path, "example.png", 71, 95, "asset_atli")
        :register()
end