println("Hello World");

craftingTable.addShapeless("grass_block", <item:minecraft:grass_block>, [<item:minecraft:wheat_seeds>, <item:minecraft:dirt>]);
craftingTable.addShaped("cobble_stone", <item:minecraft:cobble_stone>, 
[<item:minecraft:dirt>, <item:minecraft:dirt>, <item:minecraft:air>],
[<item:minecraft:dirt>, <item:minecraft:dirt>, <item:minecraft:air>],
[<item:minecraft:air>, <item:minecraft:air>, <item:minecraft:air>]
);