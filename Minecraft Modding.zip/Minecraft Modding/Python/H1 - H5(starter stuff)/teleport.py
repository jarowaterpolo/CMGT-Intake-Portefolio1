#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#gebruik van tijd
import time

#variabelen
x=10
y=100
z=10

BlockType = 20

#time pause
time.sleep(10)

#teleport
mc.player.setTilePos(x,y,z)

#block place
mc.setBlock(x,y-1,z,BlockType)
