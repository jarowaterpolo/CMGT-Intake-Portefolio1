#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()


#variabelen
x=0
y=0
z=0

#positie van speler krijgen
positie = mc.player.getTilePos()
x=positie.x
y=positie.y
z=positie.z

#positie getal aanpassing
x=x+5
y=y+10

#teleport
mc.player.setTilePos(x,y,z)


