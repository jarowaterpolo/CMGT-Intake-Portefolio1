#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#gebruik van tijd
import time

#variabelen
pos=mc.player.getPos()

x=pos.x
y=pos.y
z=pos.z

breedte=4
hoogte=4
lengte=4

BlockType = 20
lucht=0
grassBlock=2

#block place
mc.setBlocks(x-2,y-1,z-2, x+breedte,y+hoogte-1,z+lengte,lucht)
mc.setBlocks(x-2,y-1,z-2, x+breedte,y+hoogte-5,z+lengte,grassBlock)






