#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
pos=mc.player.getTilePos()
wait=time.sleep
T=True
F=False

mc.setting("spawn-monsters", F)
chat("monster are now disabled")

mc.setting("world_immutable", T)
chat("you can't change the world")
wait(2)
mc.setting("world_immutable", F)
chat("you can now change the world again")
