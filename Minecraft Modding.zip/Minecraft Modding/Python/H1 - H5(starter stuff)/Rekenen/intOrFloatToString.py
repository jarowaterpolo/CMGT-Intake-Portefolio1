#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#variabele
chat=mc.postToChat
x=20
y=25
z=16.75

#dingen zeggen in minecraft chat
chat("Hallo, Minecraft World")
chat(str(x)+str(y))
chat(str(z))


