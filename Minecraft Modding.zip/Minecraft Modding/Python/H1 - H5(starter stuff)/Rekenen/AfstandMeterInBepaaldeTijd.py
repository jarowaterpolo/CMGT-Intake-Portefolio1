#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
pos=mc.player.getTilePos()
wait=time.sleep

chat("10")
wait(1)
chat("9")
wait(1)
chat("8")
wait(1)
chat("7")
wait(1)
chat("6")
wait(1)
chat("5")
wait(1)
chat("4")
wait(1)
chat("3")
wait(1)
chat("2")
wait(1)
chat("1")
wait(1)

pos1=pos
x1=pos1.x
y1=pos1.y
z1=pos1.z
chat("x1="+str(x1)+" y1="+str(y1)+" z1="+str(z1))


wait(10)
pos=mc.player.getTilePos()

pos2=pos
x2=pos2.x
y2=pos2.y
z2=pos2.z
chat("x2="+str(x2)+" y2="+str(y2)+" z2="+str(z2))

xAfstand=x2-x1
yAfstand=y2-y1
zAfstand=z2-z1

chat("X Afstand="+str(xAfstand)+" Y Afstand="+str(yAfstand)+" Z Afstand="+str(zAfstand))





