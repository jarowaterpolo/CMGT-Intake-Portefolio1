#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#variabele
chat=mc.postToChat
i=int
ip=input

blockType=i(ip("Zet hier Bloktype: "))
pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

place=mc.setBlock

#place block
place(x,y,z, blockType)
