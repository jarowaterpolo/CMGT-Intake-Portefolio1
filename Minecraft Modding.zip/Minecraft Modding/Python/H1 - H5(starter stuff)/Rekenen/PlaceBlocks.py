#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#gebruik van tijd
import time

#variabelen
pos=mc.player.getPos()

x=pos.x
y=pos.y
z=pos.z

breedte=5
hoogte=5
lengte=5

BlockType = 20
lucht=0

#block place
mc.setBlocks(x,y,z, x+breedte,y+hoogte,z+lengte,BlockType)

time.sleep(2)

mc.setBlocks(x,y,z, x+breedte,y+hoogte,z+lengte,lucht)
