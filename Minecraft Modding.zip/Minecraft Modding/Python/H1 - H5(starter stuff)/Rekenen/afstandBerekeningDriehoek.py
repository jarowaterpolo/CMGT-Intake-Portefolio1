#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
pos=mc.player.getTilePos()
wait=time.sleep
T=True
F=False
startX=0
startZ=0

x=pos.x
y=pos.y
z=pos.z

#a²+b²=c²
#  _____
#_/a²+b² = c
afstand=round(math.sqrt((startX-x)**2 + (startZ-z)**2),0)
chat("jouw afstand tot 0,0 is nu ongeveer: "+str(afstand)+"blokken")

