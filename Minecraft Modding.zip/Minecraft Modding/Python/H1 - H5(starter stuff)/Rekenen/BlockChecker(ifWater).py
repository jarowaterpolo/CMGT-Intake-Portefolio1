#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
pos=mc.player.getTilePos()
wait=time.sleep
T=True
F=False

x=pos.x
y=pos.y
z=pos.z

BlockType=mc.getBlock(x,y,z)
chat(BlockType==0)


