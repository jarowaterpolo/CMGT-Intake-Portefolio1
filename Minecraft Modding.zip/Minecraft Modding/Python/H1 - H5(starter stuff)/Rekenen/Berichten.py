#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#variabele
chat=mc.postToChat

schrijver = input("typ hier wie dit schrijft: ")
bericht = input("typ hier een bericht: ")
chat(schrijver + ": " + bericht)
