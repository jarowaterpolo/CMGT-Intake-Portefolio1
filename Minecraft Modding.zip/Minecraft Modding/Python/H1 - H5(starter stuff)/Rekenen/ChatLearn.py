#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#variabele
chat=mc.postToChat

#dingen zeggen in minecraft chat
chat("Hallo, Minecraft World")
chat("Hoe heet jij? ")
naam = input("Hoe heet jij? ")
chat("Welcome " + naam)
print(naam)
