#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#gebruik van tijd
import time

#gebruik van random
import random

#variabelen
pos=mc.player.getPos()

x=pos.x
y=pos.y
z=pos.z

score=0

dobbelsteenWaarde=random.randint(1,6)

score += dobbelsteenWaarde

print(score)




