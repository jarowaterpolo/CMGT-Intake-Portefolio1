#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#variabele
chat=mc.postToChat
i=int
ip=input

try:
    wil=int(input("hoeveel? "))
    chat(str(wil))
except:
    print("Ongeldige Input: typ een getal")
    chat("Ongeldige Input: typ een getal")



