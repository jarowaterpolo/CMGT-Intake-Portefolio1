#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#gebruik van tijd
import time

#variabelen
pos=mc.player.getPos()

x=pos.x
y=pos.y
z=pos.z

breedte=4
hoogte=4
lengte=4

BlockType = 20
lucht=0

#block place
mc.setBlocks(x,y-1,z, x+breedte,y+hoogte-1,z+lengte,BlockType)
mc.setBlocks(x+1,y,z+1, x+breedte-1,y+hoogte-2,z+lengte-1,lucht)
mc.setBlocks(x,y,z+2, x+breedte-3,y+hoogte-3,z+lengte-2,lucht)

mc.player.setTilePos(x+2,y+1,z+2)


