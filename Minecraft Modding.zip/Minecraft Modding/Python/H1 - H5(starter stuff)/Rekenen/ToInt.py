#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()

#variabele
chat=mc.postToChat
DicePerDiceset=7


#dingen zeggen in minecraft chat
chat("Hallo, Minecraft World")

#verschillende mannieren van naar int converten
#1
#Dicesets=input("hoeveel dicesets heb je? ")
#Dicesets=int(Dicesets)
#2
Dicesets=int(input("hoeveel dicesets heb je? "))

#berekenen van hoeveelheid dice
Dice = DicePerDiceset * Dicesets

#chat van hoeveelheid dice
chat("jij hebt " + str(Dicesets) + " Dicesets en in totaal " + str(Dice) + " Dice")



