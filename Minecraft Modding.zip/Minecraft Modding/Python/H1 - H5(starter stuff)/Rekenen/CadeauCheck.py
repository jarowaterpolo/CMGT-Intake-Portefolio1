#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False

x=1
y=68
z=1

Cadeau=mc.getBlock(x,y,z)

if Cadeau==57:
    chat("Bedankt voor de supermooie diamantblok")
elif Cadeau==6:
    chat("Een jong boompje is net zo mooi als een diamant...")
else:
    chat("Plaats een Cadeau voor de server op "+ str(x) + ", "+ str(y) + ", "+ str(z) + ", ")

chat(BlockType==0)


