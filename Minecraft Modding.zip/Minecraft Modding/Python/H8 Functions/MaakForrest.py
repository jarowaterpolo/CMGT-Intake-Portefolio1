#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math
import random

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks
SPpos=mc.player.setTilePos

pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

LogBreedte=0
LogHoogte=3
LogLengte=0

LeaveBreedte=2
LeaveHoogte=3
LeaveLengte=2

count=0

Log=17
Leaves=18

J="J"
N="N"
close="close"

def maakBoom(x,y,z):
        places(x,y,z,x+LogBreedte,y+LogHoogte,z+LogLengte, Log)
        places(x-2,y+5,z-2,x+LeaveBreedte,y+LeaveHoogte,z+LeaveLengte, Leaves)

while count<= 10:
    pos=mc.player.getTilePos()
    x=pos.x
    y=pos.y
    z=pos.z

    maakBoom(x+2,y,z)
    wait(3)
    count+=1

