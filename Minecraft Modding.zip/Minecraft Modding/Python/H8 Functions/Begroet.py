#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math
import random

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks
SPpos=mc.player.setTilePos

pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

J="J"
N="N"
close="close"

def begroeting():
    chat("Hallo")
    chat("leuk om je te ontmoeten")

begroeting()
begroeting()
begroeting()
