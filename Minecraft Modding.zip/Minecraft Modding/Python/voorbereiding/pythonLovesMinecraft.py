print(2+2)
print("W"+"o"*20)
print("Python!")
print("<3s")
print("Minecraft")

