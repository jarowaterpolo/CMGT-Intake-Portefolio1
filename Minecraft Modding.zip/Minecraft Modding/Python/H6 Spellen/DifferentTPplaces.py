#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input

pos=mc.player.getTilePos()

x=pos.x
y=pos.y
z=pos.z

SPpos=mc.player.setPos

TPpunten = i(ip("Kies naar welk Punt je wil TPen: 1/2/3/4/5? "))
if TPpunten==1:
    SPpos(0,86,0)
elif TPpunten==2:
    SPpos(18,99,193)
elif TPpunten==3:
    SPpos(100,70,100)
elif TPpunten==4:
    SPpos(-12,72,100)
elif TPpunten==5:
    chat("there is no Fifth point at the moment")


