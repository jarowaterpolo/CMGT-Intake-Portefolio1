#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
places=mc.setBlocks

antwoord=ip("Maak een Krater? J/N: ")
pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

J="J"
N="N"

if antwoord==J:
    places(x+1,y+1,z+1,x-1,y-1,z-1, 0)
    chat("BOEM!!!")
else:
    chat("why not :(")
    

