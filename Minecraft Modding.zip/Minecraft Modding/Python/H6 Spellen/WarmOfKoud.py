#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math
import random

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks
SPpos=mc.player.setTilePos

pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

J="J"
N="N"
close="close"

blok=57
item="diamond"
amount="1"
target="@a"
SecretPosX=random.randint(-100,100)
SecretPosZ=random.randint(-100,100)
SecretPosY=mc.getHeight(SecretPosX, SecretPosZ)

BlockPlacer=1
startToggle=1
score=0

place(SecretPosX, SecretPosY, SecretPosZ, 57)

while BlockPlacer==1:
    chat("er is ergens in de wereld tussen -100 en 100 in zowel de x en z directie een blok geplaatst")
    wait(0.5)
    BlockPlacer=0
     
while startToggle==1:
    pos=mc.player.getTilePos()
    x=pos.x
    y=pos.y
    z=pos.z

    #a²+b²=c²
    #  _____
    #_/a²+b² = c
    afstand=round(math.sqrt((x-SecretPosX)**2 + (z-SecretPosZ)**2),0)
    chat(str(afstand))
    wait(0.5)
    if afstand > 100:
        chat("je bevriest")
    elif afstand > 50:
        chat("Koud")
    elif afstand > 10:
        chat("Warm")
    elif afstand > 5:
        chat("Je staat in de Fik")
    elif afstand == 0:
        chat("je hebt het blok gevonden ;)")
        place(SecretPosX, SecretPosY, SecretPosZ, 0)
        score+=1
        chat(score)
        Antwoord=ip("do you wanna start again? (J/N): ")
        if Antwoord==J:
            SecretPosX=random.randint(-100,100)
            SecretPosZ=random.randint(-100,100)
            SecretPosY=mc.getHeight(SecretPosX, SecretPosZ)
            place(SecretPosX, SecretPosY, SecretPosZ, 57)
            BlockPlacer=1
            startToggle=1
        elif Antwoord==N:
            chat("Thanks for Playing")
            startToggle=0
    
