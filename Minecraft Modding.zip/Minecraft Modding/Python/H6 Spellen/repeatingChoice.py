#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
J="J"
N="N"
place=mc.setBlock
places=mc.setBlocks
count=0


vervolgAntwoord=J
while vervolgAntwoord==J:
    count+=1
    vervolgAntwoord=ip("kies J/N: ")
    chat("je hebt een count van " + str(count))







