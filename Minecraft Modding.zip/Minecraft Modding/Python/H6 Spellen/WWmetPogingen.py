#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input

pos=mc.player.getTilePos()

x=pos.x
y=pos.y
z=pos.z

SPpos=mc.player.setPos

ww="mijncraft"
wwip=ip("Voer het wachtwoord in: ")
pogingen=0

while ww!=wwip and pogingen<3:
    pogingen+=1
    wwip=ip("Fout. Voer het wachtwoord in: ")

if ww==wwip:
    chat("Wachtwoord correct")


