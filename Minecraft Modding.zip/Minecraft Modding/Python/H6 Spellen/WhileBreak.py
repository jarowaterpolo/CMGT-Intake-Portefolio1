#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks
SPpos=mc.player.setTilePos

pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

ja="ja"
nee="nee"
close="close"

while True:
    Antwoord=ip("if you wanna exit this while loop type close: ")
    if Antwoord==close:
        break
    chat(Antwoord)
chat("de lus is beeindigd")
    


