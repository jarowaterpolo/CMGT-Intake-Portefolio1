#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
pos=mc.player.getTilePos()
wait=time.sleep
T=True
F=False
i=int
ip=input

zombies=i(ip("voer hier aantal zombies op scherm in: "))
if zombies>=20:
    chat("dat zijn veel zombies ik zou maar snel wegrennen")
elif zombies>1:
    chat("die zombies kan je wel aan pak ze")
else:
    chat("die zombie is in zn eentje pak hem")
    

