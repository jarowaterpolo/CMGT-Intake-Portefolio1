#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input

J="J"
N="N"
Money=1000
TakeOut=i(ip("How much Money do you wanna take out you still have(" + str(Money) + ") : "))

if Money>=TakeOut:
    bevestiging=ip("You sure? J/N: ")
    if bevestiging==J:
        chat("Here is your Money")
        chat("You took out " + str(TakeOut) + " Money")
    else:
        chat("you canceled the exchange")
else:
    chat("Srry you don't have enough Money!")



