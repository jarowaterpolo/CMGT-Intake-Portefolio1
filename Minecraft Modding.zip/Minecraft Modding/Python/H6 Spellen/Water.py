#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
J="J"
N="N"
place=mc.setBlock
places=mc.setBlocks
count=0


toggle=i(ip("kies modus 1=true 0=false: "))
while True:
    if toggle==1:
        if count<=10:
            pos=mc.player.getTilePos()
            x=pos.x
            y=pos.y
            z=pos.z

            place(x,y,z, 8)
            wait(1)
            place(x,y,z, 0)
            wait(1)

            count+=1
        else:
            toggle=i(ip("kies modus 1=true 0=false: "))
    else:
        wait(10)
        toggle=i(ip("kies modus 1=true 0=false: "))







