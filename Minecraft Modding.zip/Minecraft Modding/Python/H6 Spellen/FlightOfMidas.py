#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks
SPpos=mc.player.setTilePos

pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

ja="ja"
nee="nee"

lucht=0
water=9

while True:
    pos=mc.player.getTilePos()
    x=pos.x
    y=pos.y
    z=pos.z
    blokOnder=mc.getBlock(x,y-1,z)
    if blokOnder==0 or blokOnder==9:
        place(x,y-1,z, 41)
        SPpos(x,y+0.2,z)


