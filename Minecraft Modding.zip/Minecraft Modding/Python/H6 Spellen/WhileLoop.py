#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
pos=mc.player.getTilePos()
wait=time.sleep
T=True
F=False

i=10
while i>=0:
    chat(str(i))
    wait(1)
    i-=1


    

