#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
J="J"
N="N"
place=mc.setBlock
places=mc.setBlocks
count=0


toggle=i(ip("kies modus 1=true 0=false: "))
while True:
    if toggle==1:
        if count<=100:
            pos=mc.player.getTilePos()
            x=pos.x
            y=pos.y
            z=pos.z

            place(x,y,z, 46,1)

            count+=1
            wait(0.2)
        else:
            toggle=i(ip("kies modus 1=true 0=false: "))
    else:
        wait(10)
        toggle=i(ip("kies modus 1=true 0=false: "))







