#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks
SPpos=mc.player.setTilePos

pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

ja="ja"
nee="nee"
close="close"

Gebruiker=ip("Typ je Gebruikersnaam: ")
while True:
    Message=ip("Typ iets: ")
    if Message==close:
        chat("Gebruiker heeft de chat verlaten.")
        break
    chat(Message)

