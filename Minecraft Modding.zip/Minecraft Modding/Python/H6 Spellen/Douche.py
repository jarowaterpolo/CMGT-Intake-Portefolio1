#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
J="J"
N="N"
place=mc.setBlock
places=mc.setBlocks
DouX=-12
DouY=72
DouZ=100

breedte=1
hoogte=4
lengte=1

pos=mc.player.getTilePos()
x=pos.x
y=pos.y
z=pos.z

if DouX <= x < DouX + breedte and DouY <= y < DouY + hoogte and DouZ <= z < DouZ + lengte:
    places(DouX, DouY + hoogte, DouZ, DouX + breedte-1, DouY + hoogte, DouZ + lengte-1, 8)
    wait(20)
    places(DouX, DouY + hoogte, DouZ, DouX + breedte-1, DouY + hoogte, DouZ + lengte-1, 0)
else:
    places(DouX, DouY + hoogte, DouZ, DouX + breedte-1, DouY + hoogte, DouZ + lengte-1, 0)




