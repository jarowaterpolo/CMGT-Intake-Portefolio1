# Connect to Minecraft
from mcpi.minecraft import Minecraft
import time
import math
import random

mc = Minecraft.create()

# Variables
chat = mc.postToChat
wait = time.sleep
place = mc.setBlock
places = mc.setBlocks
SPpos = mc.player.setTilePos

# Constants
BLOCK_DIAMOND = 57
ITEM_DIAMOND = 264
SEARCH_RADIUS = 100

# Generate a random secret block position
def generate_secret_position():
    x = random.randint(-SEARCH_RADIUS, SEARCH_RADIUS)
    z = random.randint(-SEARCH_RADIUS, SEARCH_RADIUS)
    y = mc.getHeight(x, z)
    return x, y, z

# Give diamonds to all players
def give_item_near_player(mc, player_pos, block_id, amount):
    for i in range(amount):
        mc.setBlock(player_pos.x + i, player_pos.y, player_pos.z, block_id)

# Main game loop
def start_game():
    secret_x, secret_y, secret_z = generate_secret_position()
    place(secret_x, secret_y, secret_z, BLOCK_DIAMOND)
    chat("A secret block has been placed in the world between -100 and 100 in both X and Z directions!")

    while True:
        # Get player's current position
        pos = mc.player.getTilePos()
        x, y, z = pos.x, pos.y, pos.z

        # Calculate distance to the secret block
        distance = round(math.sqrt((x - secret_x) ** 2 + (z - secret_z) ** 2), 0)
        chat(f"Distance: {distance}")
        wait(0.5)

        # Provide hints based on the distance
        if distance > 100:
            chat("You are freezing cold!")
        elif distance > 50:
            chat("Cold")
        elif distance > 10:
            chat("Warm")
        elif distance > 5:
            chat("Hot!")
        elif distance == 0:
            chat("You found the secret block!")
            place(secret_x, secret_y, secret_z, 0)  # Remove the secret block
            player_pos = mc.player.getTilePos()
            give_item_near_player(mc, player_pos, 57, 3)  # Give 3 diamond blocks


            # Ask to play again
            answer = input("Do you want to start again? (J/N): ").strip().upper()
            if answer == "J":
                secret_x, secret_y, secret_z = generate_secret_position()
                place(secret_x, secret_y, secret_z, BLOCK_DIAMOND)
                chat("The game has restarted!")
            else:
                chat("Thanks for playing!")
                break

# Start the game
start_game()
