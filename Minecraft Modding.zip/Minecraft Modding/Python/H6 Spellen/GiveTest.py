from mcpi.minecraft import Minecraft
import time
import math

mc = Minecraft.create()

# Define the secret block position
SecretPosX = 10  # Example coordinates for the secret block
SecretPosZ = 10

while True:
    pos = mc.player.getTilePos()
    x_player = pos.x
    y_player = pos.y
    z_player = pos.z

    mc.postToChat("Congratulations! You've found the block and won!")
        
    # Place a command block at a nearby position
    command_block_x = x_player + 2
    command_block_y = y_player
    command_block_z = z_player

    mc.setBlock(command_block_x, command_block_y, command_block_z, 137)  # Place command block (block ID 137)

    # Set the command in the command block to give 1 diamond to the nearest player
    mc.postToChat(f"Setting command block at ({command_block_x}, {command_block_y}, {command_block_z}) to /give @p diamond 1")
    mc.setSign(command_block_x, command_block_y, command_block_z, 0, "give @p diamond 1")  # Set the command in the command block
        
    # Trigger the command block by placing a redstone block next to it
    mc.setBlock(command_block_x + 1, command_block_y, command_block_z, 73)  # Place redstone block to activate the command block

    # Wait for a moment before removing the redstone block (to prevent it from re-triggering)
    time.sleep(1)
    mc.setBlock(command_block_x + 1, command_block_y, command_block_z, 0)  # Remove the redstone block

    # End the game or reset for a new round
    break
