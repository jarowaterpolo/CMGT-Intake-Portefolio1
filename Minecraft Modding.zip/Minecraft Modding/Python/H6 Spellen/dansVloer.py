#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks

pos=mc.player.getTilePos()

x=pos.x
y=pos.y
z=pos.z

verschilPos=pos=mc.player.getTilePos()
xVerschil=verschilPos.x
yVerschil=verschilPos.y
zVerschil=verschilPos.z

#a²+b²=c²
#  _____
#_/a²+b² = c
afstand=round(math.sqrt((xVerschil-x)**2 + (zVerschil-z)**2),0)
chat(str(afstand))
SPpos=mc.player.setPos

vloerX=x-2
vloerY=y-1
vloerZ=z-2
breedte=5
lengte=5
blok=41

places(vloerX,vloerY,vloerZ,vloerX+breedte,vloerY,vloerZ+lengte, blok)

while vloerX<=x<=vloerX+breedte and vloerZ<=z<=vloerZ+lengte and afstand <= 5:
    if blok==41:
        blok=57
        x=pos.x
        y=pos.y
        z=pos.z
        afstand=round(math.sqrt((xVerschil-x)**2 + (zVerschil-z)**2),0)
        chat(str(afstand))
    else:
        blok=41
    places(vloerX,vloerY,vloerZ,vloerX+breedte,vloerY,vloerZ+lengte, blok)
    pos=mc.player.getTilePos()
    wait(0.5)

wait(3)
blok=2
places(vloerX,vloerY,vloerZ,vloerX+breedte,vloerY,vloerZ+lengte, blok)

