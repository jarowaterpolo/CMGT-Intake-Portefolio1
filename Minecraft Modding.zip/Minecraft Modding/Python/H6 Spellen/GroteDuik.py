#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
J="J"
N="N"
place=mc.setBlock
places=mc.setBlocks
count=0
score=0

pos=mc.player.getPos()
x=pos.x
y=pos.y
z=pos.z

SPpos=mc.player.setTilePos

blokBoven=mc.getBlock(x,y+2,z)
blokOnder=mc.getBlock(x,y-1,z)

while y<=100 and blokOnder!=2:
    wait(0.5)
    pos=mc.player.getPos()
    blokBoven=mc.getBlock(x,y+2,z)
    score+=1
    chat("je huidige score =" + str(score))
    SPpos(x,y+1,z)
    if score>=6:
        eindPos=mc.player.getPos()
        x=eindPos.x
        y=eindPos.y
        z=eindPos.z
        places(x-5,y+10,z-5,x+5,y+10,z+5, 38)
    
chat("je eind score =" + str(score))





