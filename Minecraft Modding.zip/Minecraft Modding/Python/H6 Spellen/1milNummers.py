#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks

pos=mc.player.getTilePos()

x=pos.x
y=pos.y
z=pos.z

ja="ja"
nee="nee"

Antwoord=ip("noem alle getallen tussen 1 en 1e6? (ja/nee): ")

if Antwoord == ja:
    teller=1
    while teller <= 1000000:
        chat(teller)
        teller+=1
        wait(0.01)
