#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time
import math

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
place=mc.setBlock
places=mc.setBlocks

pos=mc.player.getTilePos()

x=pos.x
y=pos.y
z=pos.z

woord="mine"
teller=0

while teller<50:
    savedwoord=woord
    wait(0.2)
    if woord=="mine":
        woord="craft"
    else:
        woord="mine"
    chat(woord+savedwoord)
    teller+=1
        
