#connectie met minecraft
from mcpi.minecraft import Minecraft
mc = Minecraft.create()
import time

#variabele
chat=mc.postToChat
wait=time.sleep
T=True
F=False
i=int
ip=input
J="J"
N="N"
place=mc.setBlock
x=100
y=70
z=100

SecretCheck = mc.getBlock(x,y,z)
if SecretCheck==50:
    #set air
    place(x,y,z+10, 0)
    wait(1)
    #set air
    place(x,y-1,z+10, 0)
    wait(1)
    #set air
    place(x,y-2,z+10, 0)
    wait(1)
    #set air
    place(x,y-3,z+10, 0)
    wait(1)
    #set air
    place(x,y-4,z+10, 0)
    wait(1)
    #set Grass
    place(x,y-1,z+10, 2)
    #set air
    place(x,y-5,z+10, 0)
    wait(1)
    #set Dirt
    place(x,y-2,z+10, 3)
    #set air
    place(x,y-6,z+10, 0)
    wait(1)
    #set Dirt
    place(x,y-3,z+10, 3)
    #set air
    place(x,y-7,z+10, 0)
    wait(1)
    #set stone
    place(x,y-4,z+10, 1)
    wait(1)
    #set stone
    place(x,y-5,z+10, 1)
    wait(1)
    #set stone
    place(x,y-6,z+10, 1)
    wait(1)
    #set OakPlanks
    place(x,y-7,z+10, 5)
    wait(1)
else:
    chat("maybe if you place something on one of the places you can tp to youl find a secret")




