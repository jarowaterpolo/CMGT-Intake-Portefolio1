﻿namespace antimatter_test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buydim1 = new System.Windows.Forms.Button();
            this.dim1text = new System.Windows.Forms.TextBox();
            this.antmtext = new System.Windows.Forms.TextBox();
            this.amountdim1 = new System.Windows.Forms.TextBox();
            this.dim2text = new System.Windows.Forms.TextBox();
            this.amountdim2 = new System.Windows.Forms.TextBox();
            this.buydim2 = new System.Windows.Forms.Button();
            this.bougthdim1 = new System.Windows.Forms.TextBox();
            this.bougthdim2 = new System.Windows.Forms.TextBox();
            this.bougthdim3 = new System.Windows.Forms.TextBox();
            this.buydim3 = new System.Windows.Forms.Button();
            this.amountdim3 = new System.Windows.Forms.TextBox();
            this.dim3text = new System.Windows.Forms.TextBox();
            this.roguescreen = new System.Windows.Forms.GroupBox();
            this.rogue3 = new System.Windows.Forms.Button();
            this.rogue2 = new System.Windows.Forms.Button();
            this.rogue1 = new System.Windows.Forms.Button();
            this.hpbar = new System.Windows.Forms.TextBox();
            this.xpbar = new System.Windows.Forms.TextBox();
            this.lvl = new System.Windows.Forms.TextBox();
            this.stats = new System.Windows.Forms.GroupBox();
            this.choice1lvl_text = new System.Windows.Forms.TextBox();
            this.choice2lvl_text = new System.Windows.Forms.TextBox();
            this.choice3lvl_text = new System.Windows.Forms.TextBox();
            this.choice1lvlup = new System.Windows.Forms.TextBox();
            this.choice2lvlup = new System.Windows.Forms.TextBox();
            this.choice3lvlup = new System.Windows.Forms.TextBox();
            this.roguescreen.SuspendLayout();
            this.stats.SuspendLayout();
            this.SuspendLayout();
            // 
            // buydim1
            // 
            this.buydim1.AutoSize = true;
            this.buydim1.BackColor = System.Drawing.Color.Green;
            this.buydim1.Location = new System.Drawing.Point(239, 121);
            this.buydim1.Name = "buydim1";
            this.buydim1.Size = new System.Drawing.Size(211, 34);
            this.buydim1.TabIndex = 0;
            this.buydim1.Text = "cost ad1";
            this.buydim1.UseVisualStyleBackColor = false;
            this.buydim1.Click += new System.EventHandler(this.buydim1_Click);
            // 
            // dim1text
            // 
            this.dim1text.BackColor = System.Drawing.Color.Maroon;
            this.dim1text.Location = new System.Drawing.Point(17, 125);
            this.dim1text.Name = "dim1text";
            this.dim1text.Size = new System.Drawing.Size(112, 26);
            this.dim1text.TabIndex = 2;
            this.dim1text.Text = "1st Dimension";
            // 
            // antmtext
            // 
            this.antmtext.BackColor = System.Drawing.Color.Maroon;
            this.antmtext.Location = new System.Drawing.Point(17, 12);
            this.antmtext.Name = "antmtext";
            this.antmtext.Size = new System.Drawing.Size(176, 26);
            this.antmtext.TabIndex = 3;
            this.antmtext.Text = "Antimatter: 0\r\n\r\n";
            // 
            // amountdim1
            // 
            this.amountdim1.BackColor = System.Drawing.Color.Maroon;
            this.amountdim1.Location = new System.Drawing.Point(135, 125);
            this.amountdim1.Name = "amountdim1";
            this.amountdim1.Size = new System.Drawing.Size(98, 26);
            this.amountdim1.TabIndex = 4;
            this.amountdim1.Text = "0";
            // 
            // dim2text
            // 
            this.dim2text.BackColor = System.Drawing.Color.Maroon;
            this.dim2text.Location = new System.Drawing.Point(17, 153);
            this.dim2text.Name = "dim2text";
            this.dim2text.Size = new System.Drawing.Size(112, 26);
            this.dim2text.TabIndex = 5;
            this.dim2text.Text = "2nd Dimension";
            this.dim2text.TextChanged += new System.EventHandler(this.dim2text_TextChanged);
            // 
            // amountdim2
            // 
            this.amountdim2.BackColor = System.Drawing.Color.Maroon;
            this.amountdim2.Location = new System.Drawing.Point(135, 153);
            this.amountdim2.Name = "amountdim2";
            this.amountdim2.Size = new System.Drawing.Size(98, 26);
            this.amountdim2.TabIndex = 6;
            this.amountdim2.Text = "0";
            // 
            // buydim2
            // 
            this.buydim2.AutoSize = true;
            this.buydim2.BackColor = System.Drawing.Color.Green;
            this.buydim2.Location = new System.Drawing.Point(239, 153);
            this.buydim2.Name = "buydim2";
            this.buydim2.Size = new System.Drawing.Size(211, 34);
            this.buydim2.TabIndex = 7;
            this.buydim2.Text = "cost ad2";
            this.buydim2.UseVisualStyleBackColor = false;
            this.buydim2.Click += new System.EventHandler(this.buydim2_Click);
            // 
            // bougthdim1
            // 
            this.bougthdim1.BackColor = System.Drawing.Color.Maroon;
            this.bougthdim1.Location = new System.Drawing.Point(452, 125);
            this.bougthdim1.Name = "bougthdim1";
            this.bougthdim1.Size = new System.Drawing.Size(292, 26);
            this.bougthdim1.TabIndex = 8;
            this.bougthdim1.Text = "0/10 for 2 X mult and 10 X cost increase\r\n";
            // 
            // bougthdim2
            // 
            this.bougthdim2.BackColor = System.Drawing.Color.Maroon;
            this.bougthdim2.Location = new System.Drawing.Point(452, 157);
            this.bougthdim2.Name = "bougthdim2";
            this.bougthdim2.Size = new System.Drawing.Size(292, 26);
            this.bougthdim2.TabIndex = 9;
            this.bougthdim2.Text = "0/10 for 2 X mult and 10 X cost increase\r\n";
            this.bougthdim2.TextChanged += new System.EventHandler(this.bougthdim2_TextChanged);
            // 
            // bougthdim3
            // 
            this.bougthdim3.BackColor = System.Drawing.Color.Maroon;
            this.bougthdim3.Location = new System.Drawing.Point(452, 189);
            this.bougthdim3.Name = "bougthdim3";
            this.bougthdim3.Size = new System.Drawing.Size(292, 26);
            this.bougthdim3.TabIndex = 10;
            this.bougthdim3.Text = "0/10 for 2 X mult and 10 X cost increase\r\n";
            // 
            // buydim3
            // 
            this.buydim3.AutoSize = true;
            this.buydim3.BackColor = System.Drawing.Color.Green;
            this.buydim3.Location = new System.Drawing.Point(239, 185);
            this.buydim3.Name = "buydim3";
            this.buydim3.Size = new System.Drawing.Size(211, 34);
            this.buydim3.TabIndex = 11;
            this.buydim3.Text = "cost ad3";
            this.buydim3.UseVisualStyleBackColor = false;
            this.buydim3.Click += new System.EventHandler(this.buydim3_Click);
            // 
            // amountdim3
            // 
            this.amountdim3.BackColor = System.Drawing.Color.Maroon;
            this.amountdim3.Location = new System.Drawing.Point(135, 189);
            this.amountdim3.Name = "amountdim3";
            this.amountdim3.Size = new System.Drawing.Size(98, 26);
            this.amountdim3.TabIndex = 12;
            this.amountdim3.Text = "0";
            // 
            // dim3text
            // 
            this.dim3text.BackColor = System.Drawing.Color.Maroon;
            this.dim3text.Location = new System.Drawing.Point(17, 189);
            this.dim3text.Name = "dim3text";
            this.dim3text.Size = new System.Drawing.Size(112, 26);
            this.dim3text.TabIndex = 13;
            this.dim3text.Text = "3rd Dimension";
            // 
            // roguescreen
            // 
            this.roguescreen.Controls.Add(this.rogue3);
            this.roguescreen.Controls.Add(this.rogue2);
            this.roguescreen.Controls.Add(this.rogue1);
            this.roguescreen.Location = new System.Drawing.Point(750, 125);
            this.roguescreen.Name = "roguescreen";
            this.roguescreen.Size = new System.Drawing.Size(425, 136);
            this.roguescreen.TabIndex = 14;
            this.roguescreen.TabStop = false;
            this.roguescreen.Text = "Rogue Choices";
            this.roguescreen.Visible = false;
            // 
            // rogue3
            // 
            this.rogue3.Location = new System.Drawing.Point(281, 53);
            this.rogue3.Name = "rogue3";
            this.rogue3.Size = new System.Drawing.Size(144, 83);
            this.rogue3.TabIndex = 2;
            this.rogue3.Text = "2X mult to all";
            this.rogue3.UseVisualStyleBackColor = true;
            this.rogue3.Click += new System.EventHandler(this.rogue3_Click);
            // 
            // rogue2
            // 
            this.rogue2.Location = new System.Drawing.Point(147, 53);
            this.rogue2.Name = "rogue2";
            this.rogue2.Size = new System.Drawing.Size(144, 83);
            this.rogue2.TabIndex = 1;
            this.rogue2.Text = "5X mult to dim 2";
            this.rogue2.UseVisualStyleBackColor = true;
            this.rogue2.Click += new System.EventHandler(this.rogue2_Click);
            // 
            // rogue1
            // 
            this.rogue1.Location = new System.Drawing.Point(0, 52);
            this.rogue1.Name = "rogue1";
            this.rogue1.Size = new System.Drawing.Size(151, 83);
            this.rogue1.TabIndex = 0;
            this.rogue1.Text = "10X mult to dim 1";
            this.rogue1.UseVisualStyleBackColor = true;
            this.rogue1.Click += new System.EventHandler(this.rogue1_Click);
            // 
            // hpbar
            // 
            this.hpbar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.hpbar.Location = new System.Drawing.Point(239, 12);
            this.hpbar.Name = "hpbar";
            this.hpbar.Size = new System.Drawing.Size(211, 26);
            this.hpbar.TabIndex = 15;
            this.hpbar.Text = "you still have: 1/100 life";
            // 
            // xpbar
            // 
            this.xpbar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.xpbar.Location = new System.Drawing.Point(673, 12);
            this.xpbar.Name = "xpbar";
            this.xpbar.Size = new System.Drawing.Size(211, 26);
            this.xpbar.TabIndex = 16;
            this.xpbar.Text = "you have: 0/100 xp";
            // 
            // lvl
            // 
            this.lvl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lvl.Location = new System.Drawing.Point(456, 12);
            this.lvl.Name = "lvl";
            this.lvl.Size = new System.Drawing.Size(211, 26);
            this.lvl.TabIndex = 17;
            this.lvl.Text = "you are lvl 0";
            // 
            // stats
            // 
            this.stats.Controls.Add(this.choice3lvlup);
            this.stats.Controls.Add(this.choice2lvlup);
            this.stats.Controls.Add(this.choice1lvlup);
            this.stats.Controls.Add(this.choice3lvl_text);
            this.stats.Controls.Add(this.choice2lvl_text);
            this.stats.Controls.Add(this.choice1lvl_text);
            this.stats.Location = new System.Drawing.Point(1181, 12);
            this.stats.Name = "stats";
            this.stats.Size = new System.Drawing.Size(397, 314);
            this.stats.TabIndex = 18;
            this.stats.TabStop = false;
            this.stats.Text = "Stats:";
            this.stats.Visible = false;
            // 
            // choice1lvl_text
            // 
            this.choice1lvl_text.Location = new System.Drawing.Point(6, 26);
            this.choice1lvl_text.Name = "choice1lvl_text";
            this.choice1lvl_text.Size = new System.Drawing.Size(169, 26);
            this.choice1lvl_text.TabIndex = 0;
            this.choice1lvl_text.Text = "choice 1 lvl = 1";
            // 
            // choice2lvl_text
            // 
            this.choice2lvl_text.Location = new System.Drawing.Point(6, 58);
            this.choice2lvl_text.Name = "choice2lvl_text";
            this.choice2lvl_text.Size = new System.Drawing.Size(169, 26);
            this.choice2lvl_text.TabIndex = 1;
            this.choice2lvl_text.Text = "choice 2 lvl = 1";
            // 
            // choice3lvl_text
            // 
            this.choice3lvl_text.Location = new System.Drawing.Point(6, 90);
            this.choice3lvl_text.Name = "choice3lvl_text";
            this.choice3lvl_text.Size = new System.Drawing.Size(169, 26);
            this.choice3lvl_text.TabIndex = 2;
            this.choice3lvl_text.Text = "choice 3 lvl = 1";
            // 
            // choice1lvlup
            // 
            this.choice1lvlup.Location = new System.Drawing.Point(181, 26);
            this.choice1lvlup.Name = "choice1lvlup";
            this.choice1lvlup.Size = new System.Drawing.Size(181, 26);
            this.choice1lvlup.TabIndex = 3;
            this.choice1lvlup.Text = "choice 1 lvlup = 0/10";
            // 
            // choice2lvlup
            // 
            this.choice2lvlup.Location = new System.Drawing.Point(177, 58);
            this.choice2lvlup.Name = "choice2lvlup";
            this.choice2lvlup.Size = new System.Drawing.Size(181, 26);
            this.choice2lvlup.TabIndex = 4;
            this.choice2lvlup.Text = "choice 2 lvlup = 0/10";
            // 
            // choice3lvlup
            // 
            this.choice3lvlup.Location = new System.Drawing.Point(181, 90);
            this.choice3lvlup.Name = "choice3lvlup";
            this.choice3lvlup.Size = new System.Drawing.Size(181, 26);
            this.choice3lvlup.TabIndex = 5;
            this.choice3lvlup.Text = "choice 3 lvlup = 0/10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1633, 450);
            this.Controls.Add(this.stats);
            this.Controls.Add(this.lvl);
            this.Controls.Add(this.xpbar);
            this.Controls.Add(this.hpbar);
            this.Controls.Add(this.roguescreen);
            this.Controls.Add(this.dim3text);
            this.Controls.Add(this.amountdim3);
            this.Controls.Add(this.buydim3);
            this.Controls.Add(this.bougthdim3);
            this.Controls.Add(this.bougthdim2);
            this.Controls.Add(this.bougthdim1);
            this.Controls.Add(this.buydim2);
            this.Controls.Add(this.amountdim2);
            this.Controls.Add(this.dim2text);
            this.Controls.Add(this.amountdim1);
            this.Controls.Add(this.antmtext);
            this.Controls.Add(this.dim1text);
            this.Controls.Add(this.buydim1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.roguescreen.ResumeLayout(false);
            this.stats.ResumeLayout(false);
            this.stats.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buydim1;
        private System.Windows.Forms.TextBox dim1text;
        private System.Windows.Forms.TextBox antmtext;
        private System.Windows.Forms.TextBox amountdim1;
        private System.Windows.Forms.TextBox dim2text;
        private System.Windows.Forms.TextBox amountdim2;
        private System.Windows.Forms.Button buydim2;
        private System.Windows.Forms.TextBox bougthdim1;
        private System.Windows.Forms.TextBox bougthdim2;
        private System.Windows.Forms.TextBox bougthdim3;
        private System.Windows.Forms.Button buydim3;
        private System.Windows.Forms.TextBox amountdim3;
        private System.Windows.Forms.TextBox dim3text;
        private System.Windows.Forms.GroupBox roguescreen;
        private System.Windows.Forms.Button rogue3;
        private System.Windows.Forms.Button rogue2;
        private System.Windows.Forms.Button rogue1;
        private System.Windows.Forms.TextBox hpbar;
        private System.Windows.Forms.TextBox xpbar;
        private System.Windows.Forms.TextBox lvl;
        private System.Windows.Forms.GroupBox stats;
        private System.Windows.Forms.TextBox choice1lvl_text;
        private System.Windows.Forms.TextBox choice3lvl_text;
        private System.Windows.Forms.TextBox choice2lvl_text;
        private System.Windows.Forms.TextBox choice1lvlup;
        private System.Windows.Forms.TextBox choice3lvlup;
        private System.Windows.Forms.TextBox choice2lvlup;
    }
}

