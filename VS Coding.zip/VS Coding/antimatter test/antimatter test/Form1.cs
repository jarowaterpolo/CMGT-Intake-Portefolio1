﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace antimatter_test
{
    public partial class Form1 : Form
    {
        double antimatter = 10;
        double firstdim = 0;
        double seconddim = 0;
        double thirddim = 0;
        double costmult1 = 1;
        double costmult2 = 1;
        double costmult3 = 1;
        double dim1cost = 10;
        double dim2cost = 100;
        double dim3cost = 1000;
        double dim1production = 1;
        double dim2production = 1;
        double dim3production = 1;
        double timesbougth1 = 0;
        double timesbougth2 = 0;
        double timesbougth3 = 0;
        double timesmultresult1 = 1;
        double timesmultresult2 = 1;
        double timesmultresult3 = 1;
        double costtotal1 = 0;
        double costtotal2 = 0;
        double costtotal3 = 0;
        double rogue = 0;
        double roguemult1 = 1;
        double roguemult2 = 1;
        double roguemult3 = 1;
        double milestonedim2 = 0;
        double milestoneMIam = 0;
        double maxlife = 100;
        double life = 100;
        double decay = 1;
        double xp = 0;
        double maxxp = 100;
        double level = 0;
        double lvlmult = 1;
        double chosen1 = 0;
        double chosen2 = 0;
        double chosen3 = 0;
        double chosen1max = 10;
        double chosen2max = 10;
        double chosen3max = 10;
        double onceact = 0;
        double choice1lvl = 0;
        double choice2lvl = 0;
        double choice3lvl = 0;
        double roguemultmult1 = 10;
        double roguemultmult2 = 5;
        double roguemultmult3 = 2;
        double liferestart = 0;
        double milestonecheck = 0;

        private Timer timer;
        public Form1()
        {
            InitializeComponent();
            InitializeTimer();


            //hp/life
            hpbar.Text = "you still have " + life + "/" + maxlife + " life";
            //xp
            xpbar.Text = "you have:" + xp + "/" + maxxp + " xp";
            //lvl
            lvl.Text = "you are lvl: " + level;


            //am
            if (antimatter >= 1e3)
            {
                antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
            }
            else
            {
                antmtext.Text = antimatter.ToString() + " Antimatter";
            }

            //cost dim 1
            costtotal1 = dim1cost * costmult1;
            if (costtotal1 >= 1e3)
            {
                buydim1.Text = costtotal1.ToString("0.##E0") + " Antimatter";
            }
            else
            {
                buydim1.Text = "cost: " + (costtotal1) + " antimatter";
            }

            //cost dim 2
            costtotal2 = dim2cost * costmult2;
            if (costtotal2 >= 1e3)
            {
                buydim2.Text = costtotal2.ToString("0.##E0") + " Antimatter";
            }
            else
            {
                buydim2.Text = "cost: " + (costtotal2) + " antimatter";
            }

            //cost dim 3
            costtotal3 = dim3cost * costmult3;
            if (costtotal3 >= 1e3)
            {
                buydim3.Text = costtotal3.ToString("0.##E0") + " Antimatter";
            }
            else
            {
                buydim3.Text = "cost: " + (costtotal3) + " antimatter";
            }

        }

        private void InitializeTimer()
        {
            timer = new Timer();
            timer.Interval = 1000; // Interval in milliseconds (adjust as needed)
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            Update();
        }


        private void buydim1_Click(object sender, EventArgs e)
        {
            if (antimatter >= costtotal1)
            {
                antimatter -= costtotal1;
                firstdim += 1;
                timesbougth1 += 1;
                dim1cost = 10;
                costtotal1 = dim1cost * costmult1;

                dim1text.Text = "1st dimension: " + firstdim;

                //cost dim 1
                if (costtotal1 >= 1e3)
                {
                    buydim1.Text = costtotal1.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim1.Text = "cost: " + (costtotal1) + " antimatter";
                }

                //am
                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }

                amountdim1.Text = firstdim + "";
                bougthdim1.Text = timesbougth1 + "/10 for a 2 X mult and 10 X cost increase";
            }

        }



        private void buydim2_Click(object sender, EventArgs e)
        {
            if (antimatter >= costtotal2)
            {
                antimatter -= costtotal2;
                seconddim += 1;
                timesbougth2 += 1;

                if (milestonecheck >= 1)
                {
                    MessageBox.Show("Rogue Option Skip Fixer");
                }
                else
                {
                    milestonedim2 += 1;

                }

                dim2cost = 100;
                costtotal2 = dim2cost * costmult2;

                dim2text.Text = "2nd dimension: " + seconddim;

                //cost dim 2
                if (costtotal2 >= 1e3)
                {
                    buydim2.Text = costtotal2.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim2.Text = "cost: " + (costtotal2) + " antimatter";
                }

                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }

                amountdim2.Text = seconddim + "";
                bougthdim2.Text = timesbougth2 + "/10 for a 2 X mult and 10 X cost increase";
            }
        }


        public new void Update()
        {
            if (life > 0)
            {
                if (firstdim > 0)
                {
                    life -= decay;
                    //hp/life
                    hpbar.Text = "you still have " + life + "/" + maxlife + " life";
                }

            }

            if (life == 0)
            {
                life = 100;
                firstdim = 0;
                seconddim = 0;
                thirddim = 0;

                if (antimatter >= 1e6)
                {
                    xp += antimatter / 1e6;
                }
                else
                {
                    xp += 1;
                }
                
                antimatter = 10;

                //xp
                if (maxxp >= 1e6)
                {
                    if (xp >= 1e6)
                    {
                        xpbar.Text = "you have:" + xp.ToString("0.##E0") + "/" + maxxp.ToString("0.##E0") + " xp";
                    }
                    else
                    {
                        xpbar.Text = "you have:" + xp + "/" + maxxp.ToString("0.##E0") + " xp";
                    }
                }
                else
                {
                    xpbar.Text = "you have:" + xp + "/" + maxxp + " xp";
                }
                //am
                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }

                //dim text
                amountdim1.Text = firstdim + "";
                amountdim2.Text = seconddim + "";
                amountdim3.Text = thirddim + "";

                dim1text.Text = "1st dimension: " + firstdim;
                dim2text.Text = "2nd dimension: " + seconddim;
                dim3text.Text = "3rd dimension: " + thirddim;

                //life text
                hpbar.Text = "you still have " + life + "/" + maxlife + " life";

                //costs
                dim1cost = 10;
                dim2cost = 100;
                dim3cost = 1000;
                costmult1 = 1;
                costmult2 = 1;
                costmult3 = 1;
                costtotal1 = dim1cost * costmult1;
                costtotal2 = dim2cost * costmult2;
                costtotal3 = dim3cost * costmult3;

                //costs text

                //cost dim 1
                if (costtotal1 >= 1e3)
                {
                    buydim1.Text = costtotal1.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim1.Text = "cost: " + (costtotal1) + " antimatter";
                }

                //cost dim 2
                if (costtotal2 >= 1e3)
                {
                    buydim2.Text = costtotal2.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim2.Text = "cost: " + (costtotal2) + " antimatter";
                }

                //cost dim 3
                if (costtotal3 >= 1e3)
                {
                    buydim3.Text = costtotal3.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim3.Text = "cost: " + (costtotal3) + " antimatter";
                }

                // bought text + mult reset
                timesbougth1 = 0;
                timesbougth2 = 0;
                timesbougth3 = 0;

                timesmultresult1 = 1;
                timesmultresult2 = 1;
                timesmultresult3 = 1;

                bougthdim1.Text = timesbougth1 + "/10 for a 2 X mult and 10 X cost increase";
                bougthdim2.Text = timesbougth2 + "/10 for a 2 X mult and 10 X cost increase";
                bougthdim3.Text = timesbougth3 + "/10 for a 2 X mult and 10 X cost increase";

                //life restart number
                liferestart += 1;

                //rogue milestone resetter
                milestonedim2 = 0;
                milestoneMIam = 0;
            }

            if (xp >= maxxp)
            {
                onceact += 1;
            }

            if (level == 0)
            {
                maxxp = 100;

                if (xp >= maxxp)
                {
                    xp = 0;
                    level += 1;
                    //lvl
                    lvl.Text = "you are lvl: " + level;
                    //xp
                    if (maxxp >= 1e6)
                    {
                        if (xp >= 1e6)
                        {
                            xpbar.Text = "you have:" + xp.ToString("0.##E0") + "/" + maxxp.ToString("0.##E0") + " xp";
                        }
                        else
                        {
                            xpbar.Text = "you have:" + xp + "/" + maxxp.ToString("0.##E0") + " xp";
                        }
                    }
                    else
                    {
                        xpbar.Text = "you have:" + xp + "/" + maxxp + " xp";
                    }
                }
            }

            if (level == 1)
            {
                if (onceact == 1)
                {
                    lvlmult *= 2;
                    maxxp *= 100;
                    onceact = 0;
                }

                if (xp >= maxxp)
                {
                    xp = 0;
                    level += 1;
                    //lvl
                    lvl.Text = "you are lvl: " + level;
                    //xp
                    if (maxxp >= 1e6)
                    {
                        if (xp >= 1e6)
                        {
                            xpbar.Text = "you have:" + xp.ToString("0.##E0") + "/" + maxxp.ToString("0.##E0") + " xp";
                        }
                        else
                        {
                            xpbar.Text = "you have:" + xp + "/" + maxxp.ToString("0.##E0") + " xp";
                        }
                    }
                    else
                    {
                        xpbar.Text = "you have:" + xp + "/" + maxxp + " xp";
                    }
                    MessageBox.Show("you leveled up");
                }
            }

            

            if (firstdim >= 1)
            {
                antimatter += dim1production * firstdim * timesmultresult1 * roguemult1 * roguemult3;

                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }
            }

            if (seconddim >= 1)
            {
                firstdim += seconddim * timesmultresult2 * roguemult2 * roguemult3;
                amountdim1.Text = firstdim + "";
            }

            if (antimatter >= 1e6)
            {
                if (milestonecheck >= 1)
                {
                    MessageBox.Show("Rogue Option Skip Fixer");

                }
                else
                {
                    milestoneMIam += 1;
                }

            }

            // rogue Milestones
            if (milestonedim2 == 1)
            {
                milestonecheck += 1;
                if ( milestonecheck >  1)
                {
                    MessageBox.Show("Rogue Option Skip Fixer");
                }
                else
                {
                    rogue = 1;
                    milestonedim2 = 2;
                    milestonecheck = 0;
                }
            }
            if (milestoneMIam == 1)
            {
                milestonecheck += 1;
                if (milestonecheck > 1)
                {
                    MessageBox.Show("Rogue Option Skip Fixer");
                }
                else
                {
                    rogue = 1;
                    milestoneMIam = 2;
                    milestonecheck = 0;
                }
            }

            if (thirddim >= 1)
            {
                seconddim += thirddim * timesmultresult3 * roguemult3;
                amountdim2.Text = seconddim + "";
            }

            if (timesbougth1 >= 10)
            {
                timesbougth1 -= 10;
                timesmultresult1 *= 2;
                costmult1 *= 10;
                dim1cost = 10;

                //cost dim 1
                if (costtotal1 >= 1e3)
                {
                    buydim1.Text = costtotal1.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim1.Text = "cost: " + (costtotal1) + " antimatter";
                }

                //am
                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }
                bougthdim1.Text = timesbougth1 + "/10 for a 2 X mult and 10 X cost increase";
            }

            if (timesbougth2 >= 10)
            {
                timesbougth2 -= 10;
                timesmultresult2 *= 2;
                costmult2 *= 100;
                dim2cost = 100;

                //cost dim 2
                if (costtotal2 >= 1e3)
                {
                    buydim2.Text = costtotal2.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim2.Text = "cost: " + (costtotal2) + " antimatter";
                }

                //am
                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }
                bougthdim2.Text = timesbougth2 + "/10 for a 2 X mult and 10 X cost increase";
            }

            if (timesbougth3 >= 10)
            {
                timesbougth3 -= 10;
                timesmultresult3 *= 2;
                costmult3 *= 1000;
                dim3cost = 1000;

                //cost dim 3
                if (costtotal3 >= 1e3)
                {
                    buydim3.Text = costtotal3.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim3.Text = "cost: " + (costtotal3) + " antimatter";
                }

                //am
                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }
                bougthdim3.Text = timesbougth3 + "/10 for a 2 X mult and 10 X cost increase";
            }

            // cost updater

            //dim 1
            if (costtotal1 >= 1e3)
            {
                buydim1.Text = costtotal1.ToString("0.##E0") + " Antimatter";
            }
            else
            {
                buydim1.Text = "cost: " + (costtotal1) + " antimatter";
            }
            //dim 2
            if (costtotal2 >= 1e3)
            {
                buydim2.Text = costtotal2.ToString("0.##E0") + " Antimatter";
            }
            else
            {
                buydim2.Text = "cost: " + (costtotal2) + " antimatter";
            }
            //dim 3
            if (costtotal3 >= 1e3)
            {
                buydim3.Text = costtotal3.ToString("0.##E0") + " Antimatter";
            }
            else
            {
                buydim3.Text = "cost: " + (costtotal3) + " antimatter";
            }
            

            if (rogue == 1)
            {
                roguescreen.Visible = true;
                rogue = 0;
            }

            //choice lvling
            
            //choice 1
            if (chosen1 == chosen1max)
            {
                chosen1 = 0;
                chosen1max *= 2;
                choice1lvl += 1;

                rogue1.Text = roguemultmult1 + "X mult to dim 1";
            }

            if (choice1lvl == 1)
            {
                roguemultmult1 *= 10;
            }
            else if (choice1lvl == 2)
            {
                roguemultmult1 *= 100;
            }
            else if (choice1lvl == 3)
            {
                roguemultmult1 *= 1000;
            }

            //choice 2
            if (chosen2 == chosen2max)
            {
                chosen2 = 0;
                chosen2max *= 2;
                choice2lvl += 1;

                rogue2.Text = roguemultmult2 + "X mult to dim 2";
            }

            if (choice2lvl == 1)
            {
                roguemultmult2 *= 10;
            }
            else if (choice2lvl == 2)
            {
                roguemultmult2 *= 100;
            }
            else if (choice2lvl == 3)
            {
                roguemultmult2 *= 1000;
            }

            //choice 3
            if (chosen3 == chosen3max)
            {
                chosen3 = 0;
                chosen3max *= 2;
                choice3lvl += 1;

                rogue3.Text = roguemultmult3 + "X mult to all";
            }

            if (choice3lvl == 1)
            {
                roguemultmult3 *= 10;
            }
            else if (choice3lvl == 2)
            {
                roguemultmult3 *= 100;
            }
            else if (choice3lvl == 3)
            {
                roguemultmult3 *= 1000;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dim2text_TextChanged(object sender, EventArgs e)
        {

        }

        private void bougthdim2_TextChanged(object sender, EventArgs e)
        {

        }

        private void buydim3_Click(object sender, EventArgs e)
        {
            if (antimatter >= costtotal3)
            {
                antimatter -= costtotal3;
                thirddim += 1;
                timesbougth3 += 1;
                dim3cost = 1000;
                costtotal3 = dim3cost * costmult3;

                dim3text.Text = "3rd dimension: " + thirddim;

                //cost dim 3
                if (costtotal3 >= 1e3)
                {
                    buydim3.Text = costtotal3.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    buydim3.Text = "cost: " + (costtotal3) + " antimatter";
                }

                if (antimatter >= 1e3)
                {
                    antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter";
                }
                else
                {
                    antmtext.Text = antimatter.ToString() + " Antimatter";
                }

                amountdim3.Text = thirddim + "";
                bougthdim3.Text = timesbougth3 + "/10 for a 2 X mult and 10 X cost increase";
            }

            if (liferestart >= 1)
            {
                stats.Visible = true;
            }
            else
            {
                stats.Visible = false;
            }
        }

        private void rogue1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Choice 1 selected");

            roguescreen.Visible = false;
            roguemult1 *= roguemultmult1;
            chosen1 += 1;

            choice1lvlup.Text = "choice 1 lvlup = " + chosen1 + "/" + chosen1max;
            choice1lvl_text.Text = "choice 1 lvl = " + choice1lvl;
        }

        private void rogue2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Choice 2 selected");

            roguescreen.Visible = false;
            roguemult2 *= roguemultmult2;
            chosen2 += 1;

            choice2lvlup.Text = "choice 2 lvlup = " + chosen2 + "/" + chosen2max;
            choice2lvl_text.Text = "choice 2 lvl = " + choice2lvl;
        }

        private void rogue3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Choice 3 selected");

            roguescreen.Visible = false;
            roguemult3 *= roguemultmult3;
            chosen3 += 1;

            choice3lvlup.Text = "choice 3 lvlup = " + chosen3 + "/" + chosen3max;
            choice3lvl_text.Text = "choice 3 lvl = " + choice3lvl;
        }
    }
}


//if (antimatter >= 1e6) // Check if antimatter is greater than or equal to 1,000,000
//{
//   antmtext.Text = antimatter.ToString("0.##E0") + " Antimatter"; // Format in scientific notation
//}
//else
//{
//    antmtext.Text = antimatter.ToString() + " Antimatter"; // Format normally
//}
