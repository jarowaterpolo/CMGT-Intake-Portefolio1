﻿using System;
using System.Data;
using System.Security.Cryptography.X509Certificates;

class TypeGainerGainProgram
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to Type_Gainer");
        Console.WriteLine("Type '-help-' to see the available commands.");
        Console.WriteLine("");
        double money = 0;
        double mult = 1;
        double adder = 1;
        double prestige = 1;
        double mega = 1;
        double ultra = 1;
        double prestiges = 0;
        int megas = 0;
        int ultras = 0;
        bool stopTimer = false;
        int seconds = 0;
        int minutes = 0;
        int hours = 0;
        double timemult = 1;
        int cheated = 0;
        int hackedtime = 0;
        int cheated_money = 0;
        int bougth_timemult = 0;
        int spendtime = 10 * bougth_timemult;
        double secret_mult = 1;
        int finish = 0;
        double automationspeed = 1;
        //double moneyUpdater = 0;

        // timer
        Thread timerThread = new Thread(() =>
        {
             while (!stopTimer)
            {
                Thread.Sleep(1000); // Sleep for 1 second
                seconds++;
                if (seconds >= 60)
                {
                    seconds -= 60;
                    minutes += 1;
                }

                if (minutes >= 60)
                {
                    minutes -= 60;
                    hours += 1;
                }
                    // Check if money reaches 1e307 to stop the timer
                    if (money >= 1e307)
                {
                    stopTimer = true;
                }
            }
        });
        timerThread.Start();
        //timer end

        //have to delete
        //prestiges += 1;

        while (true)
        {
            Console.WriteLine("");
            Console.WriteLine($"You own {money} money at the moment");
            Console.WriteLine($"Your adder is {adder}");
            Console.WriteLine($"Your multiplier is {mult}");
            Console.WriteLine($"Your prestige multiplier is {prestige} :-)");
            Console.WriteLine($"You have done {prestiges} prestiges");
            Console.WriteLine($"Your mega multiplier is {mega} ;-)");
            Console.WriteLine($"You have done {megas} mega's");
            Console.WriteLine($"Your ultra multiplier is {ultra} ;-)");
            Console.WriteLine($"You have done {ultras} ultra's");
            if (finish >= 2) 
            {
                Console.WriteLine($"your beating the game multiplier is {secret_mult} <3");
                Console.WriteLine($"you have finished the game {finish} times");
                Console.WriteLine("if you like the game please contact me :-)");
                Console.WriteLine("jaronieuwenhuisen@gmail.com");
                Console.WriteLine(":-) + <3");
            }
            Console.WriteLine("");

            if (prestiges <= 2 && money >= 1e6)
            {
                Console.WriteLine("automatic prestige");
                Console.WriteLine("you automatic prestige if your presitges are under 2");
                money = 0;
                adder = 1;
                mult = 1;
                prestige *= 2 * mega * ultra * timemult * secret_mult;
                prestiges += 1;
                automationspeed *= 2;
                Console.WriteLine(":-)");
                Console.WriteLine("");
            }
            if (megas <= 2 && money >= 1e12)
            {
                Console.WriteLine("automatic mega");
                Console.WriteLine("you automatic mega if your megas are under 2");
                money = 0;
                adder = 1;
                mult = 1;
                prestige = 1;
                mega *= 2 * ultra * timemult * secret_mult;
                megas += 1;
                prestiges -= 2;
                Console.WriteLine(";-)");
                Console.WriteLine("");
            }
            if (ultras <= 2 && money >= 1e30)
            {
                Console.WriteLine("automatic ultra");
                Console.WriteLine("you automatic ultra if your ultras are under 2");
                money = 0;
                adder = 1;
                mult = 1;
                prestige = 1;
                mega = 1;
                ultra *= 2 * timemult * secret_mult;
                ultras += 1;
                prestiges -= 2;
                megas -= 2;

                Console.WriteLine(";-)");
                Console.WriteLine("");
            }
            void AutoIncreaseMoney()
            {
                if (prestiges >= 1)
                {
                    if (prestiges == 1 && money == 0)
                    {
                        Console.WriteLine("you now automaticly win every second");
                        Console.WriteLine("");
                    }


                    while (true)
                    {
                        Thread.Sleep(1000);
                        money += adder * mult * prestige * mega * ultra * timemult * secret_mult * automationspeed;
                    }

                }
            }
            void AutoIncreaseAdder1()
            {
                if (megas >= 1)
                {
                    if (megas == 1 && money == 0)
                    {
                        Console.WriteLine("you now automaticly buy1 every second");
                        Console.WriteLine("");
                    }


                    while (true)
                    {
                        Thread.Sleep(1000);
                        if (money >= 10)
                        {
                            money -= 10;
                            adder += 1 * prestige * mega * ultra * timemult * secret_mult;
                        }
                    }

                }
            }

            void AutoIncreaseAdder10()
            {
                if (ultras >= 1)
                {
                    if (ultras == 1 && money == 0)
                    {
                        Console.WriteLine("you now automaticly buy10 every second");
                        Console.WriteLine("");
                    }


                    while (true)
                    {
                        Thread.Sleep(1000);
                        if (money >= 100)
                        {
                            money -= 100;
                            adder += 10 * prestige * mega * ultra * timemult * secret_mult;
                        }
                    }

                }
            }

            void AutoIncreaseMult1()
            {
                if (ultras >= 1)
                {
                    if (ultras == 1 && money == 0)
                    {
                        Console.WriteLine("you now automaticly buy mult1 every second");
                        Console.WriteLine("");
                    }


                    while (true)
                    {
                        Thread.Sleep(1000);
                        if (money >= 100)
                        {
                            money -= 100;
                            mult += 1 * prestige * mega * ultra * timemult * secret_mult;
                        }
                    }

                }
            }

            //void AutoUpdateMoney()
            //{
            //Thread.Sleep(60000);
            // Console.WriteLine("");
            //Console.WriteLine($"You own {money} money at the moment");
            //Console.WriteLine("");


            //}

            Thread autoMoneyThread = new Thread(AutoIncreaseMoney);
            autoMoneyThread.Start();

            Thread autoAdder1Thread = new Thread(AutoIncreaseAdder1);
            autoAdder1Thread.Start();

            Thread autoAdder10Thread = new Thread(AutoIncreaseAdder10);
            autoAdder10Thread.Start();

            Thread autoMult1Thread = new Thread(AutoIncreaseMult1);
            autoMult1Thread.Start();

            //Thread autoUpdateThread = new Thread(AutoUpdateMoney);
            //autoUpdateThread.Start();

            string userInput = Console.ReadLine().ToLower();

            switch (userInput)
            {
                case "help":
                    Console.WriteLine("Available commands:");
                    Console.WriteLine("- win: Get money equal to your adder");
                    Console.WriteLine("- buy1: Decrease money by 10 and increase adder by 1");
                    Console.WriteLine("- buy10: Decrease money by 100 and increase adder by 10");
                    Console.WriteLine("- buy100: Decrease money by 1000 and increase adder by 100");
                    Console.WriteLine("- buy1000: Decrease money by 10000 and increase adder by 1000");
                    Console.WriteLine("- buy mult1: Decrease money by 100 and increase multiplier by 1");
                    Console.WriteLine("- buy mult10: Decrease money by 1000 and increase multiplier by 10");
                    Console.WriteLine("- buy mult100: Decrease money by 10000 and increase multiplier by 100");
                    Console.WriteLine("- prestige: Reset money, adder, and multiplier to beginning values and increase prestige multiplier");
                    Console.WriteLine("- mega: Reset money, adder, multiplier, and prestige to beginning values and increase mega multiplier");
                    Console.WriteLine("- ultra: Reset money, adder, multiplier, prestige and mega to beginning values and increase ultra multiplier");
                    Console.WriteLine("- time: shows how long you have been in the game for");
                    Console.WriteLine("- help: Display available commands");
                    Console.WriteLine("");
                    break;

                case "time":
                    Console.WriteLine("");
                    Console.WriteLine("you have been here for " + hours + " hours " + minutes + " minutes and " + seconds + " seconds");
                        break;

                case "win":
                    money += adder * mult * prestige * mega * ultra * timemult * secret_mult;
                    Console.WriteLine("You won! Your money increased by " + adder );
                    Console.WriteLine("");
                    break;


                case "buy mult1":
                    if (money >= 100)
                    {
                        money -= 100;
                        mult += 1 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 100");
                        Console.WriteLine("");
                    }
                    break;

                case "buy mult10":
                    if (money >= 1000)
                    {
                        money -= 1000;
                        mult += 10 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 1000");
                        Console.WriteLine("");
                    }
                    break;

                case "buy mult100":
                    if (money >= 10000)
                    {
                        money -= 10000;
                        mult += 100 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 10000");
                        Console.WriteLine("");
                    }
                    break;

                case "buy mult1000":
                    if (money >= 100000)
                    {
                        money -= 100000;
                        mult += 1000 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 100000");
                        Console.WriteLine("");
                    }
                    break;

                case "buy1":
                    if (money >= 10)
                    {
                        money -= 10;
                        adder += 1 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 10");
                        Console.WriteLine("");
                    }
                    break;

                case "buy10":
                    if (money >= 100)
                    {
                        money -= 100;
                        adder += 10 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 100");
                        Console.WriteLine("");
                    }
                    break;

                case "buy100":
                    if (money >= 1000)
                    {
                        money -= 1000;
                        adder += 100 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 1000");
                        Console.WriteLine("");
                    }
                    break;

                case "buy1000":
                    if (money >= 10000)
                    {
                        money -= 10000;
                        adder += 1000 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 10000");
                        Console.WriteLine("");
                    }
                    break;

                case "buy10000":
                    if (money >= 100000)
                    {
                        money -= 100000;
                        adder += 10000 * prestige * mega * ultra * timemult * secret_mult;
                    }
                    else
                    {
                        Console.WriteLine("Not enough money you need 100000");
                        Console.WriteLine("");
                    }
                    break;

                case "prestige":
                    if (money >= 1e6)
                    {
                        Console.WriteLine(":-)");
                        money = 0;
                        adder = 1;
                        mult = 1;
                        prestige *= 2 * mega * ultra * timemult * secret_mult;
                        prestiges += 1;
                        automationspeed *= 2;
                    }
                    else
                    {
                        Console.WriteLine("You need at least 1e6 money to prestige!");
                        Console.WriteLine("");
                    }
                    break;

                case "mega":
                    if (money >= 1e12)
                    {
                        Console.WriteLine(";-)");
                        money = 0;
                        adder = 1;
                        mult = 1;
                        prestige = 1;
                        mega *= 2 * ultra * timemult * secret_mult;
                        megas += 1;
                    }
                    else
                    {
                        Console.WriteLine("You need at least 1e12 money to go mega!");
                        Console.WriteLine("");
                    }
                    break;

                case "ultra":
                    if (money >= 1e30)
                    {
                        Console.WriteLine(";-)");
                        money = 0;
                        adder = 1;
                        mult = 1;
                        prestige = 1;
                        mega = 1;
                        ultra *= 2 * timemult * secret_mult;
                        ultras += 1;
                    }
                    else
                    {
                        Console.WriteLine("You need at least 1e30 money to go ultra!");
                        Console.WriteLine("");
                    }
                    break;

                case "buy timemult":
                    cheated += 1;
                    if (minutes >= 10)
                    {
                        minutes -= 10;
                        timemult *= 2 * secret_mult;
                        bougth_timemult += 1;
                        Console.WriteLine("you just spended ten minutes of your life for a 2 times multiplier");
                        Console.WriteLine("");
                    }
                    else
                    {
                        if (hours >= 1)
                        {
                            hours -= 1;
                            minutes += 60;
                            minutes -= 10;
                            timemult *= 2 * secret_mult;
                            Console.WriteLine("you just spended ten minutes of your life for a 2 times multiplier");
                            Console.WriteLine("");
                        }
                        else
                        Console.WriteLine("Not enough money you need 10");
                        Console.WriteLine("");
                    }
                    break;

                case "spoiler":
                    Console.WriteLine("you will finish the game at 1e307");
                    Console.WriteLine("dont !!cheat!!");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("BERBECUE");
                    Console.WriteLine("");
                    break;

                case "time_hack":
                    hackedtime += 10;
                    cheated += 1;
                    Console.WriteLine("");
                    Console.WriteLine("you just hacked yourself trough time it is now 10 minutes into the future");
                    minutes += 10;
                    Console.WriteLine("");
                    Console.WriteLine("you have been here for " + hours + " hours " + minutes + " minutes and " + seconds + " seconds");
                    break;

                case "cheat":
                    cheated += 1;
                    Console.WriteLine("you can use 10 minutes of your time to buy a 2 times multiplier by typing -buy timemult-");
                    Console.WriteLine("dont try to cheat anymore okay?");
                    Console.WriteLine("");
                    break;

                case "ultra_cheat":
                    cheated += 1;
                    Console.WriteLine("how did you find this");
                    Console.WriteLine("for the effort");
                    Console.WriteLine("you can get 10 minutes of free time when you type time_hack");
                    Console.WriteLine("you can get 100 money when you type money_hack");
                    Console.WriteLine("");
                    break;

                case "money_hack":
                    cheated_money += 100;
                    cheated += 1;
                    money += 100 * secret_mult;
                    Console.WriteLine("you just cheated in 100 money");
                    Console.WriteLine("");
                    break;

                case "hack_hack":
                    money += 1e308;
                    cheated += 1;
                    Console.WriteLine("you just cheated in 1e308 money");
                    Console.WriteLine("");
                    break;
                    
                case "BERBECUE":
                    money += 1e307;
                    cheated += 1;
                    Console.WriteLine("you just truly found the ultimate secret");
                    Console.WriteLine("for doing this the BER gave you 1e307 money");
                    Console.WriteLine("");
                    break;

                case "cheat_stats":
                    Console.WriteLine("your time_multiplier is " + timemult);
                    Console.WriteLine("you have cheated " + cheated + " times");
                    Console.WriteLine("and you have gotten " + hackedtime + " minutes of hacked time" );
                    Console.WriteLine("and you cheated in " + cheated_money + " money");
                    Console.WriteLine("");
                    break;


                default:
                    Console.WriteLine("Invalid command. Type '-help-' for available commands.");
                    Console.WriteLine("");
                    break;
            }

            if (money >= 1e307)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("STATS OF THIS RUN");
                Console.WriteLine("time you have been here" + hours + " hours " + minutes + " minutes and " + seconds + " seconds");
                Console.WriteLine("+" + spendtime + " minutes of time that was spend on the timemultiplier");
                Console.WriteLine("-" + hackedtime + " minutes of hacked time");
                Console.WriteLine("");
                Console.WriteLine("the amount you cheated " + cheated);
                Console.WriteLine("and what you have cheated in");
                Console.WriteLine("you have gotten " + hackedtime + " minutes of hacked time");
                Console.WriteLine("you cheated in " + cheated_money + " money");
                Console.WriteLine("you also got a cheated timemultiplier of " + timemult);
                Console.WriteLine("");
                Console.WriteLine("the rest of the stats");
                Console.WriteLine("money " + money);
                Console.WriteLine("adder " + adder);
                Console.WriteLine("multiplier " + mult);
                Console.WriteLine("prestige_multiplier " + prestige);
                Console.WriteLine("amount of prestiges " + prestiges);
                Console.WriteLine("mega_multiplier " + mega);
                Console.WriteLine("amount of megas " + megas);
                Console.WriteLine("ultra_multiplier " + ultra);
                Console.WriteLine("amount of ultra's " + ultras);
                if (finish >= 1)
                {
                    Console.WriteLine("secret_mult " + secret_mult);
                    Console.WriteLine("finished the game " + finish + " times");
                }
                Console.WriteLine("");

                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");

                money = 0;
                adder = 1;
                mult = 1;
                prestige = 1;
                mega = 1;
                ultra = 1;
                cheated = 0;
                hackedtime = 0;
                timemult = 1;
                cheated_money = 0;
                bougth_timemult = 0;


                Console.WriteLine("A goblin stole all your money!");
                Console.WriteLine("You were also subtracted for not paying your taxes!");
                Console.WriteLine("And your multiplier, prestige multiplier, and ultra multiplier vanished!");
                Console.WriteLine("So you are back to step 1!");
                
                if (finish >= 1)
                {
                    Console.WriteLine("your secret multiplier got multiplied by 2 again and the finish went up by 1");
                }
                else
                {
                    Console.WriteLine("or did something else happen ???");
                }
                Console.WriteLine("");

                finish += 1;
                secret_mult *= 2;
                prestiges = 1;
                megas = 0;
                ultras = 0;
            }


            if (finish >= 10)
            {
                Console.WriteLine("well you truly finished my game thanks for playing");
                break;
            }
        }
    }
}