﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics.CodeAnalysis;

Console.WriteLine("Welcome to Type_Gainer");
Console.WriteLine("if you type -win- you will get money equal to your adder");
Console.WriteLine("if you type -multiply- you will multiply your money with youre multiplier");
Console.WriteLine("if you type -buy1- you money wil go down by 10 and youre adder will increase by 1");
Console.WriteLine("if you type -buy10- your money will go down by 100 and your adder will increase by 10");
Console.WriteLine("if you type -buy mult1- your money will go down by 100 and your multiplier will increase by 1");
Console.WriteLine("if you type -buy mult10- your money will go down by 1000 and your multiplier will increase by 10");
Console.WriteLine("if you type -prestige- your money, adder and multiplier will get set to the beginning values and you wil get a multiplier to the upgrades so instead of getting 1 you wil get it times 2 per prestige");
Console.WriteLine("if you type -ultra- your money, adder ,multiplier and prestige will get set to the beginning values and you wil get a multiplier to the others listed so instead of getting 1 of them you wil get it times 2 per ultra");

Console.WriteLine("if you type -help- you will see these again");
Console.WriteLine("");
double money = 0;
double gold = 0;
double mult = 1;
double adder = 1;
double prestige = 1;
int prestiges = 0;
double ultra = 1;
int ultras = 0;

while (gold <= 1e308)
{
    gold = money;
    Console.WriteLine("you own " + money + " money at the moment" );
    Console.WriteLine("and your adder is " + adder);
    Console.WriteLine("and your multiplier is " + mult);
    Console.WriteLine("and your prestige multiplier is " + prestige);
    Console.WriteLine("and you have done prestiges " + prestiges);
    Console.WriteLine("and your ultra multiplier is " + ultra);
    Console.WriteLine("and you have done " + ultras + " ultra's");
    Console.WriteLine("");


    //money gain text when you type win you get 1 money
    string userInput = Console.ReadLine();

    if (userInput.ToLower() == "help")
    {
        Console.WriteLine("if you type -win- you will get money equal to your adder");
        Console.WriteLine("if you type -multiply- you will multiply your money with youre multiplier");
        Console.WriteLine("if you type -buy1- you money wil go down by 10 and youre adder will increase by 1");
        Console.WriteLine("if you type -buy10- your money will go down by 100 and your adder will increase by 10");
        Console.WriteLine("if you type -buy mult1- your money will go down by 100 and your multiplier will increase by 1");
        Console.WriteLine("if you type -buy mult10- your money will go down by 1000 and your multiplier will increase by 10");
        Console.WriteLine("if you type -prestige- your money, adder and multiplier will get set to the beginning values and you wil get a multiplier to the upgrades so instead of getting 1 you wil get it times 2 per prestige");
        Console.WriteLine("if you type -ultra- your money, adder ,multiplier and prestige will get set to the beginning values and you wil get a multiplier to the others listed so instead of getting 1 of them you wil get it times 2 per ultra");


        Console.WriteLine("if you type -help- you will see these again");
        Console.WriteLine("");
    }


    // Check if user input is "win"
    if (userInput.ToLower() == "win")
    {
        // Increase money by 1
        money += adder;
        Console.WriteLine("You won! Your money increased by 1.");
        Console.WriteLine("");
    }

    if (userInput.ToLower() == "multiply")
    { 
        money *= mult;
      Console.WriteLine("you just multiplied your money by 2");
        Console.WriteLine("");
    }

    if(userInput.ToLower() == "buy mult1")
    { money -= 100;
        mult += 1 * prestige * ultra;      
    }

    if (userInput.ToLower() == "buy mult10")
    {
        money -= 1000;
        mult += 10 * prestige * ultra;
    }

    if (userInput.ToLower() == "buy1")
    {
        money -= 10;
        adder += 1 * prestige * ultra;
    }

    if (userInput.ToLower() == "buy10")
    {
        money -= 100;
        adder += 10 * prestige * ultra;
    }

    if (userInput.ToLower() =="prestige")
    {
        money = 0;
        adder = 1;
        mult = 1;
        prestige *= 2 * ultra;
        prestiges += 1;
    }

    if (userInput.ToLower() == "ultra")
    {
        money = 0;
        adder = 1;
        mult = 1;
        prestige = 1;
        ultra *= 2;
        ultras += 1;
    }


    if (money >= 1e307)
    {
        money = 0;
        adder = 1;
        mult = 1;
        prestige = 1;
        ultra = 1;

        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("a goblin stole all your money");
        Console.WriteLine("you were also subtracted for not paying your taxes");
        Console.WriteLine("and your multiplier, prestige multiplier and ulta multiplier vanished");
        Console.WriteLine("so you are back to step 1");
        
    }
    if (money >= 1e308)
    {
     break;
    }
}