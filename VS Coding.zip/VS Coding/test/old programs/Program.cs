﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to Type_Gainer");
        Console.WriteLine("Type '-help-' to see the available commands.");

        double money = 0;
        double mult = 1;
        double adder = 1;
        double prestige = 1;
        double ultra = 1;
        int prestiges = 0;
        int ultras = 0;

        while (true)
        {
            Console.WriteLine($"You own {money} money at the moment");
            Console.WriteLine($"Your adder is {adder}");
            Console.WriteLine($"Your multiplier is {mult}");
            Console.WriteLine($"Your prestige multiplier is {prestige}");
            Console.WriteLine($"You have done {prestiges} prestiges");
            Console.WriteLine($"Your ultra multiplier is {ultra}");
            Console.WriteLine($"You have done {ultras} ultra's");
            Console.WriteLine("");

            string userInput = Console.ReadLine().ToLower();

            switch (userInput)
            {
                case "help":
                    Console.WriteLine("Available commands:");
                    Console.WriteLine("- win: Get money equal to your adder");
                    Console.WriteLine("- multiply: Multiply your money with your multiplier");
                    Console.WriteLine("- buy1: Decrease money by 10 and increase adder by 1");
                    Console.WriteLine("- buy10: Decrease money by 100 and increase adder by 10");
                    Console.WriteLine("- buy mult1: Decrease money by 100 and increase multiplier by 1");
                    Console.WriteLine("- buy mult10: Decrease money by 1000 and increase multiplier by 10");
                    Console.WriteLine("- prestige: Reset money, adder, and multiplier to beginning values and increase prestige multiplier");
                    Console.WriteLine("- ultra: Reset money, adder, multiplier, and prestige to beginning values and increase ultra multiplier");
                    Console.WriteLine("- help: Display available commands");
                    Console.WriteLine("");
                    break;

                case "win":
                    money += adder;
                    Console.WriteLine("You won! Your money increased by 1.");
                    Console.WriteLine("");
                    break;

                case "multiply":
                    money *= mult;
                    Console.WriteLine("You just multiplied your money by 2");
                    Console.WriteLine("");
                    break;

                case "buy mult1":
                    if (money >= 100)
                    {
                        money -= 100;
                        mult += 1 * prestige * ultra;
                    }
                    else
                    {
                        Console.WriteLine("Insufficient funds!");
                        Console.WriteLine("");
                    }
                    break;

                case "buy mult10":
                    if (money >= 1000)
                    {
                        money -= 1000;
                        mult += 10 * prestige * ultra;
                    }
                    else
                    {
                        Console.WriteLine("Insufficient funds!");
                        Console.WriteLine("");
                    }
                    break;

                case "buy1":
                    if (money >= 10)
                    {
                        money -= 10;
                        adder += 1 * prestige * ultra;
                    }
                    else
                    {
                        Console.WriteLine("Insufficient funds!");
                        Console.WriteLine("");
                    }
                    break;

                case "buy10":
                    if (money >= 100)
                    {
                        money -= 100;
                        adder += 10 * prestige * ultra;
                    }
                    else
                    {
                        Console.WriteLine("Insufficient funds!");
                        Console.WriteLine("");
                    }
                    break;

                case "prestige":
                    if (money >= 1e6)
                    {
                        money = 0;
                        adder = 1;
                        mult = 1;
                        prestige *= 2;
                        prestiges += 1;
                    }
                    else
                    {
                        Console.WriteLine("You need at least 1e6 money to prestige!");
                        Console.WriteLine("");
                    }
                    break;

                case "ultra":
                    if (money >= 1e30)
                    {
                        money = 0;
                        adder = 1;
                        mult = 1;
                        prestige = 1;
                        ultra *= 2;
                        ultras += 1;
                    }
                    else
                    {
                        Console.WriteLine("You need at least 1e30 money to go ultra!");
                        Console.WriteLine("");
                    }
                    break;

                default:
                    Console.WriteLine("Invalid command. Type '-help-' for available commands.");
                    Console.WriteLine("");
                    break;
            }

            if (money >= 1e307)
            {
                money = 0;
                adder = 1;
                mult = 1;
                prestige = 1;
                ultra = 1;

                Console.WriteLine("A goblin stole all your money!");
                Console.WriteLine("You were also subtracted for not paying your taxes!");
                Console.WriteLine("And your multiplier, prestige multiplier, and ultra multiplier vanished!");
                Console.WriteLine("So you are back to step 1!");
                Console.WriteLine("");
            }

            if (money >= 1e308)
            {
                break;
            }
        }
    }
}