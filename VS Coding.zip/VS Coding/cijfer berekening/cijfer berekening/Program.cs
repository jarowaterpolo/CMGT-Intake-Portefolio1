﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("type in pointNM and pointBK then a = number");
double pointBK = 0;
double pointNM = 0;
double maxpointBK = 0;
double maxpointNM = 0;
double cijfer1  = 0;
double cijfer2 = 0;
double eindcijfer  = 0;
double trigger = 0;

maxpointNM += 8;
maxpointBK += 7;

while (true)
{
    string userInput = Console.ReadLine().ToLower();

    if (userInput.StartsWith("pointnm="))
    {
        string[] parts = userInput.Split('=');
        if (parts.Length == 2 && double.TryParse(parts[1], out pointNM))
        {
            cijfer1 = pointNM / maxpointNM * 3;
            Console.WriteLine("Jouw punt van Nieuwe Media is " + cijfer1);
            trigger += 1;
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter in the format 'pointNM=6'.");
        }
    }
    else if (userInput.StartsWith("pointbk="))
    {
        string[] parts = userInput.Split('=');
        if (parts.Length == 2 && double.TryParse(parts[1], out pointBK))
        {
            cijfer2 = pointBK / maxpointBK * 7 + 1;
            Console.WriteLine("Jouw punt van Beeldende Kunst is " + cijfer2);
            trigger += 1;
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter in the format 'pointBK=6'.");
        }
    }
    else
    {
        Console.WriteLine("Invalid command. Please enter 'pointNM=6' or 'pointBK=5' or something like that.");
    }

    if (trigger == 2)
    {
        eindcijfer = cijfer1 + cijfer2;
        Console.WriteLine("Jouw eindcijfer is een " + eindcijfer);
        trigger = 0; // Reset trigger after calculating eindcijfer
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("");
    }
}