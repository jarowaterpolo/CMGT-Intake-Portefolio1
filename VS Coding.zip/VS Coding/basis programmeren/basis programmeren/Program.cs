﻿// See https://aka.ms/new-console-template for more information
using System;

class Program
{
    static void Main(string[] args)
    {
        double points = 0;  // Initialize points
        while (true)         // Infinite loop
        {
            Console.WriteLine("Type 'win' to get +1 point (or type 'exit' to quit):");
            Console.WriteLine("");
           string input = Console.ReadLine();  // Read user input

            if (input.ToLower() == "win")
            {
                points += 1;  // Increment points if user types "win"
                Console.WriteLine($"You gained a point! Total points: {points}");
                Console.WriteLine("");
            }
            else if (input.ToLower() == "exit")
            {
                break;  // Exit the loop if user types "exit"
            }
            else
            {
                Console.WriteLine("Invalid input. Please type 'win' or 'exit'.");
            }
        }

        Console.WriteLine($"Final points: {points}");
        Console.WriteLine("");
    }
}
