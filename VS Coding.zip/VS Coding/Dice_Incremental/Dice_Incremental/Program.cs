﻿using System;
using System.Data;
using System.Data.SqlTypes;
using System.Security.Cryptography.X509Certificates;
// See https://aka.ms/new-console-template for more information
class Dice_IncrementalProgram
{
    static void Main(string[] args)
    {
        double gold = 10;
        int diceresult1 = 0;
        int diceresult2 = 0;
        int diceresult3 = 0;
        int dice1 = 0;
        int dice2 = 0;
        int dice3 = 0;
        int diceup1 = 0;
        int diceup2 = 0;
        int diceup3 = 0;
        int prestigechance = 0;
        double prestigemult = 1;
        int prestige = 0;

        Console.WriteLine("Welcome to Dice_Incremental");
        Console.WriteLine("Type '-help-' to see the available commands.");
        Console.WriteLine("");

        Console.WriteLine("");
        Console.WriteLine($"You own {gold} gold at the moment");
        Console.WriteLine("");

        while (true)
        {
            string userInput = Console.ReadLine().ToLower();
            Random random = new Random();
            
            if (gold >= 1e10)
            {
                Console.WriteLine("you can now buy updice3");
                Console.WriteLine("");
            }
            if (diceup3 >= 50)
            {
                diceup3 -= 50;
                Console.WriteLine("you just bougth to much to the power of so you got reset but now you have a chance to prestige ");
                Console.WriteLine("");
                prestigechance += 1;
            }
            

            switch (userInput)
            {
                case "help":
                    Console.WriteLine("Available commands:");
                    Console.WriteLine("- roll: Get gold equal to your diceresult");
                    Console.WriteLine("- buy dice1: Decrease gold by 10 add dice1");
                    Console.WriteLine("- buy dice2: Decrease gold by 100 add dice2");
                    Console.WriteLine("- buy dice3: Decrease gold by 1000 add dice3");
                    Console.WriteLine("- help: Display available commands");
                    Console.WriteLine("");
                    break;

                case "roll":
                    if (dice3 == 1 && dice2 == 1 && dice1 == 1)
                    {
                        Console.WriteLine("");
                        diceresult1 += random.Next(1, 7); 
                        diceresult2 += random.Next(1, 7); 
                        diceresult3 += random.Next(1, 7);
                        diceresult1 += diceup1;
                        diceresult2 += diceup2;
                        diceresult3 += diceup3;
                        double dicecombine = Math.Pow(diceresult2, diceresult3);

                        gold += diceresult1 * dicecombine;
                        Console.WriteLine("you rolled a " + diceresult1 + " with your first dice and a " + diceresult2 + " with your second and a " + diceresult3 + " with your third");
                        Console.WriteLine("so you got " + diceresult1 * dicecombine  + " gold");
                        diceresult1 = 0;
                        diceresult2 = 0;
                        diceresult3 = 0;
                        Console.WriteLine("you now own " + gold + " gold");
                        Console.WriteLine("");
                    }
                    else if (dice2 == 1 && dice1 == 1)
                    {
                        Console.WriteLine("");
                        diceresult1 += random.Next(1, 7); 
                        diceresult2 += random.Next(1, 7); 
                       
                        gold += (diceresult1 + diceup1) * (diceresult2 + diceup2);
                        Console.WriteLine("you rolled a " + diceresult1 + " with your first dice and a " + diceresult2 + " with your second");
                        Console.WriteLine("so you got " + diceresult1 * diceresult2 + " gold");
                        diceresult1 = 0;
                        diceresult2 = 0;
                        Console.WriteLine("you now own " + gold + " gold");
                        Console.WriteLine("");
                    }
                    else if (dice1 == 1)
                    {
                        Console.WriteLine("");
                        diceresult1 += random.Next(1, 7); 
                        gold += diceresult1 + diceup1;
                        Console.WriteLine("you rolled a " + diceresult1);
                        diceresult1 = 0;
                        Console.WriteLine("you now own " + gold + " gold");
                        Console.WriteLine("");
                    }
                    else
                    {
                        Console.WriteLine("you do not have any dice to roll ");
                        Console.WriteLine("");
                    }
                    break;

                case "buy dice1":
                    if (dice1 < 1)
                    {
                        if (gold >= 10)
                        {
                            Console.WriteLine("");
                            gold -= 10;
                            dice1 += 1;
                            Console.WriteLine("you now own " + gold + " gold");
                            Console.WriteLine("you now own dice 1 it will add its rolled number to your gold ");
                            Console.WriteLine("");
                        }
                        else
                        {
                            Console.WriteLine("you do not have enough gold you need atleast 10 gold");
                            Console.WriteLine("");
                        }
                    }
                    else
                    {
                            Console.WriteLine("you already own this dice");
                            Console.WriteLine("");
                    }
                    
                    
                    break;

                case "buy dice2":
                    if (dice2 < 1)
                    {
                        if (gold >= 100)
                        {
                            Console.WriteLine("");
                            gold -= 100;
                            dice2 += 1;
                            Console.WriteLine("you now own " + gold + " gold");
                            Console.WriteLine("you now own dice 2 it will multiply your first dice ");
                            Console.WriteLine("");
                        }
                        else
                        {
                            Console.WriteLine("you do not have enough gold you need atleast 100 gold");
                            Console.WriteLine("");
                        }
                    }
                    else
                    {
                        Console.WriteLine("you already own this dice");
                        Console.WriteLine("");
                    }                 
                    break;

                case "buy dice3":
                    if (dice3 < 1)
                    {
                        if (gold >= 1e3)
                        {
                            Console.WriteLine("");
                            gold -= 1e3;
                            dice3 += 1;
                            Console.WriteLine("you now own " + gold + " gold");
                            Console.WriteLine("you now own dice 3 it will power your second dice so if your second dice was 4 and your third is 2 then it would be 4 to the power of 2  ");
                            Console.WriteLine("");
                        }
                        else
                        {
                            Console.WriteLine("you do not have enough gold you need atleast 1e3 gold");
                            Console.WriteLine("");
                        }
                    }
                    else
                    {
                        Console.WriteLine("you already own this dice");
                        Console.WriteLine("");
                    }
                    break;

                case "buy updice1":
                    if (gold >= 1e5)
                    {
                        gold -= 1e5;
                        diceup1 += 6;
                        Console.WriteLine("you just bougth an upgrade for your first dice witch give you a +6 boost");
                        Console.WriteLine("");
                    }
                    else
                    {
                        Console.WriteLine("you do not have enough gold you need atleast 1e5");
                    }

                    break;

                case "buy updice2":
                    if (gold >= 1e6)
                    {
                        gold -= 1e6;
                        diceup2 += 6;
                        Console.WriteLine("you just bougth an upgrade for your second dice witch give you a +6 boost");
                        Console.WriteLine("");
                    }
                    else
                    {
                        Console.WriteLine("you do not have enough gold you need atleast 1e6");
                    }

                    break;

                case "buy updice3":
                    if (gold >= 1e10)
                    {
                        gold -= 1e10;
                        diceup3 += 6;
                        Console.WriteLine("you just bougth an upgrade for your third dice witch give you a +6 boost");
                        Console.WriteLine("");
                    }
                    else
                    {
                        Console.WriteLine("you do not have enough gold you need atleast 1e10");
                    }

                    break;

                case "prestige":
                    if (prestigechance == 1)
                    {
                        gold = 10;
                        dice1 = 0;
                        dice2 = 0;
                        dice3 = 0;
                        diceup1 = 0;
                        diceup2 = 0;
                        diceup3 = 0;
                        prestige += 1;
                        prestigemult *= 2;
                    }
                    break;

                default:
                    Console.WriteLine("Invalid command. Type '-help-' for available commands.");
                    Console.WriteLine("");
                    break;
            }

            
        }
    }
}


