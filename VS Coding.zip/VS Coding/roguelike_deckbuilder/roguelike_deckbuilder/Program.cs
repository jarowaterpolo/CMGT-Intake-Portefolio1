﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;

Console.WriteLine("Hello, And welcome by my text roguelike_deckbuilder");
Console.WriteLine("this is a beta version");
Console.WriteLine("in this version you wil start with 50 max_hp");
Console.WriteLine("you wil also have 8 starter cards and you have 4 different cards in your hand that you can play");
Console.WriteLine("you have 3 mana every time you play something you mana will go down by 1");
Console.WriteLine("you can write -help- to see all the usable commands");
Console.WriteLine("");
Console.WriteLine("first you have to start the run by typing -start-");
Console.WriteLine("");

//player
int gold = 0;
int goldgain = 0;
int gem = 0;
int gemgain = 0;
int dmg = 0;
double shield = 0;
int shieldgain = 10;
double hp = 1;
int max_hp = 1;
int mana = 3;
int poisongain = 0;
int poison = 0;
int buffvalue = 2;
int shieldboost = 0;


//enemy
double enemyhp = 20;
int enemymax_hp = 20;
int enemydmg = 5;
double enemyshield = 0;

//boss
double bosshp = 100;
int bossmax_hp = 100;
int bossdmg = 15;
double bossshield = 25;

//stage prog
int realstage = 0;
int stage = 0;
int shop = 0;
int healer = 0;
int max_hp_increaser = 0;
int goldring = 0;
int goldmult = 0;

//meta prog
int lostruns = 0;
int losecoins = 0;
double dmgmult = 1;
double shieldmult = 1;


double dmgresult = dmg * dmgmult;
double shieldgainresult = shieldgain * shieldmult;
//run start
bool startrun = false; // Flag to track whether the game has started



    while (true)
    {
    dmgresult = dmg * dmgmult;
    shieldgainresult = (shieldgain + shieldboost) * shieldmult;
    if (lostruns >= 1)
    {
        Console.WriteLine("");
        Console.WriteLine("your dmg multiplier is " + dmgmult + " at the moment");
        Console.WriteLine("your shield multiplier is " + shieldmult + " at the moment");
        Console.WriteLine("");
    }
    if (losecoins >= 1)
    {
        Console.WriteLine("");
        Console.WriteLine("you can buy a 1.25 times dmg multiplier for 5 losecoins by typing -buydmgmult-");
        Console.WriteLine("also");
        Console.WriteLine("you can buy a 1.25 times shield multiplier for 5 losecoins by typing -buyshieldmult-");
        Console.WriteLine("");
        Console.WriteLine("you have " + losecoins + " lose coins at the moment");
        Console.WriteLine("");
    }

    Console.WriteLine("");
    Console.WriteLine("");
        Console.WriteLine("you have " + mana + " mana");
        Console.WriteLine("you have " + hp + " hp out of the " + max_hp + " max_hp");
        Console.WriteLine("you have " + shield + " shield at the moment");
    Console.WriteLine("you will do " + dmgresult + " damage when you attack");
    Console.WriteLine("and you will gain " + shieldgainresult + " shield when you shield yourself");
    Console.WriteLine("");
    if (healer == 1)
    {
        Console.WriteLine("you also own the healer relic");
        Console.WriteLine("");
    }
    if (max_hp_increaser == 1)
    {
        Console.WriteLine("you also own the max_hp increaser relic");
        Console.WriteLine("");
    }
    if (goldring == 1)
    {
        Console.WriteLine("you also own the goldenring relic");
        Console.WriteLine("");
    }
    Console.WriteLine("card1 : buff dmg");
    Console.WriteLine("card2 : attack");
    Console.WriteLine("card3 : shield");
    Console.WriteLine("card4 : apply poison");
    Console.WriteLine("");
    Random random = new Random();

    //if (realstage == 10)
    //{
      //  if (bosshp <= 0)
        //{
          //  Console.Write("nextstage");
       // }
    //}
    //if (stage != 5 && realstage != 10)
    //{
      //  if (enemyhp <= 0)
        //{
          //  Console.Write("nextstage");
        //}
    //}

    string userInput = Console.ReadLine().ToLower();
        switch (userInput)
        {
            case "help":
                Console.WriteLine("-play1 : with this command you play the card in your first card slot");
                Console.WriteLine("when you play card 1 your dmg wil get buffed by 2");
            Console.WriteLine("");
            Console.WriteLine("-play2 : with this command you play the card in your second card slot");
            Console.WriteLine("when you play card 2 you will attack");
            Console.WriteLine("");
            Console.WriteLine("-play3 : with this command you play the card in your third card slot");
            Console.WriteLine("when you play card 3 you wil gain 10 shield");
            Console.WriteLine("");
            Console.WriteLine("-play4 : with this command you play the card in your fourth card slot");
                Console.WriteLine("when you play card 4 you will apply 5 poison to the enemy");
            Console.WriteLine("by typing -start- you will start the run");
            Console.WriteLine("by typing -next- the next turn will start");
            Console.WriteLine("by typing -nextstage- you will go to the next stage");
            Console.WriteLine("");
            Console.WriteLine("");

            break;

            case "start":
            if (!startrun)
            {
                bosshp = 0;
                enemyhp = 0;
                buffvalue = 2;
                shieldboost = 0;
                healer = 0;
                max_hp_increaser = 0;
                goldring = 0;
                max_hp = 50;
                hp = 50;
                dmg = 1;
                shieldgain = 10;
                poisongain = 5;
                stage = 1;
                realstage = 0;

                Console.WriteLine("you have encountered your first enemy");
                Console.WriteLine("it has " + enemyhp + " hp out of its " + enemymax_hp + " max_hp");
                Console.WriteLine("");
                Console.WriteLine("this turn the enemy will");

                // Generate a random number between 1 and 3
                int firstRandomNumber = random.Next(1, 4);

                // Perform action based on the random number
                if (firstRandomNumber == 1)
                {
                    Console.WriteLine("Attack!");
                    // Perform attack action
                    if (shield >= 1)
                    {
                        shield -= enemydmg;
                    }
                    else if (shield <= 0)
                    {
                        hp -= shield;
                        shield = 0;
                    }
                    else
                    {
                        hp -= enemydmg;
                    }
                }
                else if (firstRandomNumber == 2)
                {
                    Console.WriteLine("Shields itself!");
                    // Perform shield action
                    enemyshield += 10;
                }
                else if (firstRandomNumber == 3)
                {
                    Console.WriteLine("Buffs its damage!");
                    // Perform buff action
                    enemydmg += 5;
                }

                Console.WriteLine("the enemy now has " + enemyhp + "/" + enemymax_hp + " hp, " + enemyshield + " shield" + " and will do " + enemydmg + " dmg with his next attack");
                if (poison >= 1)
                {
                    Console.WriteLine("and has " + poison + " poison");
                }
                startrun = true; // Set the flag to indicate that the game has started
            }
            else
            {
                Console.WriteLine("The game has already started!");
            }
            break;

        case "card1":
            if (startrun)
            {
                if (mana >= 1)
                {
                    mana -= 1;
                    dmg += 2;
                    Console.WriteLine("you have just buffed your attack dmg by " + buffvalue);
                }     
                else
                {
                    Console.WriteLine("not enough mana");
                }
            }
            break;

        case "card2":
            if (startrun)
            {
                if (mana >= 1)
                {
                    mana -= 1;
                    if (enemyshield >= 1)
                    {
                        enemyshield -= dmgresult;
                    } else if (enemyshield <= 0)
                    {
                        enemyhp -= enemyshield;
                        enemyshield = 0;
                    }
                    else
                    {
                        enemyhp -= dmgresult;
                    }
                    if (bossshield >= 1)
                    {
                        bossshield -= dmgresult;
                    }
                    else if (bossshield <= 0)
                    {
                        bosshp -= bossshield;
                        bossshield = 0;
                    }
                    else
                    {
                        bosshp -= dmgresult;
                    }

                }
                else
                {
                    Console.WriteLine("not enough mana");
                }

                if (enemyhp >= 1)
                {
                    Console.WriteLine("you have just attacked the enemy for " + dmgresult + " damage");
                    Console.WriteLine("");
                    if (enemyhp >= 1)
                    {
                        Console.WriteLine("the enemy now has " + enemyhp + "/" + enemymax_hp + " hp, " + enemyshield + " shield" + " and will do " + enemydmg + " dmg with his next attack");
                        if (poison >= 1)
                        {
                            Console.WriteLine("and the enemy has " + poison + " poison at the moment");
                        }
                    }
                }
                if (bosshp >= 1)
                {
                    Console.WriteLine("you have just attacked the boss for " + dmgresult + " damage");
                    Console.WriteLine("");
                    if (bosshp >= 1)
                    {
                        Console.WriteLine("the boss now has " + bosshp + "/" + bossmax_hp + " hp, " + bossshield + " shield" + " and will do " + bossdmg + " dmg with his next attack");
                        if (poison >= 1)
                        {
                            Console.WriteLine("and the boss has " + poison + " poison at the moment");
                        }
                    }
                }
            }
            break;

        case "card3":
            if (startrun)
            {
                if (mana >= 1)
                {
                    mana -= 1;
                    shield += shieldgainresult;
                    Console.WriteLine("you have just shielded yourself with " + shieldgainresult + " shield");
                    
                }
                else
                {
                    Console.WriteLine("not enough mana");
                }

            }
            break;

        case "card4":
            if (startrun)
            {
                if (mana >= 1)
                {
                    mana -= 1;
                    poison += poisongain;
                    Console.WriteLine("you have just poisoned the enemy with " + poisongain + " poison");
                    Console.WriteLine("");
                    Console.WriteLine("the enemy now has " + enemyhp + "/" + enemymax_hp + " hp, " + enemyshield + " shield" + " and will do " + enemydmg + " dmg with his next attack");
                    if (poison >= 1)
                    {
                        Console.WriteLine("and the enemy has " + poison + " poison at the moment");
                    }
                }
                else
                {
                    Console.WriteLine("not enough mana");
                }
                
            }
            break;


        case "next":
            if (startrun)
            {
                enemyhp -= poison;
                bosshp -= poison;
                poison -= 1;
                mana += 3;
                Console.WriteLine("");
                if (realstage == 10)
                {
                    if(bosshp >= 1)
                    {
                        Console.WriteLine("this turn the boss will");
                        // Generate a random number between 1 and 3
                        int enemyRandomNumber = random.Next(1, 4);

                        // Perform action based on the random number
                        if (enemyRandomNumber == 1)
                        {
                            Console.WriteLine("Attack!");
                            // Perform attack action
                            if (shield >= 1)
                            {
                                shield -= bossdmg;
                            }
                            else if (shield <= 0)
                            {
                                hp -= shield;
                                shield = 0;
                            }
                            else
                            {
                                hp -= bossdmg;
                            }
                            
                        }
                        else if (enemyRandomNumber == 2)
                        {
                            Console.WriteLine("Shield itself!");
                            // Perform shield action
                            bossshield += 30;
                        }
                        else if (enemyRandomNumber == 3)
                        {
                            Console.WriteLine("Buff its damage!");
                            // Perform buff action
                            bossdmg += 15;
                        }


                        Console.WriteLine("the boss now has " + bosshp + "/" + bossmax_hp + " hp, " + bossshield + " shield" + " and will do " + bossdmg + " dmg with his next attack");
                        if (poison >= 1)
                        {
                            Console.WriteLine("and the boss has " + poison + " poison at the moment");
                        }
                    }
                    
                }
                else
                {
                    if (enemyhp >= 1)
                    {
                        Console.WriteLine("this turn the enemy will");

                        // Generate a random number between 1 and 3
                        int newRandomNumber = random.Next(1, 4);

                        // Perform action based on the random number
                        if (newRandomNumber == 1)
                        {
                            Console.WriteLine("Attack!");
                            // Perform attack action
                            if (shield >= 1)
                            {
                                shield -= enemydmg;
                            }
                            else if (shield <= 0)
                            {
                                hp -= shield;
                                shield = 0;
                            }
                            else
                            {
                                hp -= enemydmg;
                            }
                        }
                        else if (newRandomNumber == 2)
                        {
                            Console.WriteLine("Shield itself!");
                            // Perform shield action
                            enemyshield += 10;
                        }
                        else if (newRandomNumber == 3)
                        {
                            Console.WriteLine("Buff its damage!");
                            // Perform buff action
                            enemydmg += 5;
                        }

                        Console.WriteLine("the enemy now has " + enemyhp + "/" + enemymax_hp + " hp, " + enemyshield + " shield" + " and will do " + enemydmg + " dmg with his next attack");
                        if (poison >= 1)
                        {
                            Console.WriteLine("and the enemy has " + poison + " poison at the moment");
                        }
                    }
                    else
                    {
                        Console.WriteLine("");
                    }
                }
            }
            else
            {
                Console.WriteLine("You need to start the run first!");
            }
            break;



        case "buydmgmult":
            if (losecoins >= 5)
            {
                losecoins -= 5;
                dmgmult *= 1.25;
                Console.WriteLine("you have just spend 5 losecoins to get a 1.25 times dmg multiplier");
                Console.WriteLine("your dmg multiplier is " + dmgmult + " at the moment");
                Console.WriteLine("you still have " + losecoins + " losecoins");
            }
            else
            {
                Console.WriteLine("you do not have enough lose coins to buy a dmg multiplier ");
                Console.WriteLine("");
                Console.WriteLine("you have " + losecoins + " lose coins at the moment");
                Console.WriteLine("you need 5");
                Console.WriteLine("");
            }
            
            break;

        case "buyshieldmult":
            if (losecoins >= 5)
            {
                losecoins -= 5;
                shieldmult *= 1.25;
                Console.WriteLine("you have just spend 5 losecoins to get a 1.25 times shield multiplier");
                Console.WriteLine("your shield multiplier is " + shieldmult + " at the moment");
                Console.WriteLine("you still have " + losecoins + " losecoins");
            }
            else
            {
                Console.WriteLine("you do not have enough lose coins to buy a shield multiplier ");
                Console.WriteLine("");
                Console.WriteLine("you have " + losecoins + " lose coins at the moment");
                Console.WriteLine("you need 5");
                Console.WriteLine("");
            }

            break;

        case "nextstage":
            poison = 0;
            stage += 1;
            realstage += 1;
            if (healer == 1)
            {
                hp += 10;
            }
            if (max_hp_increaser == 1)
            {
                max_hp += 2;
            }
            
            if (stage == 5)
            {
                shop += 1;
                    if (shop == 1)
                {
                    Console.WriteLine("you have entered a shop");
                    Console.WriteLine("it has potion to heal 20 hp for sale for only 100 gold -buyheal-");
                    Console.WriteLine("it has a meal to increase you max_hp by 10 for sale for also only 100 gold -buymax_hp-");
                    Console.WriteLine("you can also upgrade your buff value by 2 for only 200 gold -buybuff-");
                    Console.WriteLine("you can also boost your shieldgain by 10 for only 200 gold -buyboost-");
                    Console.WriteLine("");
                    Console.WriteLine("you can also buy 1 of the 3 relics");
                    Console.WriteLine("relic 1: battle_healer you will heal 10 hp after each battle for only 10 gems -buyrelic1-");
                    Console.WriteLine("relic 2: max_hp increasing ring your max_hp wil increase with 2 after each battle for only 15 gems -buyrelic2-");
                    Console.WriteLine("relic 3: midas ring you wil gain 3 times the amount of gold for only 20 gems --buyrelic3");
                    Console.WriteLine("");
                    switch (userInput)
                    {
                        case "buyheal":
                            gold -= 100;
                            hp += 20;
                            break;

                        case "buymax_hp":
                            gold -= 100;
                            max_hp += 10;
                            break;

                        case "buybuff":
                            gold -= 200;
                            buffvalue += 2;
                            break;

                        case "buyboost":
                            gold -= 200;
                            shieldboost += 10;
                            break;
                        case "buyrelic1":
                            if (healer == 0)
                            {
                                gem -= 10;
                                healer += 1;
                            }
                            else
                            {
                                Console.WriteLine("you already have this relic");
                                Console.WriteLine("");
                            }
                            
                            break;

                        case "buyrelic2":
                            if (max_hp_increaser == 0)
                            {
                                gem -= 15;
                                max_hp_increaser += 1;
                            }
                            else
                            {
                                Console.WriteLine("you already have this relic");
                                Console.WriteLine("");
                            }
                            break;

                        case "buyrelic3":
                            if (goldring == 0)
                            {
                                gem -= 20;
                                goldring += 1;
                                goldmult += 3;
                            }
                            else
                            {
                                Console.WriteLine("you already have this relic");
                                Console.WriteLine("");
                            }
                            break;
                    }
                    stage -= 5;
                    shop -= 1;
                    } 
                
            }
            else if (realstage == 10)
            {
                bosshp = 100;
                bossmax_hp = 100;
                bossdmg = 15;
                bossshield = 25;
                Console.WriteLine("you have encountered an boss");
                Console.WriteLine("it has " + bosshp + " hp out of its " + bossmax_hp + " max_hp");
                Console.WriteLine("");
                Console.WriteLine("this turn it will");
                // Generate a random number between 1 and 3
                int enemyRandomNumber = random.Next(1, 4);

                // Perform action based on the random number
                if (enemyRandomNumber == 1)
                {
                    Console.WriteLine("Attack!");
                    // Perform attack action
                    if (shield >= 1)
                    {
                        shield -= bossdmg;
                    }
                    else if (shield <= 0)
                    {
                        hp -= shield;
                        shield = 0;
                    }
                    else
                    {
                        hp -= bossdmg;
                    }
                }
                else if (enemyRandomNumber == 2)
                {
                    Console.WriteLine("Shield itself!");
                    // Perform shield action
                    bossshield += 30;
                }
                else if (enemyRandomNumber == 3)
                {
                    Console.WriteLine("Buff its damage!");
                    // Perform buff action
                    bossdmg += 15;
                }


                Console.WriteLine("the boss now has " + bosshp + "/" + bossmax_hp + " hp, " + bossshield + " shield" + " and will do " + bossdmg + " dmg with his next attack");
                if (poison >= 1)
                {
                    Console.WriteLine("and the boss has " + poison + " poison at the moment");
                }
                realstage -= 10;
            } 
            else
            {
                enemyhp = 20;
                enemymax_hp = 20;
                enemydmg = 5;
                Console.WriteLine("you have encountered another enemy");
                Console.WriteLine("it has " + enemyhp + " hp out of its " + enemymax_hp + " max_hp");
                Console.WriteLine("");
                Console.WriteLine("this turn it will");
                // Generate a random number between 1 and 3
                int enemyRandomNumber = random.Next(1, 4);

                // Perform action based on the random number
                if (enemyRandomNumber == 1)
                {
                    Console.WriteLine("Attack!");
                    // Perform attack action
                    if (shield >= 1)
                    {
                        shield -= enemydmg;
                    }
                    else if (shield <= 0)
                    {
                        hp -= shield;
                        shield = 0;
                    }
                    else
                    {
                        hp -= enemydmg;
                    }
                }
                else if (enemyRandomNumber == 2)
                {
                    Console.WriteLine("Shield itself!");
                    // Perform shield action
                    enemyshield += 10;
                }
                else if (enemyRandomNumber == 3)
                {
                    Console.WriteLine("Buff its damage!");
                    // Perform buff action
                    enemydmg += 5;
                }


                Console.WriteLine("the enemy now has " + enemyhp + "/" + enemymax_hp + " hp, " + enemyshield + " shield" + " and will do " + enemydmg + " dmg with his next attack");
                if (poison >= 1)
                {
                    Console.WriteLine("and the enemy has " + poison + " poison at the moment");
                }
            }
            
            
            
    break;


        default:
                Console.WriteLine("Invalid command");
                break;
        }

    if (enemyhp <= 0)
    {
        int goldrandomNumber = random.Next(25, 101);
        if (goldrandomNumber >= 25) {
            goldgain = goldrandomNumber;
            gold += goldrandomNumber;
        }
        
        int gemrandomNumber = random.Next(1, 6);
        if (gemrandomNumber >= 1)
        {
            gemgain = gemrandomNumber;
            gem += gemrandomNumber;
        }
        
        Console.WriteLine("you have defeated this enemy");
        Console.WriteLine("as a reward you gain " + goldgain + " gold and " + gemgain + " gems");
        Console.WriteLine("");
        Console.WriteLine("you have " + gold + " gold");
        Console.WriteLine("you have " + gem + " gems");

    }

    if (bosshp <= 0)
    {
        int goldrandomNumber = random.Next(200, 501);
        if (goldrandomNumber >= 200)
        {
            goldgain = goldrandomNumber;
            gold += goldrandomNumber;
        }

        int gemrandomNumber = random.Next(8, 48);
        if (gemrandomNumber >= 8)
        {
            gemgain = gemrandomNumber;
            gem += gemrandomNumber;
        }

        Console.WriteLine("you have defeated this boss");
        Console.WriteLine("as a reward you gain " + goldgain + " gold and " + gemgain + " gems");
        Console.WriteLine("");
        Console.WriteLine("you have " + gold + " gold");
        Console.WriteLine("you have " + gem + " gems");

    }

    if (hp <= 0)
        {
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("");
        gold = 0;
            gem = 0;
            dmg = 0;
            shield = 0;
            mana = 3;
            enemyhp = 20;
            enemymax_hp = 20;
            enemydmg = 5;
            enemyshield = 0;
            poison = 0;

            losecoins += 1;
            lostruns += 1;
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("you just lost a run but do not worry you just got " + losecoins + " losecoins with these coins you can buy multipliers");
        Console.WriteLine("");
        Console.WriteLine("");
        
        hp = 1;
        startrun = false;
    }
    }

    // shield not working