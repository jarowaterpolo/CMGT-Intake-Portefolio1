﻿using System;
using System.Data;
using System.Data.SqlTypes;
using System.Security.Cryptography.X509Certificates;
// See https://aka.ms/new-console-template for more information
class TeachProgram
{
    static void Main(string[] args)
    {
        int step = 0;
        int trigger1 = 0;
        int help1 = 0;
        int help2 = 0;
        int help3 = 0;
        int help4 = 0;
        int help5 = 0;
        Console.WriteLine("Hello, Class!");
        Console.WriteLine("Here you will learn about programming ");
        Console.WriteLine("for this you need a scripting tool and a scripting language for this we are gonna use Visual Studio 2022 and C# ");
        Console.WriteLine("for the first step were gonna program a variable of choice ");
        Console.WriteLine("start off by choosing between a int, double or float ");
        Console.WriteLine("an int is a full number such as 1 the max of an int is 2147483647 and the min is -2147483647");
        Console.WriteLine("an float is a decimal number such as 0.1 the max of an float is 3.402823466E38 and the min is -1.175494351E38");
        Console.WriteLine("an double is a combination of a float and int but you can go way higher the max is 1.7976931348623157E308 and the min is -2.2250738585072014E308");
        Console.WriteLine("just type the one you like to use in ");


        
        Console.WriteLine("");
        Console.WriteLine("");
        Console.WriteLine("");

        while (true)
        {
            if (trigger1 >= 1) {
                Console.WriteLine("From now on were gonna program this in your own visual studio script");
                Console.WriteLine("Now you have chosen one of the above you can type anything you want, that will become your varible ");
                Console.WriteLine("For the example I will pick money and a double");
                Console.WriteLine("Now we will set it to a value we want such as 1 ");
                Console.WriteLine("I would look like this ( double money = 1;) ");
                Console.WriteLine("You can change the value by using ( +=, -= or =) ");
                Console.WriteLine("For example ( money += 1;) ");
                Console.WriteLine("Now you have created a varible I am gonna teach you how it will be visable in your game ");
                Console.WriteLine("It works almost the same as all of the text that you can see right now");
                Console.WriteLine("first we are gonna start of by learning the ( Console.WriteLine(); ) command ");
                Console.WriteLine("Try to make your game say ( You did it )");
                Console.WriteLine("if you dont get it to work type help1 ");
                Console.WriteLine("and if youre done and it works let us check and we will send you to the next step with nextstep");
                Console.WriteLine("");
                Console.WriteLine("");
                trigger1 = 0;
            }
            if (help1 >= 1)
            {
                Console.WriteLine("If you could not get it to work here is your answer ( Console.WriteLine(You did it)");
                Console.WriteLine("do not forget the (Double apostrophe) in the brackets and type your text in there ");
                Console.WriteLine("");
                Console.WriteLine("");
                help1 = 0;
            }
            if (step == 1)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Now you have learned the Console.WriteLine command were gonna put your varible in there");
                Console.WriteLine("try to put your varible in the command yourself otherwise we will help you again");
                Console.WriteLine("");
                Console.WriteLine("if you dont get it to work type help2 ");
                Console.WriteLine("and if youre done and it works let us check and we will send you to the next step with nextstep");
                Console.WriteLine("");
                Console.WriteLine("");
            }

            

            if (help2 >= 1)
            {
                Console.WriteLine("It would look something like this ( Console.WriteLine(you have + money + money);");
                Console.WriteLine("Because the first money is you varible and it will show its value the second will be in the Double apostophe and will literally say  money");
                Console.WriteLine("if you still don't understand please ask us for help");
                Console.WriteLine("");
                Console.WriteLine("");
                help2 = 0;
            }

            if (step == 2)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Well done now you have all these things you can already make the program say you varible and text");
                Console.WriteLine("The next step is learning how you can type something in your program so it will respond");
                Console.WriteLine("First i will start of by giving you guys some necessary commands");
                Console.WriteLine("while (true) { we are gonna work in this }");
                Console.WriteLine("You will first need ( string userInput = Console.ReadLine().ToLower(); ) ");
                Console.WriteLine("Second you will need ( switch (userInput) { we are gonna work in this } )");
                Console.WriteLine("And last ( case -something you want to type-: Console.WriteLine( something you want again ) break; )");
                Console.WriteLine("Now fill in the open gaps for yourself and try if it works otherwise ask for our help");
                Console.WriteLine("");
                Console.WriteLine("if you dont get it to work type help3 ");
                Console.WriteLine("and if youre done and it works let us check and we will send you to the next step with nextstep");
                Console.WriteLine("");
                Console.WriteLine("");
            }

           


            if (help3 >= 1)
            {
                Console.WriteLine("here is what it would look like:");
                Console.WriteLine("");
                Console.WriteLine("int hello = 0;");
                Console.WriteLine("");
                Console.WriteLine("while (true)");
                Console.WriteLine("{");
                Console.WriteLine("string userInput = Console.ReadLine().ToLower();");
                Console.WriteLine("");
                Console.WriteLine("switch (userInput)");
                Console.WriteLine("{");
                Console.WriteLine("");
                Console.WriteLine("case -hello-:");
                Console.WriteLine("Console.WriteLine(-hello how are you- + -you have said hello - + hello + - times-);");
                Console.WriteLine("break;");
                Console.WriteLine("}");
                Console.WriteLine("}");
                Console.WriteLine("if you still don't understand please ask us for help");
                Console.WriteLine("");
                Console.WriteLine("");
                help3 = 0;
            }

            if (step == 3)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("There is 1 next step but it is very advanced so if u want an extra point try your best");
                Console.WriteLine("Try to use the multiply command on your varible and/or try to implement an random number generator");
                Console.WriteLine("This is what I am gonna give you there is no more help than that in this file but you can ask us");
                Console.WriteLine("You atleast need *= and/or  Random random = new Random(); and random.Next(..., ...); ");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine(""); 
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
            }

            if (step == 4)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("There is no next step");
                Console.WriteLine("you have finnished our lesson");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("");
                step = 0;
            }


            if (help4 >= 1)
            {

                help4 = 0;
            }
            if (help5 >= 1)
            {

                help5 = 0;
            }

            string userInput = Console.ReadLine().ToLower();

            switch (userInput)
            {
                case "nextstep":
                    step += 1;
                    break;
                case "int":
                    trigger1 += 1;
                    break;

                case "double":
                    trigger1 += 1;
                    break;

                case "float":
                    trigger1 += 1;
                    break;

                case "help1":
                    help1 += 1;
                    break;

                case "help2":
                    help2 += 1;
                    break;

                case "help3":
                    help3 += 1;
                    break;

                case "help4":
                    help4 += 1;
                    break;

                case "help5":
                    help5 += 1;
                    break;


                default:
                    Console.WriteLine("Invalid command.");
                    Console.WriteLine("");
                    break;
            }
        }
    }
}

