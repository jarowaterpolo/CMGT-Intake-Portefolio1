﻿namespace roguelike
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enemy = new System.Windows.Forms.Button();
            this.enemyhp = new System.Windows.Forms.TextBox();
            this.tokens = new System.Windows.Forms.TextBox();
            this.playerattacktext = new System.Windows.Forms.TextBox();
            this.timesup = new System.Windows.Forms.Button();
            this.dmgup = new System.Windows.Forms.Button();
            this.playerhp = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.playerdefence = new System.Windows.Forms.TextBox();
            this.playerdmg = new System.Windows.Forms.TextBox();
            this.playertimes = new System.Windows.Forms.TextBox();
            this.enemyattacktext = new System.Windows.Forms.TextBox();
            this.defenceup = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // enemy
            // 
            this.enemy.BackgroundImage = global::roguelike.Properties.Resources.Goblin;
            this.enemy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.enemy.Location = new System.Drawing.Point(496, 8);
            this.enemy.Name = "enemy";
            this.enemy.Size = new System.Drawing.Size(175, 130);
            this.enemy.TabIndex = 0;
            this.enemy.UseVisualStyleBackColor = true;
            this.enemy.Click += new System.EventHandler(this.enemy_Click);
            // 
            // enemyhp
            // 
            this.enemyhp.BackColor = System.Drawing.Color.Red;
            this.enemyhp.Location = new System.Drawing.Point(532, 144);
            this.enemyhp.Name = "enemyhp";
            this.enemyhp.Size = new System.Drawing.Size(100, 26);
            this.enemyhp.TabIndex = 1;
            this.enemyhp.Text = "10 hp";
            // 
            // tokens
            // 
            this.tokens.BackColor = System.Drawing.Color.Goldenrod;
            this.tokens.Location = new System.Drawing.Point(688, 12);
            this.tokens.Name = "tokens";
            this.tokens.Size = new System.Drawing.Size(100, 26);
            this.tokens.TabIndex = 2;
            this.tokens.Text = "0 tokens";
            // 
            // playerattacktext
            // 
            this.playerattacktext.BackColor = System.Drawing.Color.Silver;
            this.playerattacktext.Location = new System.Drawing.Point(37, 27);
            this.playerattacktext.Name = "playerattacktext";
            this.playerattacktext.Size = new System.Drawing.Size(400, 26);
            this.playerattacktext.TabIndex = 3;
            this.playerattacktext.Text = "player log: you attack the enemy ... times for ... damage";
            // 
            // timesup
            // 
            this.timesup.Location = new System.Drawing.Point(810, 12);
            this.timesup.Name = "timesup";
            this.timesup.Size = new System.Drawing.Size(131, 145);
            this.timesup.TabIndex = 4;
            this.timesup.Text = "get multi attack \r\n(you attack +1 times)\r\n-1 token\r\ndamage X= 0.5\r\ntimes += 1";
            this.timesup.UseVisualStyleBackColor = true;
            this.timesup.Click += new System.EventHandler(this.timesup_Click);
            // 
            // dmgup
            // 
            this.dmgup.Location = new System.Drawing.Point(947, 12);
            this.dmgup.Name = "dmgup";
            this.dmgup.Size = new System.Drawing.Size(131, 145);
            this.dmgup.TabIndex = 5;
            this.dmgup.Text = "get buffed \r\n(you gain +1 damage)\r\n-1 token\r\ndamage += 1";
            this.dmgup.UseVisualStyleBackColor = true;
            this.dmgup.Click += new System.EventHandler(this.dmgup_Click);
            // 
            // playerhp
            // 
            this.playerhp.BackColor = System.Drawing.Color.Red;
            this.playerhp.Location = new System.Drawing.Point(37, 245);
            this.playerhp.Name = "playerhp";
            this.playerhp.Size = new System.Drawing.Size(100, 26);
            this.playerhp.TabIndex = 6;
            this.playerhp.Text = "10 hp";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.textBox2.Location = new System.Drawing.Point(37, 213);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 7;
            this.textBox2.Text = "your stats:\r\n";
            // 
            // playerdefence
            // 
            this.playerdefence.BackColor = System.Drawing.Color.Gray;
            this.playerdefence.Location = new System.Drawing.Point(37, 277);
            this.playerdefence.Name = "playerdefence";
            this.playerdefence.Size = new System.Drawing.Size(100, 26);
            this.playerdefence.TabIndex = 8;
            this.playerdefence.Text = "0 defence";
            // 
            // playerdmg
            // 
            this.playerdmg.BackColor = System.Drawing.Color.Gray;
            this.playerdmg.Location = new System.Drawing.Point(37, 309);
            this.playerdmg.Name = "playerdmg";
            this.playerdmg.Size = new System.Drawing.Size(100, 26);
            this.playerdmg.TabIndex = 9;
            this.playerdmg.Text = "1 dmg";
            // 
            // playertimes
            // 
            this.playertimes.BackColor = System.Drawing.Color.Gray;
            this.playertimes.Location = new System.Drawing.Point(31, 341);
            this.playertimes.Name = "playertimes";
            this.playertimes.Size = new System.Drawing.Size(112, 26);
            this.playertimes.TabIndex = 10;
            this.playertimes.Text = "attack 1 times";
            // 
            // enemyattacktext
            // 
            this.enemyattacktext.BackColor = System.Drawing.Color.Silver;
            this.enemyattacktext.Location = new System.Drawing.Point(37, 60);
            this.enemyattacktext.Name = "enemyattacktext";
            this.enemyattacktext.Size = new System.Drawing.Size(425, 26);
            this.enemyattacktext.TabIndex = 11;
            this.enemyattacktext.Text = "enemy log: the enemy attacked you ... times for ... damage";
            // 
            // defenceup
            // 
            this.defenceup.Location = new System.Drawing.Point(947, 163);
            this.defenceup.Name = "defenceup";
            this.defenceup.Size = new System.Drawing.Size(176, 145);
            this.defenceup.TabIndex = 12;
            this.defenceup.Text = "you train to get less damaged \r\n(you gain +1 defence)\r\n-1 token\r\ndefence += 1";
            this.defenceup.UseVisualStyleBackColor = true;
            this.defenceup.Click += new System.EventHandler(this.defenceup_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 450);
            this.Controls.Add(this.defenceup);
            this.Controls.Add(this.enemyattacktext);
            this.Controls.Add(this.playertimes);
            this.Controls.Add(this.playerdmg);
            this.Controls.Add(this.playerdefence);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.playerhp);
            this.Controls.Add(this.dmgup);
            this.Controls.Add(this.timesup);
            this.Controls.Add(this.playerattacktext);
            this.Controls.Add(this.tokens);
            this.Controls.Add(this.enemyhp);
            this.Controls.Add(this.enemy);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button enemy;
        private System.Windows.Forms.TextBox enemyhp;
        private System.Windows.Forms.TextBox tokens;
        private System.Windows.Forms.TextBox playerattacktext;
        private System.Windows.Forms.Button timesup;
        private System.Windows.Forms.Button dmgup;
        private System.Windows.Forms.TextBox playerhp;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox playerdefence;
        private System.Windows.Forms.TextBox playerdmg;
        private System.Windows.Forms.TextBox playertimes;
        private System.Windows.Forms.TextBox enemyattacktext;
        private System.Windows.Forms.Button defenceup;
    }
}

