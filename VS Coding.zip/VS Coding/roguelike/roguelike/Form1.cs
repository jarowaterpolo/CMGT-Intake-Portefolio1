﻿using System;
using System.Media;
using System.Windows.Forms;

namespace roguelike
{
    public partial class Form1 : Form
    {
        int hp = 10;
        int defence = 0;
        double badhp = 10;
        int token = 0;
        int times = 1;
        double dmg = 1;
        int enemydmg = 1;
        int enemytimes = 1;
        int turn = 0;

        public Form1()
        {
            InitializeComponent();
            start();
            // Initialize and start the timer
            Timer enemyCheckerTimer = new Timer();
            enemyCheckerTimer.Interval = 1; // 1000 milliseconds = 1 second
            enemyCheckerTimer.Tick += new EventHandler(EnemyCheckerTimer_Tick);
            enemyCheckerTimer.Start();
        }

        private void start()
        {
            playerhp.Text = hp.ToString() + " hp";
            enemyhp.Text = badhp.ToString() + " hp";
            tokens.Text = token.ToString() + " tokens";
        }

        private void enemy_Click(object sender, EventArgs e)
        {
            badhp -= dmg * times;

            if (turn >= 1)
            {
                hp -= (enemydmg -= defence) * enemytimes;
            }
            
            enemyhp.Text = badhp.ToString() + " hp";
            playerhp.Text = hp.ToString() + " hp";
            playerdefence.Text = defence.ToString() + " defence";

            playerattacktext.Text = "player log: you attacked the enemy " + times.ToString() + " times for " + dmg.ToString() + " damage";
            enemyattacktext.Text = "enemy log: the enemy attacked you " + enemytimes.ToString() + " times for " + enemydmg.ToString() + " damage";

            turn += 1;

            if (turn >= 10)
            {
                turn = 0;
            }
        }

        private void hpchecker()
        {
            if (badhp <= 0)
            {
                badhp = 10;
                token += 1;
                hp = 10;
                // Additional actions when enemy defeated
                playerhp.Text = hp.ToString() + " hp";
                enemyhp.Text = badhp.ToString() + " hp";
                tokens.Text = token.ToString() + " tokens";

            }

            if (hp <= 0)
            {
                hp = 10;
                token = 0;
                dmg = 1;
                times = 1;
                defence = 0;
                badhp = 10;
                enemydmg = 1;
                enemytimes = 1;
            }
        }

        private void textupdater()
        {
            playerhp.Text = hp + " hp";
            playerdefence.Text = defence + " defence";
            playerdmg.Text = dmg + " dmg";
            playertimes.Text = "attack " + times + " times";
        }
        private void EnemyCheckerTimer_Tick(object sender, EventArgs e)
        {
            hpchecker();
            textupdater();
        }

        private void timesup_Click(object sender, EventArgs e)
        {
            if (dmg >= 2)
            {
                if (token >= 1)
                {
                    token -= 1;
                    times += 1;
                    tokens.Text = token.ToString() + " tokens";
                    dmg *= 0.5;
                }
            }
        }

        private void dmgup_Click(object sender, EventArgs e)
        {
            if (token >= 1)
            {
                token -= 1;
                dmg += 1;
                tokens.Text = token.ToString() + " tokens";
            }
        }

        private void defenceup_Click(object sender, EventArgs e)
        {
            if (token >= 1)
            {
                token -= 1;
                defence += 1;
                tokens.Text = token.ToString() + " tokens";
                playerdefence.Text = defence.ToString() + " defence";
            }
        }
    }
}
