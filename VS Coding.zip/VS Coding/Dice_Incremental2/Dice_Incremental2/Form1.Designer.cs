﻿namespace Dice_Incremental2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Roll = new System.Windows.Forms.Button();
            this.GoldValue = new System.Windows.Forms.TextBox();
            this.dice1 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Upgrade1 = new System.Windows.Forms.Button();
            this.dice2 = new System.Windows.Forms.TextBox();
            this.dice3 = new System.Windows.Forms.TextBox();
            this.dice4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.Upgrade2 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.xdice1 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.xdice2 = new System.Windows.Forms.TextBox();
            this.diceupgrade1 = new System.Windows.Forms.Button();
            this.diceupgrade2 = new System.Windows.Forms.Button();
            this.prestige = new System.Windows.Forms.Button();
            this.mult = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.autobuy1 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.prespoint = new System.Windows.Forms.TextBox();
            this.autobuy2 = new System.Windows.Forms.Button();
            this.autoup1 = new System.Windows.Forms.Button();
            this.autoup2 = new System.Windows.Forms.Button();
            this.prestigemultup1 = new System.Windows.Forms.Button();
            this.prestigepointmult = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Roll
            // 
            this.Roll.BackColor = System.Drawing.SystemColors.Highlight;
            this.Roll.Location = new System.Drawing.Point(234, 190);
            this.Roll.Name = "Roll";
            this.Roll.Size = new System.Drawing.Size(336, 76);
            this.Roll.TabIndex = 0;
            this.Roll.Text = "Roll";
            this.Roll.UseVisualStyleBackColor = false;
            this.Roll.Click += new System.EventHandler(this.Roll_Click);
            // 
            // GoldValue
            // 
            this.GoldValue.BackColor = System.Drawing.SystemColors.Highlight;
            this.GoldValue.ForeColor = System.Drawing.Color.Gold;
            this.GoldValue.Location = new System.Drawing.Point(308, 38);
            this.GoldValue.Multiline = true;
            this.GoldValue.Name = "GoldValue";
            this.GoldValue.Size = new System.Drawing.Size(164, 36);
            this.GoldValue.TabIndex = 1;
            this.GoldValue.Text = "Gold";
            this.GoldValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dice1
            // 
            this.dice1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dice1.Location = new System.Drawing.Point(214, 120);
            this.dice1.Name = "dice1";
            this.dice1.Size = new System.Drawing.Size(49, 26);
            this.dice1.TabIndex = 2;
            this.dice1.Text = "0";
            this.dice1.TextChanged += new System.EventHandler(this.dice1_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Highlight;
            this.textBox1.Location = new System.Drawing.Point(104, 120);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(67, 26);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "Gold+=";
            // 
            // Upgrade1
            // 
            this.Upgrade1.BackColor = System.Drawing.SystemColors.Highlight;
            this.Upgrade1.Location = new System.Drawing.Point(682, 12);
            this.Upgrade1.Name = "Upgrade1";
            this.Upgrade1.Size = new System.Drawing.Size(106, 98);
            this.Upgrade1.TabIndex = 4;
            this.Upgrade1.Text = "Buy + dice \r\n-10 gold\r\ndice += 1\r\n";
            this.Upgrade1.UseVisualStyleBackColor = false;
            this.Upgrade1.Click += new System.EventHandler(this.Upgrade1_Click);
            // 
            // dice2
            // 
            this.dice2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dice2.Location = new System.Drawing.Point(279, 120);
            this.dice2.Name = "dice2";
            this.dice2.Size = new System.Drawing.Size(49, 26);
            this.dice2.TabIndex = 5;
            this.dice2.Text = "0";
            this.dice2.TextChanged += new System.EventHandler(this.dice2_TextChanged);
            // 
            // dice3
            // 
            this.dice3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dice3.Location = new System.Drawing.Point(345, 120);
            this.dice3.Name = "dice3";
            this.dice3.Size = new System.Drawing.Size(47, 26);
            this.dice3.TabIndex = 6;
            this.dice3.Text = "0";
            this.dice3.TextChanged += new System.EventHandler(this.dice3_TextChanged);
            // 
            // dice4
            // 
            this.dice4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.dice4.Location = new System.Drawing.Point(402, 120);
            this.dice4.Name = "dice4";
            this.dice4.Size = new System.Drawing.Size(49, 26);
            this.dice4.TabIndex = 7;
            this.dice4.Text = "0";
            this.dice4.TextChanged += new System.EventHandler(this.dice4_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox2.Location = new System.Drawing.Point(197, 120);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(14, 26);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "(";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox3.Location = new System.Drawing.Point(256, 120);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(17, 26);
            this.textBox3.TabIndex = 9;
            this.textBox3.Text = "+";
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox4.Location = new System.Drawing.Point(327, 120);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(17, 26);
            this.textBox4.TabIndex = 10;
            this.textBox4.Text = "+";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox5.Location = new System.Drawing.Point(385, 120);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(17, 26);
            this.textBox5.TabIndex = 11;
            this.textBox5.Text = "+";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox6.Location = new System.Drawing.Point(447, 120);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(14, 26);
            this.textBox6.TabIndex = 12;
            this.textBox6.Text = ")";
            // 
            // Upgrade2
            // 
            this.Upgrade2.BackColor = System.Drawing.SystemColors.Highlight;
            this.Upgrade2.Location = new System.Drawing.Point(682, 120);
            this.Upgrade2.Name = "Upgrade2";
            this.Upgrade2.Size = new System.Drawing.Size(106, 98);
            this.Upgrade2.TabIndex = 13;
            this.Upgrade2.Text = "Buy X dice \r\n-100 gold\r\nX dice += 1\r\n";
            this.Upgrade2.UseVisualStyleBackColor = false;
            this.Upgrade2.Click += new System.EventHandler(this.Upgrade2_Click);
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox7.Location = new System.Drawing.Point(458, 120);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(17, 26);
            this.textBox7.TabIndex = 14;
            this.textBox7.Text = "X";
            // 
            // xdice1
            // 
            this.xdice1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.xdice1.Location = new System.Drawing.Point(473, 120);
            this.xdice1.Name = "xdice1";
            this.xdice1.Size = new System.Drawing.Size(47, 26);
            this.xdice1.TabIndex = 15;
            this.xdice1.Text = "0";
            this.xdice1.TextChanged += new System.EventHandler(this.xdice1_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox8.Location = new System.Drawing.Point(517, 120);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(17, 26);
            this.textBox8.TabIndex = 16;
            this.textBox8.Text = "X";
            // 
            // xdice2
            // 
            this.xdice2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.xdice2.Location = new System.Drawing.Point(533, 120);
            this.xdice2.Name = "xdice2";
            this.xdice2.Size = new System.Drawing.Size(50, 26);
            this.xdice2.TabIndex = 17;
            this.xdice2.Text = "0";
            this.xdice2.TextChanged += new System.EventHandler(this.xdice2_TextChanged);
            // 
            // diceupgrade1
            // 
            this.diceupgrade1.BackColor = System.Drawing.SystemColors.Highlight;
            this.diceupgrade1.Location = new System.Drawing.Point(794, 12);
            this.diceupgrade1.Name = "diceupgrade1";
            this.diceupgrade1.Size = new System.Drawing.Size(265, 98);
            this.diceupgrade1.TabIndex = 18;
            this.diceupgrade1.Text = "Buy + diceupgrade \r\n-1000 gold\r\ndice value += 1\r\nso instead of a 1-6 --> 2-7 --> " +
    "etc.\r\n";
            this.diceupgrade1.UseVisualStyleBackColor = false;
            this.diceupgrade1.Click += new System.EventHandler(this.diceupgrade1_Click);
            // 
            // diceupgrade2
            // 
            this.diceupgrade2.BackColor = System.Drawing.SystemColors.Highlight;
            this.diceupgrade2.Location = new System.Drawing.Point(794, 120);
            this.diceupgrade2.Name = "diceupgrade2";
            this.diceupgrade2.Size = new System.Drawing.Size(265, 98);
            this.diceupgrade2.TabIndex = 19;
            this.diceupgrade2.Text = "Buy X diceupgrade \r\n-10000 gold\r\ndice value += 1\r\nso instead of a 1-6 --> 2-7 -->" +
    " etc.\r\n";
            this.diceupgrade2.UseVisualStyleBackColor = false;
            this.diceupgrade2.Click += new System.EventHandler(this.diceupgrade2_Click);
            // 
            // prestige
            // 
            this.prestige.BackColor = System.Drawing.Color.Red;
            this.prestige.Location = new System.Drawing.Point(682, 235);
            this.prestige.Name = "prestige";
            this.prestige.Size = new System.Drawing.Size(377, 98);
            this.prestige.TabIndex = 20;
            this.prestige.Text = "Prestige\r\n-1e6 gold\r\nprestige multiplier X= 2 X multiplier\r\npresitge point += 1 X" +
    " point multiplier";
            this.prestige.UseVisualStyleBackColor = false;
            this.prestige.Click += new System.EventHandler(this.prestige_Click);
            // 
            // mult
            // 
            this.mult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.mult.Location = new System.Drawing.Point(626, 120);
            this.mult.Name = "mult";
            this.mult.Size = new System.Drawing.Size(50, 26);
            this.mult.TabIndex = 21;
            this.mult.Text = "0";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox10.Location = new System.Drawing.Point(603, 120);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(17, 26);
            this.textBox10.TabIndex = 22;
            this.textBox10.Text = "X";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox11.Location = new System.Drawing.Point(177, 120);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(14, 26);
            this.textBox11.TabIndex = 23;
            this.textBox11.Text = "(";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.textBox12.Location = new System.Drawing.Point(583, 120);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(14, 26);
            this.textBox12.TabIndex = 24;
            this.textBox12.Text = ")";
            // 
            // autobuy1
            // 
            this.autobuy1.BackColor = System.Drawing.Color.Lime;
            this.autobuy1.Location = new System.Drawing.Point(1061, 12);
            this.autobuy1.Name = "autobuy1";
            this.autobuy1.Size = new System.Drawing.Size(106, 98);
            this.autobuy1.TabIndex = 25;
            this.autobuy1.Text = "Auto Buy + dice \r\n-1 prestige point\r\n\r\n";
            this.autobuy1.UseVisualStyleBackColor = false;
            this.autobuy1.Click += new System.EventHandler(this.autobuy1_Click);
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox9.Location = new System.Drawing.Point(682, 339);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(120, 26);
            this.textBox9.TabIndex = 26;
            this.textBox9.Text = "prestigepoints:\r\n";
            // 
            // prespoint
            // 
            this.prespoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.prespoint.Location = new System.Drawing.Point(808, 339);
            this.prespoint.Name = "prespoint";
            this.prespoint.Size = new System.Drawing.Size(50, 26);
            this.prespoint.TabIndex = 27;
            this.prespoint.Text = "0";
            this.prespoint.TextChanged += new System.EventHandler(this.prespoint_TextChanged);
            // 
            // autobuy2
            // 
            this.autobuy2.BackColor = System.Drawing.Color.Lime;
            this.autobuy2.Location = new System.Drawing.Point(1064, 120);
            this.autobuy2.Name = "autobuy2";
            this.autobuy2.Size = new System.Drawing.Size(106, 98);
            this.autobuy2.TabIndex = 28;
            this.autobuy2.Text = "Auto Buy X dice \r\n-2 prestige point\r\n\r\n";
            this.autobuy2.UseVisualStyleBackColor = false;
            this.autobuy2.Click += new System.EventHandler(this.autobuy2_Click);
            // 
            // autoup1
            // 
            this.autoup1.BackColor = System.Drawing.Color.Lime;
            this.autoup1.Location = new System.Drawing.Point(1173, 12);
            this.autoup1.Name = "autoup1";
            this.autoup1.Size = new System.Drawing.Size(106, 98);
            this.autoup1.TabIndex = 29;
            this.autoup1.Text = "Auto Buy + diceupgrade \r\n-3 prestige point\r\n\r\n";
            this.autoup1.UseVisualStyleBackColor = false;
            this.autoup1.Click += new System.EventHandler(this.autoup1_Click);
            // 
            // autoup2
            // 
            this.autoup2.BackColor = System.Drawing.Color.Lime;
            this.autoup2.Location = new System.Drawing.Point(1173, 120);
            this.autoup2.Name = "autoup2";
            this.autoup2.Size = new System.Drawing.Size(106, 98);
            this.autoup2.TabIndex = 30;
            this.autoup2.Text = "Auto Buy X diceupgrade \r\n-4 prestige point\r\n\r\n";
            this.autoup2.UseVisualStyleBackColor = false;
            this.autoup2.Click += new System.EventHandler(this.autoup2_Click);
            // 
            // prestigemultup1
            // 
            this.prestigemultup1.BackColor = System.Drawing.Color.OliveDrab;
            this.prestigemultup1.Location = new System.Drawing.Point(1064, 339);
            this.prestigemultup1.Name = "prestigemultup1";
            this.prestigemultup1.Size = new System.Drawing.Size(215, 98);
            this.prestigemultup1.TabIndex = 31;
            this.prestigemultup1.Text = "prestige multiplier multiplier\r\n-50 prestige point\r\nprestige multiplier X= 2\r\n";
            this.prestigemultup1.UseVisualStyleBackColor = false;
            this.prestigemultup1.Click += new System.EventHandler(this.prestigemultup1_Click);
            // 
            // prestigepointmult
            // 
            this.prestigepointmult.BackColor = System.Drawing.Color.OliveDrab;
            this.prestigepointmult.Location = new System.Drawing.Point(1065, 235);
            this.prestigepointmult.Name = "prestigepointmult";
            this.prestigepointmult.Size = new System.Drawing.Size(215, 98);
            this.prestigepointmult.TabIndex = 32;
            this.prestigepointmult.Text = "prestige point multiplier\r\n-10 prestige point\r\nprestige point X= 2\r\n";
            this.prestigepointmult.UseVisualStyleBackColor = false;
            this.prestigepointmult.Click += new System.EventHandler(this.prestigepointmult_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1315, 479);
            this.Controls.Add(this.prestigepointmult);
            this.Controls.Add(this.prestigemultup1);
            this.Controls.Add(this.autoup2);
            this.Controls.Add(this.autoup1);
            this.Controls.Add(this.autobuy2);
            this.Controls.Add(this.prespoint);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.autobuy1);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.mult);
            this.Controls.Add(this.prestige);
            this.Controls.Add(this.diceupgrade2);
            this.Controls.Add(this.diceupgrade1);
            this.Controls.Add(this.xdice2);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.xdice1);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.Upgrade2);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.dice4);
            this.Controls.Add(this.dice3);
            this.Controls.Add(this.dice2);
            this.Controls.Add(this.Upgrade1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dice1);
            this.Controls.Add(this.GoldValue);
            this.Controls.Add(this.Roll);
            this.Name = "Form1";
            this.Text = "Dice_Incremental";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Roll;
        private System.Windows.Forms.TextBox GoldValue;
        private System.Windows.Forms.TextBox dice1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Upgrade1;
        private System.Windows.Forms.TextBox dice2;
        private System.Windows.Forms.TextBox dice3;
        private System.Windows.Forms.TextBox dice4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button Upgrade2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox xdice1;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox xdice2;
        private System.Windows.Forms.Button diceupgrade1;
        private System.Windows.Forms.Button diceupgrade2;
        private System.Windows.Forms.Button prestige;
        private System.Windows.Forms.TextBox mult;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button autobuy1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox prespoint;
        private System.Windows.Forms.Button autobuy2;
        private System.Windows.Forms.Button autoup1;
        private System.Windows.Forms.Button autoup2;
        private System.Windows.Forms.Button prestigemultup1;
        private System.Windows.Forms.Button prestigepointmult;
    }
}

