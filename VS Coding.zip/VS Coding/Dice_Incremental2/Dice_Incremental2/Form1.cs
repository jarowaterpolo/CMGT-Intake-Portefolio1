﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Incremental2
{
    public partial class Form1 : Form
    {
        double gold = 0;
        int dice = 1;
        int xdice = 0;
        int diceresult1 = 0;
        int diceresult2 = 0;
        int diceresult3 = 0;
        int diceresult4 = 0;
        int xdiceresult1 = 0;
        int xdiceresult2 = 0;
        int diceup1 = 0;
        int diceup2 = 0;
        double prestigemult = 1;
        int prestigepoint = 0;
        int auto1 = 0;
        int auto2 = 0;
        int upauto1 = 0;
        int upauto2 = 0;
        double multiplier = 1;
        int pointmult = 1;
        int autocheck1 = 0;
        int autocheck2 = 0;
        int autocheck3 = 0;
        int autocheck4 = 0;
        int pointmultup = 0;

        private Timer timer;

        Random random = new Random();
        public Form1()
        {
            InitializeComponent();
            InitializeTimer();
        }

        
        private void InitializeTimer()
        {
            timer = new Timer();
            timer.Interval = 1000; // Interval in milliseconds (adjust as needed)
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            auto();
            finish();
        }


        private void Roll_Click(object sender, EventArgs e)
        {
            int firstRandomNumber = random.Next(1, 7);
            diceresult1 += firstRandomNumber += diceup1;
            int secondRandomNumber = random.Next(1, 7);
            diceresult2 += secondRandomNumber += diceup1;
            int thirdRandomNumber = random.Next(1, 7);
            diceresult3 += thirdRandomNumber += diceup1;
            int fourthRandomNumber = random.Next(1, 7);
            diceresult4 += fourthRandomNumber += diceup1;

            int firstxdiceresult = random.Next(1, 7);
            xdiceresult1 += firstxdiceresult += diceup2;
            int secondxdiceresult = random.Next(1, 7);
            xdiceresult2 += secondxdiceresult += diceup2;

            if (prestigemult >= 2)
            {
                if (xdice >= 1)
                {
                    if (xdice == 2)
                    {
                        gold += (diceresult1 + diceresult2 + diceresult3 + diceresult4) * xdiceresult1 * xdiceresult2 * prestigemult;
                        mult.Text = prestigemult.ToString();
                        xdice2.Text = xdiceresult2.ToString();
                        xdice1.Text = xdiceresult1.ToString();
                        dice4.Text = diceresult4.ToString();
                        dice3.Text = diceresult3.ToString();
                        dice2.Text = diceresult2.ToString();
                        dice1.Text = diceresult1.ToString();
                    }
                    else if (xdice == 1)
                    {
                        gold += (diceresult1 + diceresult2 + diceresult3 + diceresult4) * xdiceresult1 * prestigemult;
                        mult.Text = prestigemult.ToString();
                        xdice1.Text = xdiceresult1.ToString();
                        dice4.Text = diceresult4.ToString();
                        dice3.Text = diceresult3.ToString();
                        dice2.Text = diceresult2.ToString();
                        dice1.Text = diceresult1.ToString();
                    }
                }
                else if (xdice <= 0)
                {
                    if (dice == 4)
                    {
                        gold += ((diceresult1 + diceresult2 + diceresult3 + diceresult4) * prestigemult);
                        mult.Text = prestigemult.ToString();
                        dice4.Text = diceresult4.ToString();
                        dice3.Text = diceresult3.ToString();
                        dice2.Text = diceresult2.ToString();
                        dice1.Text = diceresult1.ToString();

                    }
                    else if (dice == 3)
                    {

                        gold += ((diceresult1 + diceresult2 + diceresult3) * prestigemult);
                        mult.Text = prestigemult.ToString();
                        dice3.Text = diceresult3.ToString();
                        dice2.Text = diceresult2.ToString();
                        dice1.Text = diceresult1.ToString();

                    }
                    else if (dice == 2)
                    {
                        gold += ((diceresult1 + diceresult2) * prestigemult);
                        mult.Text = prestigemult.ToString();
                        dice2.Text = diceresult2.ToString();
                        dice1.Text = diceresult1.ToString();
                    }

                    else if (dice == 1)
                    {

                        gold += diceresult1 * prestigemult;
                        mult.Text = prestigemult.ToString();
                        dice1.Text = diceresult1.ToString();
                    }

                }
            }
            else

            if (xdice >= 1)
            {
                if (xdice == 2)
                {
                    gold += (diceresult1 + diceresult2 + diceresult3 + diceresult4) * xdiceresult1 * xdiceresult2;
                    xdice2.Text = xdiceresult2.ToString();
                    xdice1.Text = xdiceresult1.ToString();
                    dice4.Text = diceresult4.ToString();
                    dice3.Text = diceresult3.ToString();
                    dice2.Text = diceresult2.ToString();
                    dice1.Text = diceresult1.ToString();
                } 
                else if (xdice == 1)
                {
                    gold += (diceresult1 + diceresult2 + diceresult3 + diceresult4) * xdiceresult1;
                    xdice1.Text = xdiceresult1.ToString();
                    dice4.Text = diceresult4.ToString();
                    dice3.Text = diceresult3.ToString();
                    dice2.Text = diceresult2.ToString();
                    dice1.Text = diceresult1.ToString();
                }
            } 
            else if (xdice <= 0)
            {
                if (dice == 4)
                {
                    gold += (diceresult1 + diceresult2 + diceresult3 + diceresult4);
                    dice4.Text = diceresult4.ToString();
                    dice3.Text = diceresult3.ToString();
                    dice2.Text = diceresult2.ToString();
                    dice1.Text = diceresult1.ToString();

                }
                else if (dice == 3)
                {

                    gold += (diceresult1 + diceresult2 + diceresult3);
                    dice3.Text = diceresult3.ToString();
                    dice2.Text = diceresult2.ToString();
                    dice1.Text = diceresult1.ToString();

                }
                else if (dice == 2)
                {
                    gold += (diceresult1 + diceresult2);
                    dice2.Text = diceresult2.ToString();
                    dice1.Text = diceresult1.ToString();
                }

                else if (dice == 1)
                {

                    gold += diceresult1;
                    dice1.Text = diceresult1.ToString();
                }
                
            }
            diceresult1 = 0;
            diceresult2 = 0;
            diceresult3 = 0;
            diceresult4 = 0;
            xdiceresult1 = 0;
            xdiceresult2 = 0;



            if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
            {
                GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
            }
            else
            {
                GoldValue.Text = gold.ToString() + " Gold"; // Format normally
            }
        }

        private void Upgrade1_Click(object sender, EventArgs e)
        {
            if (dice < 4)
            {
                if (gold >= 10)
                {
                    gold -= 10;
                    dice += 1;
                    if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
                    {
                        GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
                    }
                    else
                    {
                        GoldValue.Text = gold.ToString() + " Gold"; // Format normally
                    }
                }
            }
        }

        private void Upgrade2_Click(object sender, EventArgs e)
        {
            if (xdice < 2)
            {
                if (gold >= 100)
                {
                    gold -= 100;
                    xdice += 1;
                    if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
                    {
                        GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
                    }
                    else
                    {
                        GoldValue.Text = gold.ToString() + " Gold"; // Format normally
                    }
                }
            }
        }

        private void diceupgrade1_Click(object sender, EventArgs e)
        {
            if (gold >= 1000)
            {
                gold -= 1000;
                diceup1 += 1;
            }
        }

        private void diceupgrade2_Click(object sender, EventArgs e)
        {
            if (gold >= 10000)
            {
                gold -= 10000;
                diceup2 += 1;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void xdice2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dice2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dice3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dice4_TextChanged(object sender, EventArgs e)
        {

        }

        private void xdice1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dice1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void prestige_Click(object sender, EventArgs e)
        {
            if (gold >= 1e6)
            {
                gold = 0;
                dice = 1;
                xdice = 0;
                diceup1 = 0;
                diceup2 = 0;
                prestigemult *= 2 * multiplier;
                prestigepoint += 1 * pointmult;
                if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
                {
                    GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
                }
                else
                {
                    GoldValue.Text = gold.ToString() + " Gold"; // Format normally
                }
                prespoint.Text = prestigepoint + "";


                diceresult1 = 0;
                diceresult2 = 0;
                diceresult3 = 0;
                diceresult4 = 0;
                xdiceresult1 = 0;
                xdiceresult2 = 0;

                xdice2.Text = xdiceresult2.ToString();
                xdice1.Text = xdiceresult1.ToString();
                dice4.Text = diceresult4.ToString();
                dice3.Text = diceresult3.ToString();
                dice2.Text = diceresult2.ToString();
                dice1.Text = diceresult1.ToString();
            }
        }

        private void autobuy1_Click(object sender, EventArgs e)
        {
            if (autocheck1 == 0)
            {
                if (prestigepoint >= 1)
                {
                    prestigepoint -= 1;
                    auto1 += 1;
                    prespoint.Text = prestigepoint + "";
                    MessageBox.Show(" You now automaticly buy +dice ");
                    autocheck1 += 1;
                }
            }
            else
            {
                MessageBox.Show(" you already have this autobuyer");
            }
            
        }
        private void auto()
        {
            if (auto1 >= 1)
            {
                if (dice < 4)
                {
                    if (gold >= 10)
                    {
                        gold -= 10;
                        dice += 1;
                        if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
                        {
                            GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
                        }
                        else
                        {
                            GoldValue.Text = gold.ToString() + " Gold"; // Format normally
                        }
                    }
                }
            }

            if (auto2 >= 1)
            {
                if (xdice < 2)
                {
                    if (gold >= 100)
                    {
                        gold -= 100;
                        xdice += 1;
                        if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
                        {
                            GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
                        }
                        else
                        {
                            GoldValue.Text = gold.ToString() + " Gold"; // Format normally
                        }
                    }
                }
            }

            if (upauto1 >= 1)
            {
                    if (gold >= 1000)
                    {
                        gold -= 1000;
                        diceup1 += 1;
                    if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
                    {
                        GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
                    }
                    else
                    {
                        GoldValue.Text = gold.ToString() + " Gold"; // Format normally
                    }
                }
            }

            if (upauto2 >= 1)
            {
                    if (gold >= 10000)
                    {
                        gold -= 10000;
                        diceup2 += 1;
                    if (gold >= 1e6) // Check if gold is greater than or equal to 1,000,000
                    {
                        GoldValue.Text = gold.ToString("0.##E0") + " Gold"; // Format in scientific notation
                    }
                    else
                    {
                        GoldValue.Text = gold.ToString() + " Gold"; // Format normally
                    }
                }
            }
        }

        private void prespoint_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void autobuy2_Click(object sender, EventArgs e)
        {
            if (autocheck2 == 0)
            {
                if (prestigepoint >= 2)
                {
                    prestigepoint -= 2;
                    auto2 += 1;
                    prespoint.Text = prestigepoint + " ";
                    MessageBox.Show(" You now automaticly buy Xdice ");
                    autocheck2 += 1;
                }
            }
            else
            {
                MessageBox.Show(" you already have this autobuyer");
            }

        }

        private void autoup1_Click(object sender, EventArgs e)
        {
            if (autocheck3 == 0)
            {
                if (prestigepoint >= 3)
                {
                    prestigepoint -= 3;
                    upauto1 += 1;
                    prespoint.Text = prestigepoint + " ";
                    MessageBox.Show(" You now automaticly buy +dice upgrade");
                    autocheck3 += 1;
                }
            }
            else
            {
                MessageBox.Show(" you already have this autobuyer");
            }

        }

        private void autoup2_Click(object sender, EventArgs e)
        { 
            if (autocheck4 == 0)
            {
                if (prestigepoint >= 4)
                {
                    prestigepoint -= 4;
                    upauto2 += 1;
                    prespoint.Text = prestigepoint + " ";
                    MessageBox.Show(" You now automaticly buy Xdice upgrade");
                    autocheck4 += 1;
                }
            }
            else
            {
                MessageBox.Show(" you already have this autobuyer");
            }
        }

        private void prestigemultup1_Click(object sender, EventArgs e)
        {
            if (prestigepoint >= 50)
            {
                prestigepoint -= 50;
                prestigemult *= 2;
                multiplier *= 2;
                prespoint.Text = prestigepoint + " ";
            }

        }

        private void prestigepointmult_Click(object sender, EventArgs e)
        {
            if (pointmultup <= 20)
            {
                if (prestigepoint >= 10)
                {
                    prestigepoint -= 10;
                    pointmult *= 2;
                    prespoint.Text = prestigepoint + " ";
                    pointmultup += 1;
                }
            }
            else
            {
                MessageBox.Show(" you cant buy more ");
            }
            

        }

        private void finish()
        {
            if (gold >= 1e307)
            {
                gold = 0;
            }
        }
    }
}
