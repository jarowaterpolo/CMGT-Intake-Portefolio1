﻿namespace program_game_2024
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.silver_knight = new System.Windows.Forms.Button();
            this.attack = new System.Windows.Forms.Button();
            this.hptext = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dmgtext = new System.Windows.Forms.TextBox();
            this.goldtext = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.emdmgtext = new System.Windows.Forms.TextBox();
            this.emhptext = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.stageup = new System.Windows.Forms.Button();
            this.stageback = new System.Windows.Forms.Button();
            this.stagetext = new System.Windows.Forms.TextBox();
            this.stone_knight = new System.Windows.Forms.Button();
            this.wooden_knight = new System.Windows.Forms.Button();
            this.bronze_knight = new System.Windows.Forms.Button();
            this.gold_knight = new System.Windows.Forms.Button();
            this.diamond_knight = new System.Windows.Forms.Button();
            this.prestige = new System.Windows.Forms.Button();
            this.prestigebox = new System.Windows.Forms.GroupBox();
            this.ppmult = new System.Windows.Forms.TextBox();
            this.prestigestext = new System.Windows.Forms.TextBox();
            this.pptext = new System.Windows.Forms.TextBox();
            this.p_up_hp = new System.Windows.Forms.Button();
            this.p_up_dmg = new System.Windows.Forms.Button();
            this.startgold = new System.Windows.Forms.Button();
            this.p_up_gold = new System.Windows.Forms.Button();
            this.PrestigeUpgrades = new System.Windows.Forms.GroupBox();
            this.PrestigeStats = new System.Windows.Forms.GroupBox();
            this.startgoldtext = new System.Windows.Forms.TextBox();
            this.goldmulttext = new System.Windows.Forms.TextBox();
            this.dmgmulttext = new System.Windows.Forms.TextBox();
            this.hpmulttext = new System.Windows.Forms.TextBox();
            this.cheat = new System.Windows.Forms.Button();
            this.goldcheat = new System.Windows.Forms.Button();
            this.ultrabox = new System.Windows.Forms.GroupBox();
            this.ultramult = new System.Windows.Forms.TextBox();
            this.ultrastext = new System.Windows.Forms.TextBox();
            this.ultrapointtext = new System.Windows.Forms.TextBox();
            this.UltraStats = new System.Windows.Forms.GroupBox();
            this.prestigesmulttext = new System.Windows.Forms.TextBox();
            this.ppmulttext = new System.Windows.Forms.TextBox();
            this.UltraUpgrades = new System.Windows.Forms.GroupBox();
            this.u_up_pp = new System.Windows.Forms.Button();
            this.u_up_prestiges = new System.Windows.Forms.Button();
            this.ultra = new System.Windows.Forms.Button();
            this.pvp = new System.Windows.Forms.Button();
            this.bonestext = new System.Windows.Forms.TextBox();
            this.ultracheat = new System.Windows.Forms.Button();
            this.Cheats = new System.Windows.Forms.GroupBox();
            this.BoneUpgrades = new System.Windows.Forms.GroupBox();
            this.b_up_1 = new System.Windows.Forms.Button();
            this.b_up_2 = new System.Windows.Forms.Button();
            this.BoneStats = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.prestigebox.SuspendLayout();
            this.PrestigeUpgrades.SuspendLayout();
            this.PrestigeStats.SuspendLayout();
            this.ultrabox.SuspendLayout();
            this.UltraStats.SuspendLayout();
            this.UltraUpgrades.SuspendLayout();
            this.Cheats.SuspendLayout();
            this.BoneUpgrades.SuspendLayout();
            this.BoneStats.SuspendLayout();
            this.SuspendLayout();
            // 
            // silver_knight
            // 
            this.silver_knight.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.silver_knight.Location = new System.Drawing.Point(847, 67);
            this.silver_knight.Name = "silver_knight";
            this.silver_knight.Size = new System.Drawing.Size(168, 396);
            this.silver_knight.TabIndex = 0;
            this.silver_knight.Text = "Silver Knight";
            this.silver_knight.UseVisualStyleBackColor = false;
            this.silver_knight.Click += new System.EventHandler(this.silver_knight_Click);
            // 
            // attack
            // 
            this.attack.BackColor = System.Drawing.Color.Red;
            this.attack.Location = new System.Drawing.Point(26, 313);
            this.attack.Name = "attack";
            this.attack.Size = new System.Drawing.Size(287, 51);
            this.attack.TabIndex = 1;
            this.attack.Text = "ATTACK";
            this.attack.UseVisualStyleBackColor = false;
            this.attack.Click += new System.EventHandler(this.attack_Click);
            // 
            // hptext
            // 
            this.hptext.BackColor = System.Drawing.Color.Gray;
            this.hptext.ForeColor = System.Drawing.Color.Lime;
            this.hptext.Location = new System.Drawing.Point(6, 64);
            this.hptext.Name = "hptext";
            this.hptext.Size = new System.Drawing.Size(100, 20);
            this.hptext.TabIndex = 2;
            this.hptext.Text = "0/0 HP";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dmgtext);
            this.groupBox1.Controls.Add(this.hptext);
            this.groupBox1.Location = new System.Drawing.Point(26, 217);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(287, 90);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "player stats";
            // 
            // dmgtext
            // 
            this.dmgtext.BackColor = System.Drawing.Color.Gray;
            this.dmgtext.ForeColor = System.Drawing.Color.Red;
            this.dmgtext.Location = new System.Drawing.Point(181, 64);
            this.dmgtext.Name = "dmgtext";
            this.dmgtext.Size = new System.Drawing.Size(100, 20);
            this.dmgtext.TabIndex = 3;
            this.dmgtext.Text = "0 DMG";
            // 
            // goldtext
            // 
            this.goldtext.BackColor = System.Drawing.Color.Gray;
            this.goldtext.ForeColor = System.Drawing.Color.Gold;
            this.goldtext.Location = new System.Drawing.Point(234, 67);
            this.goldtext.Name = "goldtext";
            this.goldtext.Size = new System.Drawing.Size(79, 20);
            this.goldtext.TabIndex = 4;
            this.goldtext.Text = "0 Gold";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.emdmgtext);
            this.groupBox2.Controls.Add(this.emhptext);
            this.groupBox2.Location = new System.Drawing.Point(26, 121);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(287, 90);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "enemy stats";
            // 
            // emdmgtext
            // 
            this.emdmgtext.BackColor = System.Drawing.Color.Gray;
            this.emdmgtext.ForeColor = System.Drawing.Color.Red;
            this.emdmgtext.Location = new System.Drawing.Point(181, 64);
            this.emdmgtext.Name = "emdmgtext";
            this.emdmgtext.Size = new System.Drawing.Size(100, 20);
            this.emdmgtext.TabIndex = 3;
            this.emdmgtext.Text = "0 DMG";
            // 
            // emhptext
            // 
            this.emhptext.BackColor = System.Drawing.Color.Gray;
            this.emhptext.ForeColor = System.Drawing.Color.Lime;
            this.emhptext.Location = new System.Drawing.Point(6, 64);
            this.emhptext.Name = "emhptext";
            this.emhptext.Size = new System.Drawing.Size(100, 20);
            this.emhptext.TabIndex = 2;
            this.emhptext.Text = "0/0 HP";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.stageup);
            this.groupBox3.Controls.Add(this.stageback);
            this.groupBox3.Controls.Add(this.stagetext);
            this.groupBox3.Location = new System.Drawing.Point(26, 67);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(132, 48);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // stageup
            // 
            this.stageup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.stageup.Location = new System.Drawing.Point(102, 17);
            this.stageup.Name = "stageup";
            this.stageup.Size = new System.Drawing.Size(27, 23);
            this.stageup.TabIndex = 2;
            this.stageup.Text = "-->";
            this.stageup.UseVisualStyleBackColor = false;
            this.stageup.Click += new System.EventHandler(this.stageup_Click);
            // 
            // stageback
            // 
            this.stageback.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.stageback.Location = new System.Drawing.Point(4, 17);
            this.stageback.Name = "stageback";
            this.stageback.Size = new System.Drawing.Size(27, 23);
            this.stageback.TabIndex = 1;
            this.stageback.Text = "<--";
            this.stageback.UseVisualStyleBackColor = false;
            this.stageback.Click += new System.EventHandler(this.stageback_Click);
            // 
            // stagetext
            // 
            this.stagetext.BackColor = System.Drawing.Color.Gray;
            this.stagetext.ForeColor = System.Drawing.Color.Cyan;
            this.stagetext.Location = new System.Drawing.Point(37, 19);
            this.stagetext.Name = "stagetext";
            this.stagetext.Size = new System.Drawing.Size(59, 20);
            this.stagetext.TabIndex = 0;
            this.stagetext.Text = "Stage = 1";
            // 
            // stone_knight
            // 
            this.stone_knight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.stone_knight.ForeColor = System.Drawing.Color.White;
            this.stone_knight.Location = new System.Drawing.Point(499, 67);
            this.stone_knight.Name = "stone_knight";
            this.stone_knight.Size = new System.Drawing.Size(168, 396);
            this.stone_knight.TabIndex = 6;
            this.stone_knight.Text = "Stone Knight";
            this.stone_knight.UseVisualStyleBackColor = false;
            this.stone_knight.Click += new System.EventHandler(this.stone_knight_Click);
            // 
            // wooden_knight
            // 
            this.wooden_knight.BackColor = System.Drawing.Color.SaddleBrown;
            this.wooden_knight.ForeColor = System.Drawing.Color.White;
            this.wooden_knight.Location = new System.Drawing.Point(325, 67);
            this.wooden_knight.Name = "wooden_knight";
            this.wooden_knight.Size = new System.Drawing.Size(168, 396);
            this.wooden_knight.TabIndex = 7;
            this.wooden_knight.Text = "Wooden Knight";
            this.wooden_knight.UseVisualStyleBackColor = false;
            this.wooden_knight.Click += new System.EventHandler(this.wooden_knight_Click);
            // 
            // bronze_knight
            // 
            this.bronze_knight.BackColor = System.Drawing.Color.Chocolate;
            this.bronze_knight.ForeColor = System.Drawing.Color.White;
            this.bronze_knight.Location = new System.Drawing.Point(673, 67);
            this.bronze_knight.Name = "bronze_knight";
            this.bronze_knight.Size = new System.Drawing.Size(168, 396);
            this.bronze_knight.TabIndex = 8;
            this.bronze_knight.Text = "Bronze Knight";
            this.bronze_knight.UseVisualStyleBackColor = false;
            this.bronze_knight.Click += new System.EventHandler(this.bronze_knight_Click);
            // 
            // gold_knight
            // 
            this.gold_knight.BackColor = System.Drawing.Color.Goldenrod;
            this.gold_knight.Location = new System.Drawing.Point(1021, 67);
            this.gold_knight.Name = "gold_knight";
            this.gold_knight.Size = new System.Drawing.Size(168, 396);
            this.gold_knight.TabIndex = 9;
            this.gold_knight.Text = "Gold Knight";
            this.gold_knight.UseVisualStyleBackColor = false;
            this.gold_knight.Click += new System.EventHandler(this.gold_knight_Click);
            // 
            // diamond_knight
            // 
            this.diamond_knight.BackColor = System.Drawing.Color.Cyan;
            this.diamond_knight.Location = new System.Drawing.Point(1195, 67);
            this.diamond_knight.Name = "diamond_knight";
            this.diamond_knight.Size = new System.Drawing.Size(168, 396);
            this.diamond_knight.TabIndex = 10;
            this.diamond_knight.Text = "Diamond Knight";
            this.diamond_knight.UseVisualStyleBackColor = false;
            this.diamond_knight.Click += new System.EventHandler(this.diamond_knight_Click);
            // 
            // prestige
            // 
            this.prestige.BackColor = System.Drawing.Color.Gold;
            this.prestige.Location = new System.Drawing.Point(26, 370);
            this.prestige.Name = "prestige";
            this.prestige.Size = new System.Drawing.Size(287, 51);
            this.prestige.TabIndex = 11;
            this.prestige.Text = "PRESTIGE";
            this.prestige.UseVisualStyleBackColor = false;
            this.prestige.Click += new System.EventHandler(this.prestige_Click);
            // 
            // prestigebox
            // 
            this.prestigebox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.prestigebox.Controls.Add(this.ppmult);
            this.prestigebox.Controls.Add(this.prestigestext);
            this.prestigebox.Controls.Add(this.pptext);
            this.prestigebox.Location = new System.Drawing.Point(26, 484);
            this.prestigebox.Name = "prestigebox";
            this.prestigebox.Size = new System.Drawing.Size(287, 90);
            this.prestigebox.TabIndex = 4;
            this.prestigebox.TabStop = false;
            this.prestigebox.Text = "prestige stats";
            // 
            // ppmult
            // 
            this.ppmult.BackColor = System.Drawing.Color.Black;
            this.ppmult.ForeColor = System.Drawing.Color.SteelBlue;
            this.ppmult.Location = new System.Drawing.Point(125, 19);
            this.ppmult.Name = "ppmult";
            this.ppmult.Size = new System.Drawing.Size(123, 20);
            this.ppmult.TabIndex = 4;
            this.ppmult.Text = "Prestige Points mult = 1";
            // 
            // prestigestext
            // 
            this.prestigestext.BackColor = System.Drawing.Color.Black;
            this.prestigestext.ForeColor = System.Drawing.Color.SteelBlue;
            this.prestigestext.Location = new System.Drawing.Point(6, 45);
            this.prestigestext.Name = "prestigestext";
            this.prestigestext.Size = new System.Drawing.Size(102, 20);
            this.prestigestext.TabIndex = 3;
            this.prestigestext.Text = "0 Prestiges";
            // 
            // pptext
            // 
            this.pptext.BackColor = System.Drawing.Color.Black;
            this.pptext.ForeColor = System.Drawing.Color.SteelBlue;
            this.pptext.Location = new System.Drawing.Point(6, 19);
            this.pptext.Name = "pptext";
            this.pptext.Size = new System.Drawing.Size(102, 20);
            this.pptext.TabIndex = 2;
            this.pptext.Text = "0 Prestige Points";
            // 
            // p_up_hp
            // 
            this.p_up_hp.BackColor = System.Drawing.Color.Black;
            this.p_up_hp.ForeColor = System.Drawing.Color.SteelBlue;
            this.p_up_hp.Location = new System.Drawing.Point(6, 19);
            this.p_up_hp.Name = "p_up_hp";
            this.p_up_hp.Size = new System.Drawing.Size(168, 51);
            this.p_up_hp.TabIndex = 12;
            this.p_up_hp.Text = "HP X 2";
            this.p_up_hp.UseVisualStyleBackColor = false;
            this.p_up_hp.Click += new System.EventHandler(this.p_up_hp_Click);
            // 
            // p_up_dmg
            // 
            this.p_up_dmg.BackColor = System.Drawing.Color.Black;
            this.p_up_dmg.ForeColor = System.Drawing.Color.SteelBlue;
            this.p_up_dmg.Location = new System.Drawing.Point(180, 19);
            this.p_up_dmg.Name = "p_up_dmg";
            this.p_up_dmg.Size = new System.Drawing.Size(168, 51);
            this.p_up_dmg.TabIndex = 13;
            this.p_up_dmg.Text = "DMG X 2";
            this.p_up_dmg.UseVisualStyleBackColor = false;
            this.p_up_dmg.Click += new System.EventHandler(this.p_up_dmg_Click);
            // 
            // startgold
            // 
            this.startgold.BackColor = System.Drawing.Color.Black;
            this.startgold.ForeColor = System.Drawing.Color.SteelBlue;
            this.startgold.Location = new System.Drawing.Point(6, 76);
            this.startgold.Name = "startgold";
            this.startgold.Size = new System.Drawing.Size(168, 51);
            this.startgold.TabIndex = 14;
            this.startgold.Text = "Starting Gold + 500";
            this.startgold.UseVisualStyleBackColor = false;
            this.startgold.Click += new System.EventHandler(this.startgold_Click);
            // 
            // p_up_gold
            // 
            this.p_up_gold.BackColor = System.Drawing.Color.Black;
            this.p_up_gold.ForeColor = System.Drawing.Color.SteelBlue;
            this.p_up_gold.Location = new System.Drawing.Point(180, 78);
            this.p_up_gold.Name = "p_up_gold";
            this.p_up_gold.Size = new System.Drawing.Size(168, 51);
            this.p_up_gold.TabIndex = 15;
            this.p_up_gold.Text = "Gold X 2";
            this.p_up_gold.UseVisualStyleBackColor = false;
            this.p_up_gold.Click += new System.EventHandler(this.p_up_gold_Click);
            // 
            // PrestigeUpgrades
            // 
            this.PrestigeUpgrades.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PrestigeUpgrades.Controls.Add(this.p_up_hp);
            this.PrestigeUpgrades.Controls.Add(this.p_up_gold);
            this.PrestigeUpgrades.Controls.Add(this.p_up_dmg);
            this.PrestigeUpgrades.Controls.Add(this.startgold);
            this.PrestigeUpgrades.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PrestigeUpgrades.Location = new System.Drawing.Point(325, 469);
            this.PrestigeUpgrades.Name = "PrestigeUpgrades";
            this.PrestigeUpgrades.Size = new System.Drawing.Size(358, 147);
            this.PrestigeUpgrades.TabIndex = 16;
            this.PrestigeUpgrades.TabStop = false;
            this.PrestigeUpgrades.Text = "Prestige Upgrades";
            // 
            // PrestigeStats
            // 
            this.PrestigeStats.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PrestigeStats.Controls.Add(this.startgoldtext);
            this.PrestigeStats.Controls.Add(this.goldmulttext);
            this.PrestigeStats.Controls.Add(this.dmgmulttext);
            this.PrestigeStats.Controls.Add(this.hpmulttext);
            this.PrestigeStats.Location = new System.Drawing.Point(689, 469);
            this.PrestigeStats.Name = "PrestigeStats";
            this.PrestigeStats.Size = new System.Drawing.Size(152, 147);
            this.PrestigeStats.TabIndex = 5;
            this.PrestigeStats.TabStop = false;
            this.PrestigeStats.Text = "prestige upgrade stats";
            // 
            // startgoldtext
            // 
            this.startgoldtext.BackColor = System.Drawing.Color.Black;
            this.startgoldtext.ForeColor = System.Drawing.Color.SteelBlue;
            this.startgoldtext.Location = new System.Drawing.Point(6, 97);
            this.startgoldtext.Name = "startgoldtext";
            this.startgoldtext.Size = new System.Drawing.Size(140, 20);
            this.startgoldtext.TabIndex = 5;
            this.startgoldtext.Text = "starting gold = 0";
            // 
            // goldmulttext
            // 
            this.goldmulttext.BackColor = System.Drawing.Color.Black;
            this.goldmulttext.ForeColor = System.Drawing.Color.SteelBlue;
            this.goldmulttext.Location = new System.Drawing.Point(6, 71);
            this.goldmulttext.Name = "goldmulttext";
            this.goldmulttext.Size = new System.Drawing.Size(140, 20);
            this.goldmulttext.TabIndex = 4;
            this.goldmulttext.Text = "gold mult = 1";
            // 
            // dmgmulttext
            // 
            this.dmgmulttext.BackColor = System.Drawing.Color.Black;
            this.dmgmulttext.ForeColor = System.Drawing.Color.SteelBlue;
            this.dmgmulttext.Location = new System.Drawing.Point(6, 45);
            this.dmgmulttext.Name = "dmgmulttext";
            this.dmgmulttext.Size = new System.Drawing.Size(140, 20);
            this.dmgmulttext.TabIndex = 3;
            this.dmgmulttext.Text = "dmg mult = 1";
            // 
            // hpmulttext
            // 
            this.hpmulttext.BackColor = System.Drawing.Color.Black;
            this.hpmulttext.ForeColor = System.Drawing.Color.SteelBlue;
            this.hpmulttext.Location = new System.Drawing.Point(6, 19);
            this.hpmulttext.Name = "hpmulttext";
            this.hpmulttext.Size = new System.Drawing.Size(140, 20);
            this.hpmulttext.TabIndex = 2;
            this.hpmulttext.Text = "hp mult = 1";
            // 
            // cheat
            // 
            this.cheat.BackColor = System.Drawing.Color.Black;
            this.cheat.ForeColor = System.Drawing.Color.Chartreuse;
            this.cheat.Location = new System.Drawing.Point(847, 469);
            this.cheat.Name = "cheat";
            this.cheat.Size = new System.Drawing.Size(168, 44);
            this.cheat.TabIndex = 17;
            this.cheat.Text = "Cheat Mode = OFF";
            this.cheat.UseVisualStyleBackColor = false;
            this.cheat.Click += new System.EventHandler(this.cheat_Click);
            // 
            // goldcheat
            // 
            this.goldcheat.BackColor = System.Drawing.Color.Black;
            this.goldcheat.ForeColor = System.Drawing.Color.Chartreuse;
            this.goldcheat.Location = new System.Drawing.Point(6, 16);
            this.goldcheat.Name = "goldcheat";
            this.goldcheat.Size = new System.Drawing.Size(83, 44);
            this.goldcheat.TabIndex = 18;
            this.goldcheat.Text = "Gold + 1e8";
            this.goldcheat.UseVisualStyleBackColor = false;
            this.goldcheat.Click += new System.EventHandler(this.goldcheat_Click);
            // 
            // ultrabox
            // 
            this.ultrabox.BackColor = System.Drawing.Color.RosyBrown;
            this.ultrabox.Controls.Add(this.ultramult);
            this.ultrabox.Controls.Add(this.ultrastext);
            this.ultrabox.Controls.Add(this.ultrapointtext);
            this.ultrabox.Location = new System.Drawing.Point(26, 583);
            this.ultrabox.Name = "ultrabox";
            this.ultrabox.Size = new System.Drawing.Size(287, 90);
            this.ultrabox.TabIndex = 5;
            this.ultrabox.TabStop = false;
            this.ultrabox.Text = "ultra stats";
            // 
            // ultramult
            // 
            this.ultramult.BackColor = System.Drawing.Color.Black;
            this.ultramult.ForeColor = System.Drawing.Color.Salmon;
            this.ultramult.Location = new System.Drawing.Point(125, 19);
            this.ultramult.Name = "ultramult";
            this.ultramult.Size = new System.Drawing.Size(133, 20);
            this.ultramult.TabIndex = 4;
            this.ultramult.Text = "Ultra Points mult = 1";
            // 
            // ultrastext
            // 
            this.ultrastext.BackColor = System.Drawing.Color.Black;
            this.ultrastext.ForeColor = System.Drawing.Color.Salmon;
            this.ultrastext.Location = new System.Drawing.Point(6, 45);
            this.ultrastext.Name = "ultrastext";
            this.ultrastext.Size = new System.Drawing.Size(112, 20);
            this.ultrastext.TabIndex = 3;
            this.ultrastext.Text = "0 Ultras";
            // 
            // ultrapointtext
            // 
            this.ultrapointtext.BackColor = System.Drawing.Color.Black;
            this.ultrapointtext.ForeColor = System.Drawing.Color.Salmon;
            this.ultrapointtext.Location = new System.Drawing.Point(6, 19);
            this.ultrapointtext.Name = "ultrapointtext";
            this.ultrapointtext.Size = new System.Drawing.Size(112, 20);
            this.ultrapointtext.TabIndex = 2;
            this.ultrapointtext.Text = "0 Ultra Points";
            // 
            // UltraStats
            // 
            this.UltraStats.BackColor = System.Drawing.Color.RosyBrown;
            this.UltraStats.Controls.Add(this.prestigesmulttext);
            this.UltraStats.Controls.Add(this.ppmulttext);
            this.UltraStats.Location = new System.Drawing.Point(689, 622);
            this.UltraStats.Name = "UltraStats";
            this.UltraStats.Size = new System.Drawing.Size(152, 175);
            this.UltraStats.TabIndex = 6;
            this.UltraStats.TabStop = false;
            this.UltraStats.Text = "ultra stats";
            // 
            // prestigesmulttext
            // 
            this.prestigesmulttext.BackColor = System.Drawing.Color.Black;
            this.prestigesmulttext.ForeColor = System.Drawing.Color.Salmon;
            this.prestigesmulttext.Location = new System.Drawing.Point(6, 45);
            this.prestigesmulttext.Name = "prestigesmulttext";
            this.prestigesmulttext.Size = new System.Drawing.Size(140, 20);
            this.prestigesmulttext.TabIndex = 3;
            this.prestigesmulttext.Text = "Prestiges mult = 1";
            // 
            // ppmulttext
            // 
            this.ppmulttext.BackColor = System.Drawing.Color.Black;
            this.ppmulttext.ForeColor = System.Drawing.Color.Salmon;
            this.ppmulttext.Location = new System.Drawing.Point(6, 19);
            this.ppmulttext.Name = "ppmulttext";
            this.ppmulttext.Size = new System.Drawing.Size(141, 20);
            this.ppmulttext.TabIndex = 2;
            this.ppmulttext.Text = "Preatige Points mult = 1";
            // 
            // UltraUpgrades
            // 
            this.UltraUpgrades.BackColor = System.Drawing.Color.RosyBrown;
            this.UltraUpgrades.Controls.Add(this.u_up_pp);
            this.UltraUpgrades.Controls.Add(this.u_up_prestiges);
            this.UltraUpgrades.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UltraUpgrades.Location = new System.Drawing.Point(325, 622);
            this.UltraUpgrades.Name = "UltraUpgrades";
            this.UltraUpgrades.Size = new System.Drawing.Size(358, 147);
            this.UltraUpgrades.TabIndex = 17;
            this.UltraUpgrades.TabStop = false;
            this.UltraUpgrades.Text = "Ultra Upgrades";
            // 
            // u_up_pp
            // 
            this.u_up_pp.BackColor = System.Drawing.Color.Black;
            this.u_up_pp.ForeColor = System.Drawing.Color.Salmon;
            this.u_up_pp.Location = new System.Drawing.Point(6, 19);
            this.u_up_pp.Name = "u_up_pp";
            this.u_up_pp.Size = new System.Drawing.Size(168, 51);
            this.u_up_pp.TabIndex = 12;
            this.u_up_pp.Text = "Prestige Points X 2";
            this.u_up_pp.UseVisualStyleBackColor = false;
            this.u_up_pp.Click += new System.EventHandler(this.u_up_pp_Click);
            // 
            // u_up_prestiges
            // 
            this.u_up_prestiges.BackColor = System.Drawing.Color.Black;
            this.u_up_prestiges.ForeColor = System.Drawing.Color.Salmon;
            this.u_up_prestiges.Location = new System.Drawing.Point(180, 19);
            this.u_up_prestiges.Name = "u_up_prestiges";
            this.u_up_prestiges.Size = new System.Drawing.Size(168, 51);
            this.u_up_prestiges.TabIndex = 13;
            this.u_up_prestiges.Text = "Prestiges X 2";
            this.u_up_prestiges.UseVisualStyleBackColor = false;
            this.u_up_prestiges.Click += new System.EventHandler(this.u_up_prestiges_Click);
            // 
            // ultra
            // 
            this.ultra.BackColor = System.Drawing.Color.Purple;
            this.ultra.Location = new System.Drawing.Point(26, 427);
            this.ultra.Name = "ultra";
            this.ultra.Size = new System.Drawing.Size(287, 51);
            this.ultra.TabIndex = 19;
            this.ultra.Text = "ULTRA";
            this.ultra.UseVisualStyleBackColor = false;
            this.ultra.Click += new System.EventHandler(this.ultra_Click);
            // 
            // pvp
            // 
            this.pvp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pvp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pvp.Location = new System.Drawing.Point(26, 679);
            this.pvp.Name = "pvp";
            this.pvp.Size = new System.Drawing.Size(287, 51);
            this.pvp.TabIndex = 20;
            this.pvp.Text = "TIME CHANGE?";
            this.pvp.UseVisualStyleBackColor = false;
            this.pvp.Click += new System.EventHandler(this.pvp_Click);
            // 
            // bonestext
            // 
            this.bonestext.BackColor = System.Drawing.Color.Black;
            this.bonestext.ForeColor = System.Drawing.Color.LightGray;
            this.bonestext.Location = new System.Drawing.Point(234, 95);
            this.bonestext.Name = "bonestext";
            this.bonestext.Size = new System.Drawing.Size(79, 20);
            this.bonestext.TabIndex = 21;
            this.bonestext.Text = "0 Bones";
            // 
            // ultracheat
            // 
            this.ultracheat.BackColor = System.Drawing.Color.Black;
            this.ultracheat.ForeColor = System.Drawing.Color.Chartreuse;
            this.ultracheat.Location = new System.Drawing.Point(6, 66);
            this.ultracheat.Name = "ultracheat";
            this.ultracheat.Size = new System.Drawing.Size(122, 40);
            this.ultracheat.TabIndex = 22;
            this.ultracheat.Text = "ultra and ultrapoint + 1";
            this.ultracheat.UseVisualStyleBackColor = false;
            this.ultracheat.Click += new System.EventHandler(this.ultracheat_Click);
            // 
            // Cheats
            // 
            this.Cheats.BackColor = System.Drawing.Color.Black;
            this.Cheats.Controls.Add(this.goldcheat);
            this.Cheats.Controls.Add(this.ultracheat);
            this.Cheats.ForeColor = System.Drawing.Color.Chartreuse;
            this.Cheats.Location = new System.Drawing.Point(847, 519);
            this.Cheats.Name = "Cheats";
            this.Cheats.Size = new System.Drawing.Size(168, 154);
            this.Cheats.TabIndex = 23;
            this.Cheats.TabStop = false;
            this.Cheats.Text = "CHEATS";
            // 
            // BoneUpgrades
            // 
            this.BoneUpgrades.BackColor = System.Drawing.Color.DarkGray;
            this.BoneUpgrades.Controls.Add(this.b_up_1);
            this.BoneUpgrades.Controls.Add(this.b_up_2);
            this.BoneUpgrades.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BoneUpgrades.Location = new System.Drawing.Point(325, 775);
            this.BoneUpgrades.Name = "BoneUpgrades";
            this.BoneUpgrades.Size = new System.Drawing.Size(358, 147);
            this.BoneUpgrades.TabIndex = 18;
            this.BoneUpgrades.TabStop = false;
            this.BoneUpgrades.Text = "Bone Upgrades";
            // 
            // b_up_1
            // 
            this.b_up_1.BackColor = System.Drawing.Color.Black;
            this.b_up_1.ForeColor = System.Drawing.Color.Snow;
            this.b_up_1.Location = new System.Drawing.Point(6, 19);
            this.b_up_1.Name = "b_up_1";
            this.b_up_1.Size = new System.Drawing.Size(168, 51);
            this.b_up_1.TabIndex = 12;
            this.b_up_1.Text = "Prestige Points X 2";
            this.b_up_1.UseVisualStyleBackColor = false;
            // 
            // b_up_2
            // 
            this.b_up_2.BackColor = System.Drawing.Color.Black;
            this.b_up_2.ForeColor = System.Drawing.Color.Snow;
            this.b_up_2.Location = new System.Drawing.Point(180, 19);
            this.b_up_2.Name = "b_up_2";
            this.b_up_2.Size = new System.Drawing.Size(168, 51);
            this.b_up_2.TabIndex = 13;
            this.b_up_2.Text = "Prestiges X 2";
            this.b_up_2.UseVisualStyleBackColor = false;
            // 
            // BoneStats
            // 
            this.BoneStats.BackColor = System.Drawing.Color.DarkGray;
            this.BoneStats.Controls.Add(this.textBox1);
            this.BoneStats.Controls.Add(this.textBox2);
            this.BoneStats.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BoneStats.Location = new System.Drawing.Point(689, 803);
            this.BoneStats.Name = "BoneStats";
            this.BoneStats.Size = new System.Drawing.Size(152, 119);
            this.BoneStats.TabIndex = 7;
            this.BoneStats.TabStop = false;
            this.BoneStats.Text = "Bone stats";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Black;
            this.textBox1.ForeColor = System.Drawing.Color.Snow;
            this.textBox1.Location = new System.Drawing.Point(6, 45);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(140, 20);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "Prestiges mult = 1";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Black;
            this.textBox2.ForeColor = System.Drawing.Color.Snow;
            this.textBox2.Location = new System.Drawing.Point(6, 19);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(141, 20);
            this.textBox2.TabIndex = 2;
            this.textBox2.Text = "Preatige Points mult = 1";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1376, 962);
            this.Controls.Add(this.BoneStats);
            this.Controls.Add(this.BoneUpgrades);
            this.Controls.Add(this.Cheats);
            this.Controls.Add(this.bonestext);
            this.Controls.Add(this.pvp);
            this.Controls.Add(this.ultra);
            this.Controls.Add(this.UltraUpgrades);
            this.Controls.Add(this.UltraStats);
            this.Controls.Add(this.ultrabox);
            this.Controls.Add(this.cheat);
            this.Controls.Add(this.PrestigeStats);
            this.Controls.Add(this.PrestigeUpgrades);
            this.Controls.Add(this.prestigebox);
            this.Controls.Add(this.prestige);
            this.Controls.Add(this.diamond_knight);
            this.Controls.Add(this.gold_knight);
            this.Controls.Add(this.bronze_knight);
            this.Controls.Add(this.wooden_knight);
            this.Controls.Add(this.stone_knight);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.goldtext);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.attack);
            this.Controls.Add(this.silver_knight);
            this.Name = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.prestigebox.ResumeLayout(false);
            this.prestigebox.PerformLayout();
            this.PrestigeUpgrades.ResumeLayout(false);
            this.PrestigeStats.ResumeLayout(false);
            this.PrestigeStats.PerformLayout();
            this.ultrabox.ResumeLayout(false);
            this.ultrabox.PerformLayout();
            this.UltraStats.ResumeLayout(false);
            this.UltraStats.PerformLayout();
            this.UltraUpgrades.ResumeLayout(false);
            this.Cheats.ResumeLayout(false);
            this.BoneUpgrades.ResumeLayout(false);
            this.BoneStats.ResumeLayout(false);
            this.BoneStats.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button silver_knight;
        private System.Windows.Forms.Button attack;
        private System.Windows.Forms.TextBox hptext;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox dmgtext;
        private System.Windows.Forms.TextBox goldtext;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox emdmgtext;
        private System.Windows.Forms.TextBox emhptext;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button stageup;
        private System.Windows.Forms.Button stageback;
        private System.Windows.Forms.TextBox stagetext;
        private System.Windows.Forms.Button stone_knight;
        private System.Windows.Forms.Button wooden_knight;
        private System.Windows.Forms.Button bronze_knight;
        private System.Windows.Forms.Button gold_knight;
        private System.Windows.Forms.Button diamond_knight;
        private System.Windows.Forms.Button prestige;
        private System.Windows.Forms.GroupBox prestigebox;
        private System.Windows.Forms.TextBox prestigestext;
        private System.Windows.Forms.TextBox pptext;
        private System.Windows.Forms.TextBox ppmult;
        private System.Windows.Forms.Button p_up_hp;
        private System.Windows.Forms.Button p_up_dmg;
        private System.Windows.Forms.Button startgold;
        private System.Windows.Forms.Button p_up_gold;
        private System.Windows.Forms.GroupBox PrestigeUpgrades;
        private System.Windows.Forms.GroupBox PrestigeStats;
        private System.Windows.Forms.TextBox goldmulttext;
        private System.Windows.Forms.TextBox dmgmulttext;
        private System.Windows.Forms.TextBox hpmulttext;
        private System.Windows.Forms.TextBox startgoldtext;
        private System.Windows.Forms.Button cheat;
        private System.Windows.Forms.Button goldcheat;
        private System.Windows.Forms.GroupBox ultrabox;
        private System.Windows.Forms.TextBox ultramult;
        private System.Windows.Forms.TextBox ultrastext;
        private System.Windows.Forms.TextBox ultrapointtext;
        private System.Windows.Forms.GroupBox UltraStats;
        private System.Windows.Forms.TextBox prestigesmulttext;
        private System.Windows.Forms.TextBox ppmulttext;
        private System.Windows.Forms.GroupBox UltraUpgrades;
        private System.Windows.Forms.Button u_up_pp;
        private System.Windows.Forms.Button u_up_prestiges;
        private System.Windows.Forms.Button ultra;
        private System.Windows.Forms.Button pvp;
        private System.Windows.Forms.TextBox bonestext;
        private System.Windows.Forms.Button ultracheat;
        private System.Windows.Forms.GroupBox Cheats;
        private System.Windows.Forms.GroupBox BoneUpgrades;
        private System.Windows.Forms.Button b_up_1;
        private System.Windows.Forms.Button b_up_2;
        private System.Windows.Forms.GroupBox BoneStats;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}

