﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace program_game_2024
{
    public partial class Form1 : Form
    {
        //player
        double gold = 0;
        double dmg = 1;
        double hp = 2;
        double maxhp = 2;

        //enemy
        double emhp = 0;
        double emdmg = 0;
        double emmaxhp = 1;
        double stage = 1;

        //upgrade
        double upgradelvl = 0;
        double upmult = 0;

        //prestige
        double pp = 0;
        double prestiges = 0;
        double prestigemult = 1;
        double p_unlocker = 1;

        //prestige upgrade mults
        double hpmult = 1;
        double dmgmult = 1;
        double goldmult = 1;

        //ultra
        double up = 0;
        double ultras = 0;
        double ultrasmult = 1;
        double u_unlocker = 1;

        //ultra upgrades
        double u_ppmult = 1;
        double u_prestigesmult = 1;

        //starting gold
        double startinggold = 0;

        //cheats
        double cheat_toggle = 0;

        //pv p mode
        double savedhp = 1;
        double savedmaxhp = 1;
        double saveddmg = 1;
        double bones = 0;
        double timeswitch = 0;

        //starting stuff
        public Form1()
        {
            InitializeComponent();
            begin();
            playerupdate();
            enemyupdate();
            stageupdate();
            Timer();
        }

        public void begin()
        {
            emhp = 1;
            emdmg = 1;

            playerupdate();
            enemyupdate();
            stageupdate();
        }

        //basic button
        private void attack_Click(object sender, EventArgs e)
        {
            emhp -= dmg;
            hp -= emdmg;
            enemyupdate();
            playerupdate();

        }

        //buttons

        //stage switch
        private void stageup_Click(object sender, EventArgs e)
        {
            if (stage >= 0)
            {
                stage += 1;
            }
            stageupdate();
        }

        private void stageback_Click(object sender, EventArgs e)
        {
            if (stage >= 0)
            {
                stage -= 1;
            }
            stageupdate();
        }


        //basic upgrades
        private void mult10()
        {
            upgradelvl = Math.Pow(10, upmult);
            upgrade();
        }

        private void upgrade()
        {
            if (gold >= 5 * upgradelvl)
            {
                gold -= 5 * upgradelvl;
                dmg += 1 * upgradelvl * dmgmult;
                hp += 1 * upgradelvl * hpmult;
                maxhp += 1 * upgradelvl * hpmult;
                playerupdate();
            }
        }
        private void wooden_knight_Click(object sender, EventArgs e)
        {
            upmult = 0;
            mult10();
        }
        private void stone_knight_Click(object sender, EventArgs e)
        {
            upmult = 1;
            mult10();
        }
        private void bronze_knight_Click(object sender, EventArgs e)
        {
            upmult = 2;
            mult10();
        }

        private void silver_knight_Click(object sender, EventArgs e)
        {
            upmult = 3;
            mult10();
        }

        private void gold_knight_Click(object sender, EventArgs e)
        {
            upmult = 4;
            mult10();
        }

        private void diamond_knight_Click(object sender, EventArgs e)
        {
            upmult = 5;
            mult10();
        }

        //PRESTIGE
        private void prestige_Click(object sender, EventArgs e)
        {
            //player reset
            gold = (0 + startinggold) * goldmult;
            dmg = 1 * dmgmult;
            hp = 2 * hpmult;
            maxhp = 2 * hpmult;

            //enemy reset
            emhp = 0;
            emdmg = 0;
            emmaxhp = 1;
            stage = 1;

            //upgrade reset
            upgradelvl = 0;
            upmult = 0;

            //prestige gains
            pp += 1 * prestigemult * u_ppmult;
            prestiges += 1 * u_prestigesmult;

            //update text
            playerupdate();
            enemyupdate();
            stageupdate();
            prestigeupdate();
        }

        //ULTRA
        private void ultra_Click(object sender, EventArgs e)
        {
            //pv p change
            savedhp = hp;
            savedmaxhp = maxhp;
            saveddmg = dmg;



            //prestiges reset
            pp = 0;
            prestiges = 0;
            prestigemult = 1;
            p_unlocker = 1;

            //prestige upgrades reset
            hpmult = 1;
            dmgmult = 1;
            goldmult = 1;
            startinggold = 0;


            //player reset
            gold = (0 + startinggold) * goldmult;
            dmg = 1 * dmgmult;
            hp = 2 * hpmult;
            maxhp = 2 * hpmult;

            //enemy reset
            emhp = 0;
            emdmg = 0;
            emmaxhp = 1;
            stage = 1;

            //upgrade reset
            upgradelvl = 0;
            upmult = 0;

            //ultra gains
            up += 1 * ultrasmult;
            ultras += 1;

            


            //update text
            playerupdate();
            enemyupdate();
            stageupdate();
            prestigeupdate();
            ultraupdate();
        }

        //prestige upgrades
        private void p_up_hp_Click(object sender, EventArgs e)
        {
            if (pp >= 1)
            {
                hpmult *= 2;
                pp -= 1;
            }
            prestigeupdate();
            multupdate();
        }

        private void p_up_dmg_Click(object sender, EventArgs e)
        {
            if (pp >= 1)
            {
                dmgmult *= 2;
                pp -= 1;
            }

            prestigeupdate();
            multupdate();
        }

        private void startgold_Click(object sender, EventArgs e)
        {
            if (pp >= 1)
            {
                startinggold += 500;
                gold += 500;
                pp -= 1;
            }

            prestigeupdate();
            multupdate();
        }

        private void p_up_gold_Click(object sender, EventArgs e)
        {
            if (pp >= 1)
            {
                goldmult *= 2;
                gold *= 2;
                pp -= 1;
            }

            prestigeupdate();
            multupdate();
        }
        //cheat
        private void cheat_Click(object sender, EventArgs e)
        {
            cheat_toggle += 1;
        }

        private void goldcheat_Click(object sender, EventArgs e)
        {
            gold += 1e8;
        }
        private void ultracheat_Click(object sender, EventArgs e)
        {
            ultras += 1;
            up += 1;
            ultraupdate();
            ultraupgradeupdate();
        }

        //ultra upgrade
        private void u_up_pp_Click(object sender, EventArgs e)
        {
            if (up >= 1)
            {
                u_ppmult *= 2;
                up -= 1;
            }
            ultraupdate();
            ultraupgradeupdate();
        }
        private void u_up_prestiges_Click(object sender, EventArgs e)
        {
            if (up >= 1)
            {
                u_prestigesmult *= 2;
                up -= 1;
            }
            ultraupdate();
            ultraupgradeupdate();
        }

        //pvp stuff
        private void pvp_Click(object sender, EventArgs e)
        {
            timeswitch += 1;
            if (timeswitch == 1)
            {
                pvp.Text = "THE PAST";
                stage = -1;
                emmaxhp = savedmaxhp;
                emhp = savedhp;
                emdmg = saveddmg;
            }
            else if (timeswitch == 2)
            {
                pvp.Text = "THE FUTURE";
                stage = -2;
            }
            else if (timeswitch == 3)
            {
                pvp.Text = "DID THE " + "TIME CHANGE?";
                stage = 0;
                timeswitch = 0;
            }
        }

        //UPDATE STUFF
        private Timer timer;
        public void Timer()
        {
            timer = new Timer();
            timer.Tick += new EventHandler(Update);
            timer.Interval = 1; // in miliseconds
            timer.Start();
        }

        private void Update(object sender, EventArgs e)
        {
            //player death
            if (hp <= 0)
            {
                gold = (int)Math.Round(gold / 1.5);
                hp = maxhp;
                playerupdate();
                enemyupdate();
                stageupdate();
                prestigeupdate();
                ultraupdate();
                pvpupdate();
            }

            //enemy control
            if (stage >= 0)
            {
                if (emhp <= 0)
                {
                    if (stage >= 1)
                    {
                        emmaxhp = 0.5 * Math.Pow(2, stage);
                        emdmg = 0.5 * Math.Pow(2, stage);
                    }

                    gold += (0.5 * Math.Pow(2, stage)) * goldmult;
                    emhp = emmaxhp;
                    enemyupdate();
                } 

            }
            else if (stage == -1)
            {
                if (emhp <= 0)
                {
                    emmaxhp *= 100;
                    bones += 1;
                    emhp = emmaxhp;
                    enemyupdate();
                    pvpupdate();
                }
            }


            if (gold >= 5)
            {
                wooden_knight.Visible = true;
            }else
            {
                wooden_knight.Visible = false;
            }

            if (gold >= 50)
            {
                stone_knight.Visible = true;
                wooden_knight.Visible = false;
            }
            else
            {
                stone_knight.Visible = false;
            }

            if (gold >= 500)
            {
                bronze_knight.Visible = true;
                stone_knight.Visible = false;
            }
            else
            {
                bronze_knight.Visible = false;
            }

            if (gold >= 5000)
            {
                silver_knight.Visible = true;
                bronze_knight.Visible = false;
            }
            else
            {
                silver_knight.Visible = false;
            }

            if (gold >= 50000)
            {
                gold_knight.Visible = true;
                silver_knight.Visible = false;
            }
            else
            {
                gold_knight.Visible = false;
            }

            if (gold >= 500000)
            {
                diamond_knight.Visible = true;
                gold_knight.Visible = false;
            }
            else
            {
                diamond_knight.Visible = false;
            }

            if (gold >= 1e8)
            {
                prestige.Visible = true;
            }
            else
            {
                prestige.Visible = false;
            }

            if (goldmult >= 1e8)
            {
                prestige.Visible = false;
            }

            if (goldmult >= 1e8 & gold >= 1e15)
            {
                ultra.Visible = true;
            }
            else
            {
                ultra.Visible = false;
            }

            if (prestiges >= 1)
            {
                prestigebox.Visible = true;
                PrestigeUpgrades.Visible = true;
                PrestigeStats.Visible = true;
            }
            else
            {
                prestigebox.Visible = false;
                PrestigeUpgrades.Visible = false;
                PrestigeStats.Visible = false;
            }

            if (ultras >= 1)
            {
                ultrabox.Visible = true;
                UltraUpgrades.Visible = true;
                UltraStats.Visible = true;
            }
            else
            {
                ultrabox.Visible = false;
                UltraUpgrades.Visible = false;
                UltraStats.Visible = false;
            }

            if (prestiges >= 10 * p_unlocker)
            {
                prestigemult *= 2;
                p_unlocker += 1;
            }

            if (ultras >= 10 * u_unlocker)
            {
                ultrasmult *= 2;
                u_unlocker += 1;
            }

            if (cheat_toggle == 1)
            {
                //cheat button change
                cheat.Text = "Cheat Mode = ON";
                cheat.ForeColor = Color.Chartreuse;

                //cheat functions
                Cheats.Visible = true;
            }
            else
            {
                //cheat button change
                cheat.Text = "Cheat Mode = OFF";
                cheat.ForeColor = Color.Red;
                Cheats.Visible = false;
            }

            if (cheat_toggle >= 2)
            {
                cheat_toggle = 0;
            }

            if (bones >= 1)
            {
                bonestext.Visible = true;
            }
            else
            {
                bonestext.Visible = false;
            }

            playerupdate();
            enemyupdate();
            stageupdate();
            prestigeupdate();
            ultraupdate();
            pvpupdate();
        }

        //update text
        private string FormatLargeNumber(double value)
        {
            if (value >= 1e4)
                return value.ToString("0.##e0"); // Scientific notation with 2 decimal places
            return value.ToString(); // Regular formatting for smaller numbers
        }

        private void playerupdate()
        {
            goldtext.Text = FormatLargeNumber(gold) + " Gold";
            dmgtext.Text = FormatLargeNumber(dmg) + " DMG";
            hptext.Text = FormatLargeNumber(maxhp) + "/" + FormatLargeNumber(hp) + " HP";
        }

        private void enemyupdate()
        {
            goldtext.Text = FormatLargeNumber(gold) + " Gold";
            emhptext.Text = FormatLargeNumber(emmaxhp) + "/" + FormatLargeNumber(emhp) + " HP";
            emdmgtext.Text = FormatLargeNumber(emdmg) + " DMG";
        }

        private void stageupdate()
        {
            stagetext.Text = "Stage = " + FormatLargeNumber(stage);
        }

        private void prestigeupdate()
        {
            prestigestext.Text = FormatLargeNumber(prestiges) + " Prestiges";
            pptext.Text = FormatLargeNumber(pp) + " Prestige Points";
            ppmult.Text = "Prestige Point Mult = " + FormatLargeNumber(prestigemult);
        }

        public void multupdate()
        {
            hpmulttext.Text = "hp mult = " + FormatLargeNumber(hpmult);
            dmgmulttext.Text = "dmg mult = " + FormatLargeNumber(dmgmult);
            goldmulttext.Text = "gold mult = " + FormatLargeNumber(goldmult);
            startgoldtext.Text = "starting gold = " + FormatLargeNumber(startinggold);
        }

        public void ultraupdate()
        {
            ultrastext.Text = FormatLargeNumber(ultras) + " Ultras";
            ultrapointtext.Text = FormatLargeNumber(up) + " Ultra Points";
            ultramult.Text = "Ultra Point Mult = " + FormatLargeNumber (ultrasmult);
        }

        public void ultraupgradeupdate()
        {
            ppmulttext.Text = "Presitge Point Mult = " + FormatLargeNumber(u_ppmult);
            prestigesmulttext.Text = "Prestiges Mult = " + FormatLargeNumber(u_prestigesmult);
        }

        public void pvpupdate()
        {
            bonestext.Text = FormatLargeNumber(bones) + " Bones";
        }

    }
}
