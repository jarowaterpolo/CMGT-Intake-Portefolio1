﻿namespace aim_idle
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AimButton = new System.Windows.Forms.Button();
            this.PointsBox = new System.Windows.Forms.TextBox();
            this.MoneyReset = new System.Windows.Forms.Button();
            this.MoneyBox = new System.Windows.Forms.TextBox();
            this.MoneyUp1 = new System.Windows.Forms.Button();
            this.MultReset = new System.Windows.Forms.Button();
            this.cheat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AimButton
            // 
            this.AimButton.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.AimButton.ForeColor = System.Drawing.Color.Red;
            this.AimButton.Location = new System.Drawing.Point(500, 306);
            this.AimButton.Name = "AimButton";
            this.AimButton.Size = new System.Drawing.Size(100, 100);
            this.AimButton.TabIndex = 0;
            this.AimButton.Text = "X";
            this.AimButton.UseVisualStyleBackColor = false;
            this.AimButton.Click += new System.EventHandler(this.AimButton_Click);
            // 
            // PointsBox
            // 
            this.PointsBox.BackColor = System.Drawing.SystemColors.HotTrack;
            this.PointsBox.Location = new System.Drawing.Point(462, 10);
            this.PointsBox.Name = "PointsBox";
            this.PointsBox.Size = new System.Drawing.Size(138, 26);
            this.PointsBox.TabIndex = 1;
            this.PointsBox.Text = "points = ";
            // 
            // MoneyReset
            // 
            this.MoneyReset.BackColor = System.Drawing.Color.Red;
            this.MoneyReset.ForeColor = System.Drawing.Color.Black;
            this.MoneyReset.Location = new System.Drawing.Point(500, 200);
            this.MoneyReset.Name = "MoneyReset";
            this.MoneyReset.Size = new System.Drawing.Size(100, 100);
            this.MoneyReset.TabIndex = 2;
            this.MoneyReset.Text = "Reset for ... Money";
            this.MoneyReset.UseVisualStyleBackColor = false;
            this.MoneyReset.Click += new System.EventHandler(this.MoneyReset_Click);
            // 
            // MoneyBox
            // 
            this.MoneyBox.BackColor = System.Drawing.Color.Lime;
            this.MoneyBox.Location = new System.Drawing.Point(600, 10);
            this.MoneyBox.Name = "MoneyBox";
            this.MoneyBox.Size = new System.Drawing.Size(100, 26);
            this.MoneyBox.TabIndex = 3;
            this.MoneyBox.Text = "money = ";
            // 
            // MoneyUp1
            // 
            this.MoneyUp1.BackColor = System.Drawing.Color.Red;
            this.MoneyUp1.ForeColor = System.Drawing.Color.Black;
            this.MoneyUp1.Location = new System.Drawing.Point(700, 10);
            this.MoneyUp1.Name = "MoneyUp1";
            this.MoneyUp1.Size = new System.Drawing.Size(203, 86);
            this.MoneyUp1.TabIndex = 4;
            this.MoneyUp1.Text = "Points gained per hit +1\r\nCost: 1 money";
            this.MoneyUp1.UseVisualStyleBackColor = false;
            this.MoneyUp1.Click += new System.EventHandler(this.MoneyUp1_Click);
            // 
            // MultReset
            // 
            this.MultReset.BackColor = System.Drawing.Color.Red;
            this.MultReset.ForeColor = System.Drawing.Color.Black;
            this.MultReset.Location = new System.Drawing.Point(500, 100);
            this.MultReset.Name = "MultReset";
            this.MultReset.Size = new System.Drawing.Size(100, 100);
            this.MultReset.TabIndex = 5;
            this.MultReset.Text = "Reset for 2x Money mult";
            this.MultReset.UseVisualStyleBackColor = false;
            this.MultReset.Click += new System.EventHandler(this.MultReset_Click);
            // 
            // cheat
            // 
            this.cheat.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.cheat.ForeColor = System.Drawing.Color.Red;
            this.cheat.Location = new System.Drawing.Point(12, 10);
            this.cheat.Name = "cheat";
            this.cheat.Size = new System.Drawing.Size(100, 100);
            this.cheat.TabIndex = 6;
            this.cheat.Text = "cheat button";
            this.cheat.UseVisualStyleBackColor = false;
            this.cheat.Click += new System.EventHandler(this.cheat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 450);
            this.Controls.Add(this.cheat);
            this.Controls.Add(this.MultReset);
            this.Controls.Add(this.MoneyUp1);
            this.Controls.Add(this.MoneyBox);
            this.Controls.Add(this.MoneyReset);
            this.Controls.Add(this.PointsBox);
            this.Controls.Add(this.AimButton);
            this.Name = "Form1";
            this.Text = "window 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AimButton;
        private System.Windows.Forms.TextBox PointsBox;
        private System.Windows.Forms.Button MoneyReset;
        private System.Windows.Forms.TextBox MoneyBox;
        private System.Windows.Forms.Button MoneyUp1;
        private System.Windows.Forms.Button MultReset;
        private System.Windows.Forms.Button cheat;
    }
}

