﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace aim_idle
{

    public partial class Form1 : Form
    {
        double hitpoints = 1;
        double points = 0;
        double counter = 0;
        double resetmoney = 0;
        double money = 0;
        double moneymult = 1;
        double resetmoneymult = 0;
        double badmult = 1;


        private Timer timer;
        private Timer hoverTimer;
        Random random = new Random();
        public Form1()
        {
            InitializeComponent();
            InitializeTimers();
            this.AimButton.MouseEnter += new System.EventHandler(this.AimButton_MouseEnter);
            this.AimButton.MouseLeave += new System.EventHandler(this.AimButton_MouseLeave);

            //hovertimer
            hoverTimer = new Timer();
            hoverTimer.Interval = 10; // 100 ms interval, adjust as needed
            hoverTimer.Tick += new System.EventHandler(this.HoverTimer_Tick);
        }
        private void InitializeTimers()
        {
            //timer
            timer = new Timer();
            timer.Interval = 1; // Interval in milliseconds (adjust as needed)
            timer.Tick += Timer_Tick;
            timer.Start();

        }

        

        private void Timer_Tick(object sender, EventArgs e)
        {
            update();
        }

        private void AimButton_Click(object sender, EventArgs e)
        {
            points += hitpoints / badmult;
            counter += 1;

            //points shown
            if (points >= 1000)
            {
                PointsBox.Text = "points = " + points.ToString("0E0");
            }
            else
            {
                PointsBox.Text = "points = " + ((int)points).ToString();
            }

        }

        private void AimButton_MouseEnter(object sender, EventArgs e)
        {
            hoverTimer.Start();
        }

        private void AimButton_MouseLeave(object sender, EventArgs e)
        {
            hoverTimer.Stop();
        }

        private void HoverTimer_Tick(object sender, EventArgs e)
        {
            points += (Math.Pow(hitpoints, money) + 1) / badmult;
            counter += 1;

            //points shown
            if (points >= 1000)
            {
                PointsBox.Text = "points = " + points.ToString("0E0");
            }
            else
            {
                PointsBox.Text = "points = " + ((int)points).ToString();
            }
        }

        private void update()
        {
            if (counter >= 10) {
                int RandomNumber = random.Next(1, 4);
                if (RandomNumber == 1 )
                {
                    AimButton.Location = new Point(600, 300);
                } 
                else if (RandomNumber == 2)
                {
                    AimButton.Location = new Point(500, 300);
                }
                else if (RandomNumber == 3)
                {
                    AimButton.Location = new Point(400, 300);
                }
                else if (RandomNumber == 4)
                {
                    AimButton.Location = new Point(300, 300);
                }
                else if (RandomNumber == 5)
                {
                    AimButton.Location = new Point(200, 300);
                }
                else if (RandomNumber == 6)
                {
                    AimButton.Location = new Point(100, 300);
                }

                counter = 0;
            }

            //money reset
            if (points >= 10)
            {
                resetmoney = Math.Log(points, 100) * moneymult;
                MoneyReset.Visible = true;
                MoneyReset.Text = "Reset for "+ ((int)resetmoney).ToString() + " Money";
            }
            else
            {
                MoneyReset.Visible= false;
            }

            if (points >= 100)
            {
                MoneyReset.BackColor = Color.Green;
            }
            else
            {
                MoneyReset.BackColor = Color.Red;
            }

            if (money >= 1)
            {
                MoneyUp1.BackColor = Color.Green;
            }
            else
            {
                MoneyUp1.BackColor = Color.Red;
            }

            if (money < 1)
            {
                money = 0;
                MoneyBox.Text = "money = " + ((int)money).ToString();
            }

            //mult reset
            if (points >= 1e8)
            {
                //resetmoneymult = Math.Log(points, 1e10) * 2;
                resetmoneymult = Math.Pow(2, Math.Floor(Math.Log10(points) / 10));
                MultReset.Visible = true;
                MultReset.Text = "Reset for " + ((int)resetmoneymult).ToString() + "x Money mult";
            }
            else
            {
                MultReset.Visible = false;
            }

            if (points >= 1e10)
            {
                MultReset.BackColor = Color.Green;
            }
            else
            {
                MultReset.BackColor = Color.Red;
            }

            //max infin reset
            if (points >= 1e307)
            {
                money = 0;
                points = 0;
                hitpoints = 1;
                badmult *= 1e10;
                PointsBox.Text = "points = " + ((int)points).ToString();
                MoneyBox.Text = "money = " + ((int)money).ToString();
                MessageBox.Show("you had to much points you now get a 1e10 divider");
            }

            if (points <= 0)
            {
                points = 0;
                PointsBox.Text = "points = " + ((int)points).ToString();
            }

            if (badmult >= 1e307)
            {
                badmult = 1e300;
                PointsBox.Text = "points = " + ((int)points).ToString();
            }

        }

        private void MoneyReset_Click(object sender, EventArgs e)
        {
            if (resetmoney >= 1) {
                money = 0;
                money += resetmoney;
                points = 0;
                MoneyBox.Text = "money = " + ((int)money).ToString();
                PointsBox.Text = "points = " + ((int)points).ToString();

            }
            else
            {
                MessageBox.Show("you can't money reset yet try to reach at least 1");
            }
        }

        private void MoneyUp1_Click(object sender, EventArgs e)
        {
            if (money >= 1)
            {
                money -= 1;
                hitpoints += 1;
                MoneyBox.Text = "money = " + ((int)money).ToString();
            }
        }

        private void MultReset_Click(object sender, EventArgs e)
        {
            if (points >= 1e10)
            {
                moneymult *= resetmoneymult;
                money = 0;
                points = 0;
                hitpoints = 1;
                MoneyBox.Text = "money = " + ((int)money).ToString();
                PointsBox.Text = "points = " + ((int)points).ToString();

            }
            else
            {
                MessageBox.Show("you can't mult reset yet try to reach at least 2x");
            }
        }

        private void cheat_Click(object sender, EventArgs e)
        {
            money += 10;
        }
    }
}
