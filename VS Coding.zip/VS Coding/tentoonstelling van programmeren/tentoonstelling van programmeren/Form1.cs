﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tentoonstelling_van_programmeren
{
    public partial class Form1 : Form
    {
        public double num = 0;
        public double add = 1;
        

        public Form1()
        {
            InitializeComponent();
            UpdateNumberText();
            Timer Timer = new Timer();
            Timer.Interval = 1000; // Checks every 1000 milliseconds (1 second)
            Timer.Tick += CheckPoints;
            Timer.Start();
        }

        private void buttonnum_Click(object sender, EventArgs e)
        {
            num += add;
            UpdateNumberText();
        }

        private void buttonup_Click(object sender, EventArgs e)
        {
            if (num >= 10) 
            {
                num -= 10;
                add += 1;
                UpdateNumberText();
            }
        }

        private void CheckPoints(object sender, EventArgs e)
        {
            // Check if the points are higher than or equal to 1e6 (1,000,000)
            if (num >= 1e6)
            {
                // Do something when num reaches 1e6
                MessageBox.Show("Points have reached 1,000,000!");
                // You can add any other action here
            }
        }

        private void UpdateNumberText()
        {
            if (num >= 1000)
            {
                // Use scientific notation for numbers >= 1000
                number.Text = "€" + num.ToString("0.###E+0") + ",-";
            }
            else
            {
                // Regular formatting for numbers < 1000
                number.Text = "€" + num.ToString() + ",-";
            }
        }


    }

    
}
