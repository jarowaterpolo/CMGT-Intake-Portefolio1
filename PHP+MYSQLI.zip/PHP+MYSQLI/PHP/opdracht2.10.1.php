<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Formulier

    </titel>
</head>

<body>

    <?php 
    $profiel = $_POST["profiel"];

    switch($profiel){
        case "NT":
            echo "<h1> Natuur en Techniek </h1> <br> in dit profiel heb je: <br> wiskunde B, natuurkunde en scheikunde <br> en als je richting van computers heen wil kies dan informatica"
            break;
    }
    
    
    ?>

    <form method="post" action="resultaat.4.php">
        <p> voornaam: <input type="text" size="20" name="voornaam" > </p> <br>
        <p> achternaam: <input type="text" size="20" name="achternaam" > </p> <br>
        <p> geslacht: 
            <input type="radio" name="geslacht" value="man" checked > Mannelijk
            <input type="radio" name="geslacht" value="vrouw" > Vrouwelijk
            <input type="radio" name="geslacht" value="anders" > Anders
        </p>
        <p>profiel:
            <select name="profiel">
                <option value="NT">NT</option>
                <option value="NG">NG</option>
                <option value="EM">EM</option>
                <option value="CM">CM</option>
            </select>
        </p>
        <p>klas: <input type="text" size="20" name="klas"></p> <br>
        <p> geboortedatum: <input type="date" name="geboortedatum" > </p> <br>
        <input type="submit" value="Verstuur" >

    </form>

</body>
</html>