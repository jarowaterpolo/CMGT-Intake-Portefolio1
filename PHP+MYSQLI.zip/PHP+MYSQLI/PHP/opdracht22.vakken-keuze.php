<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php (codes)
    </titel>
</head>

<body>
<br>
<br>
    <form method="post" action="vakken-keuze-resultaat.php">

    <input type="checkbox" name="pakket[]"  value="WiA"> Wiskunde A<br>
    <input type="checkbox" name="pakket[]"  value="WiB"> Wiskunde B<br>
    <input type="checkbox" name="pakket[]"  value="Na"> Natuurkunde<br>
    <input type="checkbox" name="pakket[]"  value="Sk"> Scheikunde<br>
    <input type="checkbox" name="pakket[]"  value="Bio"> Biologie<br>
    <input type="checkbox" name="pakket[]"  value="Beco"> BedrijfsEconomie<br>
    <input type="checkbox" name="pakket[]"  value="Eco"> Economie<br>
    <input type="checkbox" name="pakket[]"  value="Ne"> Nederlands<br>
    <input type="checkbox" name="pakket[]"  value="En"> Engels<br>
    <input type="checkbox" name="pakket[]"  value="EnCa"> EngelsCamebridge<br>
    <input type="checkbox" name="pakket[]"  value="Inf"> Informatica<br>
    <input type="checkbox" name="pakket[]"  value="CKV"> Culturele Kunstzinnige Vorming<br>
    <input type="checkbox" name="pakket[]"  value="Lv"> Levensbeschouwelijke vorming<br>
    <input type="checkbox" name="pakket[]"  value="Maat"> Maatschappijleer<br>
    <input type="checkbox" name="pakket[]"  value="Sp"> Spaans<br>
    <input type="checkbox" name="pakket[]"  value="Fa"> Frans<br>
    <input type="checkbox" name="pakket[]"  value="Du"> Duits<br>

    <input type="submit" name="inleveren"  value="Kies Pakket"><br>
    
    </form>
    

</body>
</html>