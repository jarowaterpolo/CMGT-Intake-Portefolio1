<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Test php?

    </titel>
</head>

<body>
<br>
<br>
    <?php 
        $dagvdweek = date('D');
        echo "<h1>het is vandaag:" .$dagvdweek. "</h1>";
    ?>

</body>
</html>