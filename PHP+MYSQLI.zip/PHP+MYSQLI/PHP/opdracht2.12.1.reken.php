<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Formulier

    </titel>
</head>

<body>
    <form method="post" action="reken.antwoord.php">
        <p> <h1>Rekenmachine</h1>
        Getal_1: <input type="text" name="getal1" > <br>
        Getal_2: <input type="text" name="getal2" > <br>
        <select name="modifier">
                <option value="+">+</option>
                <option value="-">-</option>
                <option value="x">x</option>
                <option value="/">/</option>
                <option value="%">%</option>
                <option value="^">^</option>
                <option value=".">.</option>
        </select>
        </p>
        
        <input type="submit" value="Verstuur" >

    </form>

</body>
</html>