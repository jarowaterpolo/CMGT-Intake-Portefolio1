<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        ---
    </titel>
</head>

<body>
<br>
<br>
<?php
  $dagenpermaand = array(   "Januari" =>  "31", 
                            "Februari" =>  "28/29", 
                            "Maart" =>  "31", 
                            "April" =>  "30", 
                            "Mei" =>  "31", 
                            "Juni" =>  "30", 
                            "Juli" =>  "31", 
                            "Augustus" =>  "31", 
                            "September" =>  "30", 
                            "Oktober" =>  "31", 
                            "November" =>  "30", 
                            "December" =>  "31" 
);
    
foreach($dagenpermaand as $maand => $dag) {
    echo "in de maand " . $maand . " zitten " . $dag . " dagen.";
    echo " <br>\n";
}

    
?>
</body>
</html>