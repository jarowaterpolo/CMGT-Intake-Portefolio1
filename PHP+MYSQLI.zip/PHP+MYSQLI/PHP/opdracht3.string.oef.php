<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test string php
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    $naam = "jaro";
    $getaltext = " 2 ";
    $naam2 = " ImPortant";
    $getaltext2 = " 4 ";

    echo $naam;
    echo "<br>\n";
    echo $getaltext;
    echo "<br>\n";
    echo $naam2;
    echo "<br>\n";
    echo $getaltext2;
    echo "<br>\n";

    $combitext = $naam;
    $combitext .= $getaltext;
    $combitext .= $naam2;
    $combitext .= $getaltext2;

       //echo gettype($naam)."<br>\n";
       //echo gettype($getaltext)."<br>\n";

       echo "<hr>\n";
       echo $combitext;
      
    ?>
    <br />
    kleine letters: <?php echo strtolower($combitext); ?><br />
    hoofdletters: <?php echo strtoupper($combitext); ?><br />
    eerste letter zin hoofdletter: <?php echo ucfirst(strtolower($combitext)); ?><br />
    eerste letter woord hoofdletter: <?php echo ucwords(strtolower($combitext)); ?><br />
    <br/>
    aantal tekens: <?php echo strlen($combitext); ?><br />
    extra spatie skip: <?php echo $naam.trim($getaltext).trim($naam2).trim($getaltext2); ?><br />
    tekst zoeker: <?php echo strpos($combitext, "jaro"); ?><br />
    tekst vervanger: <?php echo str_replace("ImPortant", "Noa", $combitext); ?><br />

</body>
</html>