<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>antwoord</titel>
</head>

<body> 
<?php 
$getal1 = $_POST["getal1"];
$getal2 = $_POST["getal2"];
$modifier = $_POST["modifier"];


if ($modifier == "+"){
    $ant = $getal1 + $getal2;
    echo "<h1>{$getal1} + {$getal2} = {$ant}</h1> \n";
}
else if ($modifier == "-"){
    $ant = $getal1 - $getal2;
    echo "<h1>{$getal1} - {$getal2} = {$ant}</h1> \n";
}
else if ($modifier == "x"){
    $ant = $getal1 * $getal2;
    echo "<h1>{$getal1} x {$getal2} = {$ant}</h1> \n";
}
else if ($modifier == "/"){
    $ant = $getal1 / $getal2;
    echo "<h1>{$getal1} / {$getal2} = {$ant}</h1> \n";
}
else if ($modifier == "%"){
    $ant = $getal1 % $getal2;
    echo "<h1>{$getal1} % {$getal2} = {$ant}</h1> \n";
}
else if ($modifier == "^"){
    $ant = $getal1 ** $getal2;
    echo "<h1>{$getal1} ^ {$getal2} = {$ant}</h1> \n";
}
else if ($modifier == "."){
    $ant = $getal1 . $getal2;
    echo "<h1>{$getal1} . {$getal2} = {$ant}</h1> \n";
}

?>

</body>
</html>