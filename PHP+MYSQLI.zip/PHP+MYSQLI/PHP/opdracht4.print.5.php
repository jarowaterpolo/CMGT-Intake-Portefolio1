<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php (codes)
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    $array1 = array("Jaro", "Noa", "Jaya", "Mark", "Rilana");
    
    print_r($array1);

    ?>

    <pre><?php print_r($array1); ?></pre>


</body>
</html>