<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>antwoord</titel>
</head>

<body> 
<?php 
$getal = $_POST["getal"];
$getal2 = $_POST["getal2"];
$getal3 = $_POST["getal3"];
$mult = $getal;
$mult2 = $getal2;
$mult3 = $getal3;
$ant = $getal;
$ant2 = $getal2;
$ant3 = $getal3;
$anteind = 0;

//$ant = $getal * $mult ** $mult;
//echo "<h1>{$getal}! = {$ant}</h1> \n";

if (is_numeric($_POST["getal"]))
{
    while ($mult > 1)
{
    $mult -= 1;
    $ant *= $mult;
}
echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else 
{
    echo "voer een getal in ipv een letter \n";
}


if (is_numeric($_POST["getal2"]))
{
    while ($mult2 > 1)
{
    $mult2 -= 1;
    $ant2 *= $mult2;
}
echo "<h1>{$getal2}! = {$ant2}</h1> \n";
}
else 
{
    echo "voer een getal in ipv een letter \n";
}


if (is_numeric($_POST["getal3"]))
{
    while ($mult3 > 1)
{
    $mult3 -= 1;
    $ant3 *= $mult3;
}
echo "<h1>{$getal3}! = {$ant3}</h1> \n";
}
else 
{
    echo "voer een getal in ipv een letter \n";
}


//while ($mult > 1 && $mult2 > 1 && $mult3 > 1)
//{
//    $mult -= 1;
//    $mult2 -= 1;
//    $mult3 -= 1;
//    $ant *= $mult;
//    $ant2 *= $mult2;
//    $ant3 *= $mult3;
//}

if (is_numeric($_POST["getal"]) & is_numeric($_POST["getal2"]) & is_numeric($_POST["getal3"]))
{
    $anteind = $ant / ($ant2 * $ant3);
    echo "<h1>{$getal}! / ({$getal2}! x {$getal3}!) = {$anteind}</h1> \n";
    echo "<br> \n";
}
else 
{
    echo "een van je ingevoerde dingen is geen cijfer vul een cijfer in! \n";
    echo "<br> \n";
}

if (is_numeric($_POST["getal"]))
{
    echo "<br> \n";
    echo "{$ant} \n";
}
else 
{
    echo "<br> \n";
    echo "voer een cijfer in ipv een letter! \n";
}

if (is_numeric($_POST["getal2"]))
{
    echo "<br> \n";
    echo "{$ant2} \n";
}
else 
{
    echo "<br> \n";
    echo "voer een cijfer in ipv een letter! \n";
}

if (is_numeric($_POST["getal3"]))
{
    echo "<br> \n";
    echo "{$ant3} \n";
}
else 
{
    echo "<br> \n";
    echo "voer een cijfer in ipv een letter! \n";
}





?>

</body>
</html>