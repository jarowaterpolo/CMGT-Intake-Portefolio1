<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test php
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    
       echo date('D');
    ?>

</body>
</html>