<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>finish!</title>
</head>
<body>
    je hebt het gehaalt!
    <form method = "POST" action = "start3ddλ.php" >
    <input type = "submit" value = "nog een keer!"><br>  
</body>
</html>