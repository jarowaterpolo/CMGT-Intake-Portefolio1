<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Fiets tekoop

    </titel>
</head>

<body>
    <?php 
    $artikel = "Smith & Weston";
    $prijs = "200$";

    $optie1 = urlencode($artikel);
    $optie2 = urlencode($prijs);
    
    ?>  
    <a href=<?php echo "bestel.2.php?artikel={$optie1}&prijs={$optie2}" ?> > bestel hier</a>

</body>
</html>