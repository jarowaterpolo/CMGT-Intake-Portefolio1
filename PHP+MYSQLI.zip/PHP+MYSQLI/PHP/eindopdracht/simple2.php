<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <titel>color web </titel>
</head>

<body>
<br>
<br>
    <br>
    
    <?php
        if(empty($_POST)){
            echo "Vul alle vakjes in. Bij de eerste in het engels een kleur en bij de andere 2 een nummer. <br>\n";
        }
        else{
            if (is_string($_POST["kleur"]))
            {
                $kleur = $_POST["kleur"];
            }
            else{
                echo "voer bij 1 een kleur in het engels in!";
                echo " <br>\n";
            }
            if (is_numeric($_POST["lengte"]))
            {
                $lengte = $_POST["lengte"];
            }
            else{
                echo "voer bij 2 een getal in!";
                echo " <br>\n";
            }
            if (is_numeric($_POST["dikte"]))
            {
                $dikte = $_POST["dikte"];
            }
            else{
                echo "voer bij 3 een getal in!";
                echo " <br>\n";
            }

            if (is_string($_POST["kleur"]) & is_numeric($_POST["lengte"]) & is_numeric($_POST["dikte"]))
            {
                echo "<hr style='background:{$kleur}; width:{$lengte}px; height:{$dikte}px'>";
                echo " <br>\n";
            }
            else{
                echo "voer zowel bij 1 een kleur in en bij 2 als bij 3 een getal in!";
                echo " <br>\n";
            }
            
        }

        $kleurrij = array(
            "#ff0000" => array("kleurNL" => "rood", "kleurEN" => "red (je kan de engelse naam gebruiken voor de vorm met kleur)"),
            "#ff6000" => array("kleurNL" => "oranje", "kleurEN" => "orange (je kan de engelse naam gebruiken voor de vorm met kleur)"),
            "#ffec00" => array("kleurNL" => "geel", "kleurEN" => "yellow (je kan de engelse naam gebruiken voor de vorm met kleur)"),
            "#20ff00" => array("kleurNL" => "groen", "kleurEN" => "green (je kan de engelse naam gebruiken voor de vorm met kleur)"),
            "#000bff" => array("kleurNL" => "blauw", "kleurEN" => "blue (je kan de engelse naam gebruiken voor de vorm met kleur)")
        );
        
        foreach ($kleurrij as $hexcode => $kleuren) {
            echo "<p style='color:$hexcode;'>$hexcode = {$kleuren['kleurNL']} en {$kleuren['kleurEN']}</p>";
            echo "<br>\n";
        }
        
        
    
    ?>
</body>
</html>