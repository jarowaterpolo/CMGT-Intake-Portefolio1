<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome!</title>
</head>

<body>
<br>
<br>
<div style='background:blue; width:1000px; height:1000px'>
    <br>
    <p style='color:#FFFFFF'> &nbsp; Here I will show you my coding skills</p>
    <p style='color:#FFFFFF'> &nbsp; We will start with some numbers</p>

    <!-- Form to input numbers and perform actions -->
    <form method="POST" action="">
        <p style='color:#FFFFFF'> &nbsp; Geef getal1:</p> 
        <!-- Display the current value of getal1 after submission -->
        <input type="text" name="getal1" value="<?php echo isset($_POST['getal1']) ? (int)$_POST['getal1'] : 0; ?>"><br>

        <p style='color:#FFFFFF'> &nbsp; Geef getal2:</p> 
        <!-- Display the current value of getal2 after submission -->
        <input type="text" name="getal2" value="<?php echo isset($_POST['getal2']) ? (int)$_POST['getal2'] : 0; ?>"><br>

        <!-- Hidden field to keep track of the incremented value of t3 -->
        <input type="hidden" name="current_t3" value="<?php echo isset($_POST['current_t3']) ? (int)$_POST['current_t3'] : 0; ?>">

        <!-- Button to perform addition of getal1 and getal2 -->
        <input type="submit" name="action" value="Optellen">

        <!-- Button to increment t3 by 1 -->
        <input type="submit" name="action" value="+1">
    </form>

    <?php
    // Check if the form has been submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve getal1 and getal2 from the form
        $t1 = isset($_POST["getal1"]) ? (int)$_POST["getal1"] : 0;
        $t2 = isset($_POST["getal2"]) ? (int)$_POST["getal2"] : 0;

        // Retrieve the current value of t3 from the hidden field
        $t3 = isset($_POST["current_t3"]) ? (int)$_POST["current_t3"] : $t1 + $t2;

        // Check which button was pressed
        if ($_POST["action"] == "Optellen") {
            // Recalculate t3 as the sum of getal1 and getal2
            $t3 = $t1 + $t2;
            $t10 = $t3;
            echo "<p style='color:#FFFFFF;'>$t1 + $t2 = $t10</p>";
        } elseif ($_POST["action"] == "+1") {
            // Increment t3 by 1
            $t1 = isset($_POST["getal1"]) ? (int)$_POST["getal1"] : 0;
            $t2 = isset($_POST["getal2"]) ? (int)$_POST["getal2"] : 0;

            $t10 = $t1 + $t2;
            $t3 += 1;
            $t4 = $t3-1;
            echo "<p style='color:#FFFFFF;'>$t1 + $t2 = $t10</p>";
            echo "<p style='color:#FFFFFF;'> $t4 + 1 = $t3 </p>";
        }
        
        // Update the hidden field to retain the new value of t3
        echo "<script>document.getElementsByName('current_t3')[0].value = $t3;</script>";
    }
   
