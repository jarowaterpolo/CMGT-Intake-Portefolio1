<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php (codes)
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    $array1 = array(1,2,3);
    echo $array1[0],$array1[1],$array1[2]."<br>\n";
    echo "<br>\n";
    
    //array draaien
    $array2 = array_reverse($array1);


    
    //$array2 = array(
    //    array(1,2,3,4,5),
    //    array(6,7,8,9,10)
    //);

    //echo $array2[0][0]. " ". $array2[0][1]. " ".$array2[0][2]. " ". $array2[0][3]. " ".$array2[0][4]. " ". $array2[1][0]."<br>\n";

        
      
    ?>


</body>
</html>