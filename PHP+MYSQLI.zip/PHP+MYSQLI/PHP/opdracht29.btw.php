<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>multi php

    </titel>
</head>

<body>
<br>
<br>
<form method="POST" action="<?php $_SERVER["PHP_SELF"]; ?>">
    startbedrag: <input type="input" name="getal1" ><br>
    <input type="submit" value="optellen" >
</form>
   <?php
       
        function btw(){
            if(empty($_POST)){
                echo "Vul beide getallen in. <br>\n";
            }
            else{
                if (is_numeric($_POST["getal1"]))
                {
                    $getal1 = $_POST["getal1"];
                }
                else{
                    echo "voer bij 1 een getal in!";
                    echo " <br>\n";
                }
                
                if (is_numeric($_POST["getal1"]))
                {
                    echo "bedrag zonder btw";
                    echo " <br>\n";
                    echo "€".$_POST["getal1"].",-";
                    echo " <br>\n";
                    echo " <br>\n";

                    $btw = 0.21;
                    echo "bedrag met btw van ";
                    echo ($btw * 100)."%";
                    echo " <br>\n";
                    $totaal1 = $_POST["getal1"] * ($btw + 1);
                    echo $_POST["getal1"]."X".($btw + 1)."=".$totaal1."<br>\n";
                    echo " <br>\n";
                    $btw = 0.09;
                    echo "bedrag met btw van ";
                    echo ($btw * 100)."%";
                    echo " <br>\n";
                    $totaal2 = $_POST["getal1"] * ($btw + 1);
                    echo $_POST["getal1"]."X".($btw + 1)."=".$totaal2."<br>\n";
                    echo " <br>\n";
                }
                else{
                    echo "voer zowel bij 1 een getal in!";
                    echo " <br>\n";
                }
                
                
            }
        }

        echo btw();
    
    ?>


</body>
</html>