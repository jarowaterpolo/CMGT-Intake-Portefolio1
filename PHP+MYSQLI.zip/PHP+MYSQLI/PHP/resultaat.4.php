<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Welkom</titel>
</head>

<body> 
<?php 
$jaar = date('Y');
$vnaam = $_POST["voornaam"];
$anaam = $_POST["achternaam"];
$bdate = $_POST["geboortedatum"];
$klas = $_POST["klas"];
$geslacht = $_POST["geslacht"];
$profiel = $_POST["profiel"];
echo "<h1>Hallo {$vnaam} {$anaam} -{$geslacht}- {$klas}-{$profiel} uit {$bdate} </h1> \n";

?>

</body>
</html>