<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Test php?

    </titel>
</head>

<body>
<br>
<br>
    <?php 
    date_default_timezone_set('CET');
        $dagvdweek = date('D');
        $dag = date('d');
        $maand = date('M');
        $jaar = date('Y');
        echo date('h:i:s');
    ?>

</body>
</html>