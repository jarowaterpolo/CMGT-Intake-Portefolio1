<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Formulier

    </titel>
</head>

<body>

    <form method="post" action="reken.antwoord.faculteit2.2.php">
        <p> <h1>Rekenmachine</h1>
        Getal: <input type="text" name="getal" > <br>
        ____________________________________________________________________________________________<br>
        Getal2: <input type="text" name="getal2" > X Getal3: <input type="text" name="getal3" > <br>
        </p>
        
        <input type="submit" value="Verstuur" >

    </form>

</body>
</html>