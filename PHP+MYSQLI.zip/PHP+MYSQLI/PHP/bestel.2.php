<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Het artikel</titel>
</head>

<body> 
<?php 
$artikel = $_GET["artikel"];
$prijs = $_GET["prijs"];
echo "<h1>Hallo de {$artikel} kost {$prijs}</h1>"



?>

</body>
</html>