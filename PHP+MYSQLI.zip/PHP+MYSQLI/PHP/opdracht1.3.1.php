<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Test php?

    </titel>
</head>

<body>
<br>
<br>
    <?php 
        $dagvdweek = date('D');
        $dag = date('d');
        $maand = date('M');
        $jaar = date('Y');
        echo "Het is vandaag: {$dag} {$maand} {$jaar} --- {$dagvdweek} ";
    ?>

</body>
</html>