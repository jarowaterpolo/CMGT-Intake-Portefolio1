<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php (codes)
    </titel>
</head>

<body>
<br>
<br>
    <?php 
        $vakkenPakket = $_POST["pakket"];
        echo "Gekozen Vakken: <br>\n";
        for ($i=0; $i<sizeof($vakkenPakket); $i++){
            echo $vakkenPakket[$i];
            echo " <br>\n";
        }








    ?>
    
</body>
</html>