<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Teller While

    </titel>
</head>

<body>

<br>
    <?php 
    
    $teller = 1;
    while($teller <= 10 ){
            echo $teller."<br> \n";
            $teller++;
    }
    
    
    
    ?>

</body>
</html>