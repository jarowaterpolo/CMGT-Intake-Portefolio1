<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Teller Do-While

    </titel>
</head>

<body>

<br>
    <?php 
    
    $teller = 1;
    do {
        echo $teller."<br> \n";
            $teller++;
    } while($teller <= 10 );
    
    
    
    ?>

</body>
</html>