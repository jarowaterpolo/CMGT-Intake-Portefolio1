<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php (codes)
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    //$dag = date('d');
    //$maand = date('M');
    $cijfer1 = array(6.8, 9.0, 5.3, 7.8);
    $totaal = 0;

    for ($i=0; $i<4; $i++){
            echo $cijfer1[$i];
            echo " <br>\n";
            $totaal += $cijfer1[$i];
    }
    
    echo " <br>\n";
    $gemiddelde = $totaal / 4 ;
    echo (round($gemiddelde, 1));
    echo " <br>\n";
    ?>


</body>
</html>