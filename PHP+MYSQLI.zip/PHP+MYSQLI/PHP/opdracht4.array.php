<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    $array1 = array("Jaro", "Noa", "Jaya", "Mark", "Rilana");
    $array2 = array("Nieuwenhuisen", "Rahael", "Soeki");
    echo $array1[0]." ". $array2[0]."<br>\n";
    echo $array1[1]." ". $array2[0]."<br>\n";
    echo $array1[2]." ". $array2[2]."<br>\n";
    echo $array1[3]." ". $array2[0]."<br>\n";
    echo $array1[4]." ". $array2[1]."<br>\n";
    
    
    echo "<br>\n";
    echo $array1[0]."<br>\n";
    $array1[0] = "The Chosen 1";
    echo $array1[0]."<br>\n";
    echo "<br>\n";




    $array3 = array(
        array("Jaro", "Noa", "Jaya", "Mark", "Rilana"),
        array("Nieuwenhuisen", "Rahael", "Soeki")
    );

    echo $array3[0][0]. " ". $array3[1][0]."<br>\n";

      
    ?>


</body>
</html>