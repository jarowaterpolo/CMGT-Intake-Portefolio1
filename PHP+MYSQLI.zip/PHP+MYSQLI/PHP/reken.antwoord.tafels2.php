<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>antwoord</titel>
</head>

<body> 
<?php 
$getal2 = $_POST["getal2"];
$getal1 = 1;


if (is_numeric($_POST["getal2"]))
{
    if ($getal2 <= 100){

        while ($getal1 <= 10)
        {
            $ant = $getal1 * $getal2;
            echo "<h1>{$getal1} x {$getal2} = {$ant}</h1> \n";
            $getal1 += 1;
        
        }
        }
        else{
            echo "jou getal is te hoog het gaat tot 100 ";
        }
}
else 
{
echo "voer een cijfer in ipv een letter";
}



?>

</body>
</html>