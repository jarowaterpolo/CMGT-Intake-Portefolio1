<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php (codes)
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    //array create
    $array1 = array(3,1,2);
    echo $array1[0],$array1[1],$array1[2]."<br>\n";
    echo "<br>\n";
    
    //array draaien
    $array2 = array_reverse($array1);
    echo $array2[0],$array2[1],$array2[2]."<br>\n";
    echo "<br>\n";

    //array sort counting from 1
    sort($array1);
    echo $array1[0],$array1[1],$array1[2]."<br>\n";
    echo "<br>\n";

    //array randomly changes
    shuffle($array1);
    echo $array1[0],$array1[1],$array1[2]."<br>\n";
    echo "<br>\n";


    for ($i=0; $i<3; $i++){
        echo $array1[$i];
    }
    echo " <br>\n";

    for ($i=0; $i<3; $i++){
    echo $array2[$i];
    }
    echo " <br>\n";

    //$array2 = array(
    //    array(1,2,3,4,5),
    //    array(6,7,8,9,10)
    //);

    //echo $array2[0][0]. " ". $array2[0][1]. " ".$array2[0][2]. " ". $array2[0][3]. " ".$array2[0][4]. " ". $array2[1][0]."<br>\n";

    ?>   
<br>
<br>
    <?php 
    $array1 = array("Jaro", "Noa", "Jaya", "Mark", "Rilana");
    $array2 = array("Nieuwenhuisen", "Rahael", "Soeki");
    echo $array1[0]." ". $array2[0]."<br>\n";
    echo $array1[1]." ". $array2[0]."<br>\n";
    echo $array1[2]." ". $array2[2]."<br>\n";
    echo $array1[3]." ". $array2[0]."<br>\n";
    echo $array1[4]." ". $array2[1]."<br>\n";
    
    
    echo "<br>\n";
    echo $array1[0]."<br>\n";
    $array1[0] = "The Chosen 1";
    echo $array1[0]."<br>\n";
    echo "<br>\n";

    $array1[0] = "Jaro";


    $array3 = array(
        array("Jaro ", "Noa ", "Jaya ", "Mark ", "Rilana "),
        array("Nieuwenhuisen", "Nieuwenhuisen", "Soeki", "Nieuwenhuisen", "Rahael")
    );

    echo $array3[0][0]. " ". $array3[1][0]."<br>\n";
    echo " <br>\n";
      

    for ($i=0; $i<5; $i++){
            echo $array3[0][$i];
            echo $array3[1][$i];
            echo " <br>\n";
    }
    ?>


</body>
</html>