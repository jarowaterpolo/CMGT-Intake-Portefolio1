<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>multi php

    </titel>
</head>

<body>
<br>
<br>

<form method="POST" action="<?php $_SERVER["PHP_SELF"]; ?>">
    kleur: <input type="input" name="kleur" ><br>
    lengte: <input type="input" name="lengte" ><br>
    dikte: <input type="input" name="dikte" ><br>
    <input type="submit" value="laat de lijn zien" >
</form>
    <?php
        if(empty($_POST)){
            echo "Vul alle vakjes in. Bij de eerste in het engels een kleur en bij de andere 2 een nummer. <br>\n";
        }
        else{
            if (is_string($_POST["kleur"]))
            {
                $kleur = $_POST["kleur"];
            }
            else{
                echo "voer bij 1 een kleur in het engels in!";
                echo " <br>\n";
            }
            if (is_numeric($_POST["lengte"]))
            {
                $lengte = $_POST["lengte"];
            }
            else{
                echo "voer bij 2 een getal in!";
                echo " <br>\n";
            }
            if (is_numeric($_POST["dikte"]))
            {
                $dikte = $_POST["dikte"];
            }
            else{
                echo "voer bij 3 een getal in!";
                echo " <br>\n";
            }

            if (is_string($_POST["kleur"]) & is_numeric($_POST["lengte"]) & is_numeric($_POST["dikte"]))
            {
                echo "<hr style='background:{$kleur}; width:{$lengte}px; height:{$dikte}px'>";
                echo " <br>\n";
            }
            else{
                echo "voer zowel bij 1 een kleur in en bij 2 als bij 3 een getal in!";
                echo " <br>\n";
            }
            
        }
        
    
    ?>


</body>
</html>