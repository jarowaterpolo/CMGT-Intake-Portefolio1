<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test array php (codes)
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    //$dag = date('d');
    //$maand = date('M');
    $array1 = array("Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag");
   
    $i=0;
    while ($i<5){
        echo $array1[$i];
            echo " <br>\n";
            $i+=1;
    }

    echo " <br>\n";

    $array3 = array(
        array("Maandag ", "Dinsdag ", "Woensdag ", "Donderdag ", "Vrijdag "),
        array("16 sep", "17 sep", "18 sep", "19 sep", "20 sep")
    );

    
    $i=0;
    while ($i<5){
            echo $array3[0][$i];
            echo $array3[1][$i];
            echo " <br>\n";
            $i+=1;
    }
    ?>


</body>
</html>