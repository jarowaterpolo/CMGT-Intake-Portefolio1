<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>antwoord</titel>
</head>

<body> 
<?php 
$antwoord = $_POST["hoofdstad"];

echo "<h1>de vraag was: wat is de hoofstad van duitsland?</h1 \n>";
echo "<h1>Je antwoord op de vraag was {$antwoord}</h1> \n";

if ($antwoord == "Berlijn"){
    echo "<h1>dat klopt helemaal.</h1>";
}
else if ($antwoord == "Bonn" || "Dortmund"){
    echo "<h1>helaas is dat niet het goede antwoord.</h1> \n";
}
else{
    echo "<h1>helaas is dat niet het goede antwoord.</h1> \n";
}

?>

</body>
</html>