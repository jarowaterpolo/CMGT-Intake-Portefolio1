<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Test php?

    </titel>
</head>

<body>
<br>
<br>
    <?php 
        $dagvdweek = date('D');
        echo "het is vandaag: {$dagvdweek} ";
    ?>

</body>
</html>