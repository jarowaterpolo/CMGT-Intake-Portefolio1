<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>tijd van dag bepaling

    </titel>
</head>

<body> 
<br>
<br>
    <?php 
    date_default_timezone_set('Europe/Amsterdam');
    $uur = date('H');
        

        if ($uur >= 0 && $uur <= 6 || $uur >= 18 && $uur <= 24){
            echo "goedenacht beste Jaro";
        }
        elseif ($uur >= 6 && $uur <= 12){
            echo "goedemorgen beste Jaro";
        }
        elseif ($uur >= 12 && $uur <= 18){
            echo "goedemiddag beste Jaro";
        }
        elseif ($uur >= 18 && $uur <= 24){
            echo "goedenacht beste Jaro";
        }
        

    ?>

</body>
</html>