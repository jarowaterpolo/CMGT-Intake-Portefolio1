<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>php

    </titel>
</head>

<body>
<br>
<br>
   <?php
        $cijfers = array(7.5 ,9.2 ,8.0 ,5.5);

        function gemiddelde(Array $cijfers)
        {
            $totaal=0;
            $j = count($cijfers);
            for ($i=0; $i<$j; $i++){
                $totaal += $cijfers[$i];
            }
            $gemiddelde = $totaal / $i;
            echo $gemiddelde." <br>\n";
            echo "~";
            echo (round($gemiddelde, 1));
            echo " <br>\n";
        }


       
       echo gemiddelde($cijfers);
    
    ?>


</body>
</html>