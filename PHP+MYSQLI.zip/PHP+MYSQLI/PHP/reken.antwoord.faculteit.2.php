<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>antwoord</titel>
</head>

<body> 
<?php 
$getal = $_POST["getal"];
$getal2 = $_POST["getal2"];
$getal3 = $_POST["getal3"];
$mult = $getal;
$mult2 = $getal2;
$mult3 = $getal3;
$ant = $getal;
$ant2 = $getal2;
$ant3 = $getal3;
$anteind = 0;

//$ant = $getal * $mult ** $mult;
//echo "<h1>{$getal}! = {$ant}</h1> \n";


while ($mult > 1)
{
    $mult -= 1;
    $ant *= $mult;
}
echo "<h1>{$getal}! = {$ant}</h1> \n";

while ($mult > 1 && $mult2 > 1 && $mult3 > 1)
{
    $mult -= 1;
    $mult2 -= 1;
    $mult3 -= 1;
    $ant *= $mult;
    $ant2 *= $mult2;
    $ant3 *= $mult3;
}
$anteind = $ant / ($ant2 * $ant3);
echo "{$ant} \n";
echo "{$ant2} \n";
echo "{$ant3} \n";
echo "<h1>{$getal}! / ({$getal2}! x {$getal3}!) = {$anteind}</h1> \n";


?>

</body>
</html>