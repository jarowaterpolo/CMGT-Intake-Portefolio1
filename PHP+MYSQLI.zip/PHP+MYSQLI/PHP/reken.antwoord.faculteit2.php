<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>antwoord</titel>
</head>

<body> 
<?php 
$getal = $_POST["getal"];
$mult = $getal;
$ant = $getal;

//$ant = $getal * $mult ** $mult;
//echo "<h1>{$getal}! = {$ant}</h1> \n";

if (is_numeric($_POST["getal"]))
{
    while ($mult > 1)
{
    $mult -= 1;
    $ant *= $mult;
}
echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else 
{
    echo "voer een nummer in!";
}

?>

</body>
</html>