<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Formulier

    </titel>
</head>

<body>
    <form method="post" action="reken.antwoord.tafels.php">
        <p> <h1>Rekenmachine</h1>
        Getal: <input type="text" name="getal2" > <br>
        </p>
        
        <input type="submit" value="Verstuur" >

    </form>

</body>
</html>