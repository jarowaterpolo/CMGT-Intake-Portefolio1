<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Welkom</titel>
</head>

<body> 
<?php 
$vnaam = $_POST["voornaam"];
$anaam = $_POST["achternaam"];
echo "<h1>Hallo {$vnaam} {$anaam}</h1> \n"
?>

</body>
</html>