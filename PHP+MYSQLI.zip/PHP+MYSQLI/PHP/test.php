<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>3d doolhof!</title>
    </head>
    <body>
        <?php 
        phpinfo();


        ?>

    </body>