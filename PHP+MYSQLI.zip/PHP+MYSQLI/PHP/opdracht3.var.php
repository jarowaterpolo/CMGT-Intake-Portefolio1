<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>
        Test php
    </titel>
</head>

<body>
<br>
<br>
    <?php 
    $i = 2;
    $bedrag = 2.45;
    $bignumber = 1E307;
    $antwoord = true;
    $naam = "Jaro";
    $getaltext = "2";




       echo gettype($i)."<br>\n";
       echo gettype($bedrag)."<br>\n";
       echo gettype($bignumber)."<br>\n";
       echo gettype($antwoord)."<br>\n";
       echo gettype($naam)."<br>\n";
       echo gettype($getaltext)."<br>\n";

       echo "<hr>\n";
       ///antwoord boolean omzet in int
       echo $antwoord."<br>\n";
       echo $antwoord = false;
       echo $antwoord."<br>\n";
       //getaltext
       echo $getaltext + $i."<br>\n";
       //getal int + double = double
       echo $i + 0.75."<br>\n";
       //bignumber text
       echo $bignumber."<br>\n";
       //testing int and double
       echo $i = $bignumber."<br>\n";
    ?>

</body>
</html>