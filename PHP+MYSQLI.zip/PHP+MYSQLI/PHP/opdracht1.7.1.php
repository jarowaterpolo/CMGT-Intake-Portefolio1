<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Datum + Tijd

    </titel>
</head>

<body>
<br>
<br>
    <?php 
        date_default_timezone_set('CET');
        $dagvdweek = date('D');
        $dag = date('d');
        $maand = date('M');
        $jaar = date('Y');
        $uur = date('H');
        $minuut = date('m');
        $seconden = date('s');
        echo "Het is vandaag: {$dag}-{$maand}-{$jaar} --- {$dagvdweek} <br> \n";
        echo "en het is nu {$uur}:{$minuut}:{$seconden} \n";
        
    ?>

</body>
</html>