<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Name Birthyear and Date

    </titel>
</head>

<body>
    <form method="POST" action="resultaat.3.php">
        voornaam: <input type="text" name="voornaam" > <br>
        achternaam: <input type="text" name="achternaam" > <br>
        geboortejaar: <input type="text" name="geboortejaar" > <br>
        geboortedatum: <input type="text" name="geboortedatum" > <br>
        <input type="submit" value="Verstuur" >

    </form>

</body>
</html>