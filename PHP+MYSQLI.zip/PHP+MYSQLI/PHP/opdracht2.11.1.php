<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Formulier

    </titel>
</head>

<body>
    <form method="post" action="resultaat.5.php">
        <p> wat is de hoofstad van duitsland: 
            <input type="radio" name="hoofstad" value="Bonn" checked >Bonn
            <input type="radio" name="hoofstad" value="Berlijn" >Berlijn
            <input type="radio" name="hoofstad" value="Dortmund" >Dortmund
        </p>
        
        <input type="submit" value="Verstuur" >

    </form>

</body>
</html>