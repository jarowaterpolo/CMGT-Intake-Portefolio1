<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>het begin!</title>
</head>
    <?php 
    session_start();
    session_unset();
    session_destroy();
    session_start();
    $_SESSION["seed"] = "error2";

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seed_processed'])) {
        seed();
        header('Location: d3doolhofλ.php');
        exit();
    }

        function seed(){
            $_SESSION["seed"] = "error1";
            if(!empty($_POST["seed"])){
                if(is_numeric($_POST["seed"])){
                    if($_POST["seed"]>=20000000){
                        $_SESSION["seed"] = substr($_POST["seed"],0,18);
                    } else {$_SESSION["seed"] = rand(16777216,33554432);}
                } else {$_SESSION["seed"] = rand(16777216,33554432);}
            } else {$_SESSION["seed"] = rand(16777216,33554432);}
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['seed_processed'])) {
            $_POST['seed_processed'] = true; 
        }
    
    ?>
<body>
    hallo! om te beginnen click op "start"
    als je zelf een seed wil invoeren, <br>doe dat dan hieronder
    anders krijg je een random seed! <br>
    de seed moet hoger zijn dan 20000000
    <form method="POST" action="">
        seed: <input type="text" name="seed"><br>
        <input type="hidden" name="seed_processed" value="1">
        <input type="submit" value="verstuur"><br>
    geen nummer = random seed <br>
    niet hoog genoeg = random seed

    <?php 
    
    ?>
</body>
</html>