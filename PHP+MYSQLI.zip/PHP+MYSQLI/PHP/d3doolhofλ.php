<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>3d doolhof!</title>
    </head>
    <body>
        <?php 
        //map[z][y][x]
        //player[x][y][z]
        //hoek 0 = 0,0,0 (map)
        //hoek 1 = 0,0,10 (map)
        //hoek 2 = 0,10,0 (map)
        //hoek 3 = 0,10,10 (map)
        //hoek 4 = 10,0,0 (map)
        //hoek 5 = 10,0,10 (map)
        //hoek 6 = 10,10,0 (map)
        //hoek 7 = 10,10,10 (map)

        session_start();
        $seed = "0";
        $up = "loading";
        $down = "loading";
        $forward = "loading";
        $back = "loading";
        $left = "loading";
        $right = "loading";
        #if(empty($_SESSION["player"])){$_SESSION["player"] = array(2,2,2); }
        $finish = array(5,5,5);
        $messige1 = "";
        $messige2 = "";
        $map3d = array();
        
        #region :map

        #region big clean slate

        $vlak11 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak10 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak9 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,0,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,0,1,1,1,1,1,0,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,0,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak8 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak7 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak6 = array(
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,0,1,1,1,1,1,0,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,0,1,1,1,1,1,0,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(1,1,1,1,1,1,1,1,1,1,1)
        );
        $vlak5 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak4 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak3 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,0,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,0,1,1,1,1,1,0,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,0,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak2 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );
        $vlak1 = array(
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(1,1,1,1,1,1,1,1,1,1,1),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0),
            array(0,0,0,0,0,1,0,0,0,0,0)
        );

        $map3d = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5,$vlak6,$vlak7,$vlak8,$vlak9,$vlak10,$vlak11);

        #endregion

        #region :section0

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[0] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);

        #endregion
        
        #region :section1

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[1] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);

        #endregion

        #region :section2

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[2] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);

        #endregion

        #region :section3

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[3] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);

        #endregion

        #region :section4

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[4] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);
        
        #endregion
        
        #region :section5

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[5] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);

        #endregion

        #region :section6

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[6] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);

        #endregion

        #region :section7

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[7] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);

        #endregion

        #region :section8: finish

        $pfinish = array( #player i think
            array(3,3,3),
            array(3,3,7),
            array(3,7,3),
            array(3,7,7),
            array(7,3,3),
            array(7,3,7),
            array(7,7,3),
            array(7,7,7)
        );

        $vlak5 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak4 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,2,0,),
            array(0,0,0,0,0,)
        );
        $vlak3 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak2 = array(
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $vlak1 = array(
            array(1,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,),
            array(0,0,0,0,0,)
        );
        $section[8] = array($vlak1,$vlak2,$vlak3,$vlak4,$vlak5);
        #endregion

        #endregion
        
        function lookaround(){
            global $up,$down,$forward,$back,$left,$right,$_SESSION,$map3d;
            $xp = $_SESSION["player"][2];
            $yp = $_SESSION["player"][1];
            $zp = $_SESSION["player"][0];
            
            if (isset($map3d[$xp][$yp][$zp-1])){
                if ($map3d[$xp][$yp][$zp-1] == 0){
                    $up = "gang";} elseif ($map3d[$xp][$yp][$zp-1] == 1){
                    $up = "muur";} elseif ($map3d[$xp][$yp][$zp-1] == 2){
                    $up = "finish";} else {
                    $up = "error";}
                } else {$up = "muur";}

            if (isset($map3d[$xp][$yp][$zp+1])){
                if ($map3d[$xp][$yp][$zp+1] == 0){
                    $down = "gang";} elseif ($map3d[$xp][$yp][$zp+1] == 1){
                    $down = "muur";} elseif ($map3d[$xp][$yp][$zp+1] == 2){
                    $down = "finish";} else {
                    $down = "error";}
                } else {$down = "muur";}

            if (isset($map3d[$xp][$yp-1][$zp])){
                if ($map3d[$xp][$yp-1][$zp] == 0){
                    $forward = "gang";} elseif ($map3d[$xp][$yp-1][$zp] == 1){
                    $forward = "muur";} elseif ($map3d[$xp][$yp-1][$zp] == 2){
                    $forward = "finish";} else {
                    $forward = "error";}
                } else {$forward = "muur";}

            if (isset($map3d[$xp][$yp+1][$zp])){
                if ($map3d[$xp][$yp+1][$zp] == 0){
                    $back = "gang";} elseif ($map3d[$xp][$yp+1][$zp] == 1){
                    $back = "muur";} elseif ($map3d[$xp][$yp+1][$zp] == 2){
                    $back = "finish";} else {
                    $back = "error";}
                } else {$back = "muur";}

            if (isset($map3d[$xp-1][$yp][$zp])){
                if ($map3d[$xp-1][$yp][$zp] == 0){
                    $left = "gang";} elseif ($map3d[$xp-1][$yp][$zp] == 1){
                    $left = "muur";} elseif ($map3d[$xp-1][$yp][$zp] == 2){
                    $left = "finish";} else {
                    $left = "error";}
                } else {$left = "muur";}

            if (isset($map3d[$xp+1][$yp][$zp])){
                if ($map3d[$xp+1][$yp][$zp] == 0){
                    $right = "gang";} elseif ($map3d[$xp+1][$yp][$zp] == 1){
                    $right = "muur";} elseif ($map3d[$xp+1][$yp][$zp] == 2){
                    $right = "finish";} else {
                    $right = "error";}
                } else {$right = "muur";}}
        
        function moveit(){
            global $_SESSION,$_POST,$messige1;
            if(isset($_POST["input"])){
            $input = $_POST["input"];

                if(!empty(str_contains($input, "up:"))){
                    if(!empty(str_contains($input,"gang"))||!empty(str_contains($input,"finish"))){
                        $_SESSION["player"][2]++;   } else {$messige1 = "daar kan je niet naartoe!";}
                }

                if(!empty(str_contains($input,"down:"))){
                    if(!empty(str_contains($input,"gang"))||!empty(str_contains($input,"finish"))){
                        $_SESSION["player"][2]--;   } else {$messige1 = "daar kan je niet naartoe!";}
                }

                if(!empty(str_contains($input,"forward:"))){
                    if(!empty(str_contains($input,"gang"))||!empty(str_contains($input,"finish"))){
                        $_SESSION["player"][1]++;   } else {$messige1 = "daar kan je niet naartoe!";}
                }

                if(!empty(str_contains($input,"back:"))){
                    if(!empty(str_contains($input,"gang"))||!empty(str_contains($input,"finish"))){
                        $_SESSION["player"][1]--;   } else {$messige1 = "daar kan je niet naartoe!";}
                }

                if(!empty(str_contains($input,"left:"))){
                    if(!empty(str_contains($input,"gang"))||!empty(str_contains($input,"finish"))){
                        $_SESSION["player"][0]--;   } else {$messige1 = "daar kan je niet naartoe!";}
                }

                if(!empty(str_contains($input,"right:"))){
                    if(!empty(str_contains($input,"gang"))||!empty(str_contains($input,"finish"))){
                        $_SESSION["player"][0]++;   } else {$messige1 = "daar kan je niet naartoe!";}
                }

            } else {
                echo "click iets";
            }}

        function finish(){
            global $_SESSION, $finish;
            if ($_SESSION["player"] == $finish){
                header('Location: finish3ddλ.php');
            }}    

        function seeddecode($section){
            global $_SESSION,$seed;
            $seed = substr(decbin($_SESSION["seed"]),0,24);
            $return = substr($seed,$section*3,3);
            return(bindec($return));}

        function distance($array1,$array2){
            $dx=$array1[0]-$array2[0];
            $dy=$array1[1]-$array2[1];
            $dz=$array1[2]-$array2[2];
            return(sqrt($dx**2+$dy**2+$dz**2));}

        
        
        function generatemap(){
            global $_SESSION, $map3d, $section, $pfinish, $finish;
            $xp = $_SESSION["player"][2];
            $yp = $_SESSION["player"][1];
            $zp = $_SESSION["player"][0];
            $isf = 0;
            for ($h = 0; $h < 8; $h++){
                if ($isf == 0 && $h == 7){$temp = $section[8];$finish=$pfinish[$h];}
                elseif ($isf == 0 && seeddecode($h) == 7){$isf = 1;$temp = $section[8];$finish=$pfinish[$h];}
                else {$temp = $section[seeddecode($h)];}
                //echo $h."<br>";
                switch($h) {
                case 0:
                    $sz = 0; $sy = 0; $sx = 0;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz+$k][$sy+$j][$sx+$i]=$temp[$k][$j][$i];
                    }}}break;
                case 1:
                    $sz = 0; $sy = 0; $sx = 10;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz+$k][$sy+$j][$sx-$i]=$temp[$k][$j][$i];
                    }}}break;
                case 2:
                    $sz = 0; $sy = 10; $sx = 0;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz+$k][$sy-$j][$sx+$i]=$temp[$k][$j][$i];
                    }}}break;
                case 3:
                    $sz = 0; $sy = 10; $sx = 10;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz+$k][$sy-$j][$sx-$i]=$temp[$k][$j][$i];
                    }}}break;
                case 4:
                    $sz = 10; $sy = 0; $sx = 0;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz-$k][$sy+$j][$sx+$i]=$temp[$k][$j][$i];
                    }}}break;
                case 5:
                    $sz = 10; $sy = 0; $sx = 10;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz-$k][$sy+$j][$sx-$i]=$temp[$k][$j][$i];
                    }}}break;
                case 6:
                    $sz = 10; $sy = 0; $sx = 10;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz-$k][$sy+$j][$sx-$i]=$temp[$k][$j][$i];
                    }}}break;
                case 7:
                    $sz = 10; $sy = 10; $sx = 10;
                    for ($i = 0; $i < 5; $i++) {
                        for ($j = 0; $j < 5; $j++) {
                            for ($k = 0; $k < 5; $k++) {
                                $map3d[$sz-$k][$sy-$j][$sx-$i]=$temp[$k][$j][$i];
                    }}}break;
                    
                default:echo "error, map loading failed";break;}
                }
                $map3d[$zp][$yp][$xp]=3;


            }

        function playerrand(){
            global $finish,$map3d,$_SESSION;
            $flag = 0;
            while($flag == 0){
                $x = random_int(0,10);$y = random_int(0,10);$z = random_int(0,10);
                if($map3d[$z][$y][$x] == 0){
                    if(distance($finish,array($x,$y,$z))>4){
                        $_SESSION["player"] = array($x,$y,$z);
                        $flag = 1;}}}}
        
        function minimap(){
            global $finish,$map3d,$_SESSION;
            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[0][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;

                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[1][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;
    
                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[2][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;
    
                        case 3:
                            echo "⛋";
                            break;
                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[3][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;

                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[4][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;
    
                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[5][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;
    
                        case 3:
                            echo "⛋";
                            break;
                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[6][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;

                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[7][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;
    
                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[8][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;
    
                        case 3:
                            echo "⛋";
                            break;
                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[9][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;

                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            echo "<br>\n";
            for($i = 0; $i < 11; $i++){
                for($j = 0; $j < 11; $j++){
                    //echo ($map3d[2][$i][$j]); 

                    switch ($map3d[10][$i][$j]){
                        case 0:
                            echo "&nbsp□";
                            break;
                        
                        case 1:
                            echo "&nbsp■";
                            break;

                        case 2:
                            echo "^|";
                            break;
    
                        case 3:
                            echo "⛋";
                            break;

                        default:echo "error, minimap loading failed"; 
                        break;
  
                    }
                }	
                echo "<br>\n";
            }echo "<br>\n";

            
            //case 1:

           //         break;

        }


        if(empty($_SESSION["player"])){playerrand();}
        generatemap();
        minimap();
        finish();
        lookaround();
        moveit();
        lookaround();
        finish();

            
        ?>

        <?php echo "player coordinaten x: ".$_SESSION["player"][0]." y: ".$_SESSION["player"][1]." z: ".$_SESSION["player"][2]?>
        <form method = "POST" action="d3doolhofλ.php?">
        <input type="submit" name="input"  value="<?php echo "down: ".$right. " x-1" ?>">
        <input type="submit" name="input"  value="<?php echo "forward: ".$forward. " y+1" ?>">
        <input type="submit" name="input"  value="<?php echo "up: ".$left. " x+1" ?>"><br>
        <input type="submit" name="input"  value="<?php echo "right: ".$down. " z+1" ?>">
        <input type="submit" name="input"  value="<?php echo "back: ".$back. " y-1" ?>">
        <input type="submit" name="input"  value="<?php echo "left: ".$up. " z-1" ?>"><br>
        <?php if(isset($_POST["input"])){echo $_POST["input"];} else {echo "click iets?";}?><br>
        <?php echo "afstand tot de finish is: ".round(distance($finish,$_SESSION["player"])/0.5)*0.5;?><br>
        <?php echo $messige1 ?><br>
        <?php echo $_SESSION["seed"]?><br>
        <?php for ($s = 0; $s < 8; $s++){
            echo seeddecode($s);
        }?>
        
</body>
</html>