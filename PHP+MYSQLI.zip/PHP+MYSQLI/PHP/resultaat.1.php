<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Welkom</titel>
</head>

<body> 
<?php 
$vnaam = $_GET["voornaam"];
$anaam = $_GET["achternaam"];
echo "<h1>Hallo {$vnaam} {$anaam}</h1> \n"
?>

</body>
</html>