<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Formulier

    </titel>
</head>

<body>

    <?php 
    for($teller = 1 ; $teller <= 10 ; $teller++){
            echo $teller."<br> \n";
    }
    
    
    
    ?>

</body>
</html>