<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Test php

    </titel>
</head>

<body>
<br>
<br>
    <?php 
        $dagvdweek = date('D');
        $dag = array(   "Mon"  => "Maandag",
                        "Tue" => "Dinsdag",
                        "Wed" => "Woensdag",
                        "Thu" => "Donderdag",
                        "Fri" => "Vrijdag"
                    );
        echo "het is vandaag: ".$dag [$dagvdweek]." <br>\n";
    ?>

</body>
</html>