<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Fiets tekoop

    </titel>
</head>

<body>
    <?php 
    $artikel = "fiets";
    $prijs = 200;
    
    ?>  
    <a href=<?php echo "bestel.php?artikel={$artikel}&prijs={$prijs}" ?>> bestel hier</a>

</body>
</html>