<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Test php

    </titel>
</head>

<body>
<br>
<br>
    <?php 
        $kleurrij = array(   "#ff0000"  => "rood",
                        "#ff6000" => "oranje",
                        "#ffec00" => "geel",
                        "#20ff00" => "groen",
                        "#000bff" => "blauw"
                    );

        foreach($kleurrij as $hexcode => $kleur){
            echo "<p style='color:$hexcode;'> {$hexcode}"." = " . $kleur."</p>";
            echo " <br>\n";
            
        }
    ?>

</body>
</html>