<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Simple Form

    </titel>
</head>

<body>
    <form method="GET" action="resultaat.1.php">
        voornaam: <input type="text" name="voornaam" > <br>
        achternaam: <input type="text" name="achternaam" > <br>
        <input type="submit" value="Verstuur" >


    </form>

</body>
</html>