<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Formulier

    </titel>
</head>

<body>

    <?php 
    $profiel = $_POST["profiel"];

    switch($profiel){
        case "NT":
            echo "<h1> Natuur en Techniek </h1> <br> in dit profiel heb je: <br> Wiskunde B, Natuurkunde en Scheikunde <br> en als je richting van computers heen wilkies dan informatica \n";
        break;

        case "NG":
            echo "<h1> Natuur en Gezonheid </h1> <br> in dit profiel heb je: <br> Wiskunde A/B, Biologie en Scheikunde \n";
        break;

        case "EM":
            echo "<h1> Economie en Maatschappij </h1> <br> in dit profiel heb je: <br> Wiskunde A/B en Economie \n";
        break;

        case "CM":
            echo "<h1> Cultuur en Maatschappij </h1> <br> in dit profiel heb je: <br> Wiskunde A/C en geschiedenis \n";
        break;
    }
    
    
    ?>

</body>
</html>