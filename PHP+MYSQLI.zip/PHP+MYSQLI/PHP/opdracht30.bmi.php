<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>multi php

    </titel>
</head>

<body>
<br>
<br>
<form method="POST" action="<?php $_SERVER["PHP_SELF"]; ?>">
    KG: <input type="input" name="kg" ><br>
    lengte=(m): <input type="input" name="m2" ><br>
    <input type="submit" value="optellen" >
</form>
   <?php
       $_POST["m2"] = $_POST["m2"] * $_POST["m2"];
        function bmi(){
            if(empty($_POST)){
                echo "Vul beide getallen in. <br>\n";
            }
            else{
                if (is_numeric($_POST["kg"]))
                {
                    $kg = $_POST["kg"];
                }
                else{
                    echo "voer bij 1 een getal in!";
                    echo " <br>\n";
                }
                if (is_numeric($_POST["m2"]))
                {
                    $m2 = $_POST["m2"];
                }
                else{
                    echo "voer bij 2 een getal in!";
                    echo " <br>\n";
                }                
                
                if (is_numeric($_POST["kg"]) & is_numeric($_POST["m2"]))
                {
                    $bmi = $kg / $m2;
                    return $bmi;
                }
                
            }
        }

        if (is_numeric($_POST["kg"]) & is_numeric($_POST["m2"]))
                {
                    echo "u weegt:".$_POST["kg"]." kg";
                    echo " <br>\n";
                    echo "en uw oppervlakte is:".$_POST["m2"]." m^2";
                    echo " <br>\n";
                    echo "dus uw BMI=".bmi()." kg/m^2";
                    echo " <br>\n";
                }
                else{
                    echo "voer zowel bij 1 als bij 2 een getal in!";
                    echo " <br>\n";
                }
    
    ?>


</body>
</html>