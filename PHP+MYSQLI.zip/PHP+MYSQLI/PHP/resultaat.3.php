<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Welkom</titel>
</head>

<body> 
<?php 
$jaar = date('Y');
$vnaam = $_POST["voornaam"];
$anaam = $_POST["achternaam"];
$bjaar = $_POST["geboortejaar"];
$bdate = $_POST["geboortedatum"];
$age = $jaar - $_POST["geboortejaar"];
echo "<h1>Hallo {$vnaam} {$anaam} uit {$bjaar}-{$bdate} je bent {$age} jaar oud</h1> \n"
?>

</body>
</html>