

if ($getal == 1)
{
    $ant = $getal;
    echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else if ($getal == 2)
{
    $ant = $getal * ($mult - 1);
    echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else if ($getal == 3)
{
    $ant = $getal * ($mult - 1) * ($mult - 2);
    echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else if ($getal == 4)
{
    $ant = $getal * ($mult - 1) * ($mult - 2) * ($mult - 3);
    echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else if ($getal == 5)
{
    $ant = $getal * ($mult - 1) * ($mult - 2) * ($mult - 3) * ($mult - 4);
    echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else if ($getal == 6)
{
    $ant = $getal * ($mult - 1) * ($mult - 2) * ($mult - 3) * ($mult - 4) * ($mult - 5);
    echo "<h1>{$getal}! = {$ant}</h1> \n";
}
else if ($getal == 7)
{
    $ant = $getal * ($mult - 1) * ($mult - 2) * ($mult - 3) * ($mult - 4) * ($mult - 5) * ($mult - 6);
    echo "<h1>{$getal}! = {$ant}</h1> \n";
}
