<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>array test</title>
    </head>
    <body>
        <?php 
        $mapstage1 = array(
            array(1,0,1,
                  0,0,0,      
                  1,0,1 ),

            array(0,0,0,
                  0,1,0,      
                  0,0,0 ),

            array(1,0,1,
                  0,0,0,      
                  1,0,1 )
        );

        $map1 = $mapstage1[random_int(0,2)][random_int(0,8)];
        $map2 = $mapstage1[random_int(0,2)][random_int(0,8)];
        $map3 = $mapstage1[random_int(0,2)][random_int(0,8)];

        $map = $map1;
        $map .= $map2;
        $map .= $map3;

        echo $map;
        echo " <br>\n";

        echo "_____<br>\n";
        echo "|{$map1}{$map1}{$map1}|<br>\n";
        echo "|{$map1}{$map2}{$map1}|<br>\n";
        echo "|{$map1}{$map1}{$map1}|<br>\n";
        echo "_____<br>\n";

        ?>

    </body>