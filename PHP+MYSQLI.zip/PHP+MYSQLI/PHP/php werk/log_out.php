<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>start web for my end project</title>
</head>

<body>
<br>
<br>
<?php
    session_start();
    $_SESSION=array();
    session_destroy();
    header("Location: start.php");
?>
         
    
<br>
</body>
</html>