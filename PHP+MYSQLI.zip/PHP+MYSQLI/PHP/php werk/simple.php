<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome! to my end project main</title>
</head>

<body>
    <br>
    <?php 
        session_start();
        if(isset($_POST["naam"])){
            header("Location: start.php");
            $_SESSION["naam"] = $_POST["naam"];
        }
        $naam = $_SESSION["naam"];
        $dagvdweek = date('D');
        $dag = date('d');
        $maand = date('M');
        $jaar = date('Y');
        $uur = date('H');
        $minuut = date('i');
        $seconden = date('s');

        if ($uur >= 0 && $uur < 6 || $uur >= 18 && $uur <= 24){
            echo "goedenacht beste {$naam} <br>";
        }
        elseif ($uur >= 6 && $uur < 12){
            echo "goedemorgen beste {$naam} <br>";
        }
        elseif ($uur >= 12 && $uur < 18){
            echo "goedemiddag beste {$naam} <br>";
        }
        
        echo "Het is vandaag: {$dag}-{$maand}-{$jaar} --- {$dagvdweek} <br> \n";
        echo "en het is nu {$uur}:{$minuut}:{$seconden} <br> \n";
        
        if (date('I') == 1){
            echo "het is nu zomertijd <br>";
        } 
        else {
            echo "het is nu wintertijd <br>";
        }
    ?>
<br>
<br>
<div style='background:blue; width:1000px; height:1000px'>
    <br>
    <p style='color:#FFFFFF'> &nbsp; here I will show you my coding skills</p>
    <p style='color:#FFFFFF'> &nbsp; we will start with some numbers</p>

    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <!-- voor getal 1-->
        <p style='color:#FFFFFF'> &nbsp; geef getal1:</p> 
        <input type="text" name="getal1" value="<?php echo isset($_POST['getal1']) ? (int)$_POST['getal1'] : 0; ?>"><br>
        <!-- voor getal 2-->
        <p style='color:#FFFFFF'> &nbsp; geef getal2:</p>
        <input type="text" name="getal2" value="<?php echo isset($_POST['getal2']) ? (int)$_POST['getal2'] : 0; ?>"><br>
        <!-- voor button +1 -->
        <input type="hidden" name="current_t3" value="<?php echo isset($_POST['current_t3']) ? (int)$_POST['current_t3'] : 0; ?>">

        <!-- basic optellen van start getallen -->
        <input type="submit" name="action" value="Optellen" >
        <!-- resultaat + 1 -->
        <input type="submit" name="action" value="+1">
        <!-- resultaat x 2 -->
        <input type="submit" name="action" value="x2">
        <!-- resultaat ^ 2 -->
        <input type="submit" name="action" value="^2">
    </form>

    <?php
    // Check if the form has been submitted and "action" is set
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"])) {
        // Retrieve getal1 and getal2 from the form
        $t1 = isset($_POST["getal1"]) ? (int)$_POST["getal1"] : 0;
        $t2 = isset($_POST["getal2"]) ? (int)$_POST["getal2"] : 0;

        // Retrieve the current value of t3 from the hidden field
        $t3 = isset($_POST["current_t3"]) ? (int)$_POST["current_t3"] : $t1 + $t2;

        // Check which button was pressed
        if ($_POST["action"] == "Optellen") {
            $t3 = $t1 + $t2;
            echo "<p style='color:#FFFFFF;'>$t1 + $t2 = $t3</p>";
        } elseif ($_POST["action"] == "+1") {
            $t10 = $t1 + $t2;
            $t3 += 1;
            $t4 = $t3 - 1;
            echo "<p style='color:#FFFFFF;'>$t1 + $t2 = $t10</p>";
            echo "<p style='color:#FFFFFF;'> $t4 + 1 = $t3 </p>";
        } elseif ($_POST["action"] == "x2") {
            $t10 = $t1 + $t2;
            $t3 *= 2;
            $t4 = $t3 / 2;
            echo "<p style='color:#FFFFFF;'>$t1 + $t2 = $t10</p>";
            echo "<p style='color:#FFFFFF;'> $t4 x 2 = $t3 </p>";
        } elseif ($_POST["action"] == "^2") {
            $t10 = $t1 + $t2;
            $t3 = pow($t3, 2);
            $t4 = sqrt($t3);
            echo "<p style='color:#FFFFFF;'>$t1 + $t2 = $t10</p>";
            echo "<p style='color:#FFFFFF;'> $t4 ^ 2 = $t3 </p>";
        }
        
        // Update the hidden field to retain the new value of t3
        echo "<script>document.getElementsByName('current_t3')[0].value = $t3;</script>";
    }
    ?>

    <?php
        echo "<p style='color:#FFFFFF'> &nbsp; now we will go to some colors </p>";
    ?>

    <form method="POST" action="simple2.php">
        kleur: <input type="input" name="kleur"><br>
        lengte: <input type="input" name="lengte"><br>
        dikte: <input type="input" name="dikte"><br>
        <input type="submit" value="laat de vorm in kleur zien">
    </form>

    <?php
        echo "<p style='color:#FFFFFF'> &nbsp; now my own creation </p>";
    ?>

    <form method="POST" action="simple_is_it_tho.php">
        side1: <input type="input" name="side1"><br>
        side2: <input type="input" name="side2"><br>
        <input type="submit" value="make game">
    </form>
    <br>
    <br>

    <?php
        echo "<a style='color:#FFFFFF' href='http://localhost/log_out.php'> log out </a><br>";
    ?>
</div>



</body>
</html>
