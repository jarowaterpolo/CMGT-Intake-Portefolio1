<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <titel>start web for my end project</titel>
</head>

<body>
<br>
<br>
 <?php
 session_start();
        if(!isset($_SESSION["naam"])){
    ?>
            <form method="POST" action="simple.php">
            <!-- voor naam-->
            geef hier je naam:<input type="text" name="naam" ><br>
            </form>
    <?php
        }
        else{
            header("Location: simple.php");
        }
    ?>
    
<br>
</body>
</html>