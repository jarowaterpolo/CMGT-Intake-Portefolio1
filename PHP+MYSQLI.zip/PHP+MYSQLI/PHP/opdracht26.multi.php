<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>multi php

    </titel>
</head>

<body>
<br>
<br>

<form method="POST" action="<?php $_SERVER["PHP_SELF"]; ?>">
    getal1: <input type="input" name="getal1" ><br>
    getal2: <input type="input" name="getal2" ><br>
    <input type="submit" value="optellen" >
</form>
    <?php 
    //"opdracht26.multi.php"(voor action)
        if(empty($_POST)){
            echo "Vul beide getallen in. <br>\n";
        }
        else{
            $totaal = $_POST["getal1"] + $_POST["getal2"];
            echo $_POST["getal1"]."+".$_POST["getal2"]."=".$totaal."<br>\n";
        }
        echo " <br>\n";
        foreach($_SERVER as $sleutel => $waarde){
            echo $sleutel."=>".$waarde."<br>\n";
        }
    ?>

</body>
</html>