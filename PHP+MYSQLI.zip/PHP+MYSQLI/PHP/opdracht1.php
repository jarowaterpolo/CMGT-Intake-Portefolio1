<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Test php</titel>
</head>

<body>

    <?php 
       phpinfo();
    ?>

</body>
</html>