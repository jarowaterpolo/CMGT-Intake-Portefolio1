<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>seizoen tijden

    </titel>
</head>

<body>
<br>
<br>
    <?php 
        date_default_timezone_set('Europe/Amsterdam');

        if (date('I') == 1){
                echo "het is zomertijd ";
        } else {
            echo "het is wintertijd ";
        }

    ?>

</body>
</html>