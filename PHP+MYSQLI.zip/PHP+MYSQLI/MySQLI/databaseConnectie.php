<?php
    $server="localhost";
    $database="jaro";
    $username="Jaro";
    $wachtwoord="JJN13!";

    //connectie met database via php
    $connectie= mysqli_connect($server,$username,$wachtwoord,$database);
    if (!$connectie= mysqli_connect($server,$username,$wachtwoord,$database))
    {
        $boodschap="Verbinding mislukt omdat: ".mysqli_connect_error($connectie).
        " Met als foutnummer: ".mysqli_connect_errno($connectie);
    } else {
        $boodschap="Verbinding is gelukt !";
    }

?>