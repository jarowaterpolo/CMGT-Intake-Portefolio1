<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lijst met alle Leerlingen</title>
    <?php
        include("databaseConnectie.php");
    ?>

    <?php
    //de sqli query
    $query="SELECT * FROM leerlingen";
    
    //voer de query uit op de database en sla op in $resultaat
    if (!$resultaat=mysqli_query($connectie, $query))
    {
        $boodschap.=" query \"$query\" is mislukt! ";
    } else {
        $boodschap.=" query is gelukt! ";
    }
    ?>
</head>
<body>
    <?php
        echo $boodschap;
    ?>
</body>
</html>