<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <titel>Welcome!

    </titel>
</head>

<body>
<br>
<br>
<div style='background:blue; width:1000px; height:1000px'>
    <br>
    <p style='color:#FFFFFF'> &nbsp; here i will show you my coding skills</p>
    <p style='color:#FFFFFF'> &nbsp; we will start with some numbers</p>

    <form method="POST" action="<?php $_SERVER["PHP_SELF"]; ?>">
    <p style='color:#FFFFFF'> &nbsp; geef getal1:</p> <input type="input" name="getal1" ><br>
    <p style='color:#FFFFFF'> &nbsp; geef getal2:</p> <input type="input" name="getal2" ><br>
    <input type="submit" value="optellen" >
    </form>

   <?php
    $t1 = $_POST["getal1"];
    $t2 = $_POST["getal2"];
    $t3 = $t2 + $t1;
    echo $t1."+".$t2."=".$t3;
    ?>
</div>

</body>
</html>