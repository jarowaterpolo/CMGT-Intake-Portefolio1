<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Creation</title>
    <style>
        button {
            width: 50px;
            height: 50px;
            font-size: 20px;
        }
        .game-over {
            background-color: red;
            color: white;
        }
        .right-clicked {
            background-color: red;
            color: white;
        }
        /* Add style for the counter display */
        #counter {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 24px;
            background-color: #f0f0f0;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php
    echo " <br>";
    echo "welcome here some instuctions";
    echo "<p style='color:#20ff00;'>left click to reveal a number</p>";
    echo "<p style='color:#ff0000;'>right click to turn red</p>";
    echo "the revealed number wil show the amount of game-over tiles around it";
    // Start a session to store the map grid
    session_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get the form values
        $side1 = isset($_POST['side1']) ? (int)$_POST['side1'] : 0;
        $side2 = isset($_POST['side2']) ? (int)$_POST['side2'] : 0;

        // Generate the map grid if valid input is provided
        if ($side1 > 0 && $side2 > 0) {
            // Initialize map with 0 (empty)
            $map = array();
            $twosCount = 0; // Initialize the counter for the number of '2's

            for ($i = 0; $i < $side2; $i++) {
                for ($j = 0; $j < $side1; $j++) {
                    $map[$i][$j] = 0; // Initially all cells are '0' (empty)

                    // Randomly place some '2's (special cells) in the grid
                    if (rand(0, 10) < 3) { // Randomly set some cells as '2'
                        $map[$i][$j] = 2;
                        $twosCount++; // Increment the count of '2's
                    }
                }
            }

            // Save the grid and the count of '2's into session for persistence
            $_SESSION['map'] = $map;
            $_SESSION['side1'] = $side1;
            $_SESSION['side2'] = $side2;
            $_SESSION['twosCount'] = $twosCount; // Store the initial '2' count
        }
    }

    // Retrieve the map and the count of '2's from the session
    $map = isset($_SESSION['map']) ? $_SESSION['map'] : [];
    $side1 = isset($_SESSION['side1']) ? $_SESSION['side1'] : 0;
    $side2 = isset($_SESSION['side2']) ? $_SESSION['side2'] : 0;
    $twosCount = isset($_SESSION['twosCount']) ? $_SESSION['twosCount'] : 0;
    ?>

    <script>
        var clickedCells = {}; // Object to store the state of each cell
        var redCells = {}; // Object to store the red-flagged (right-clicked) cells
        var totalTwosNotRed = <?php echo $twosCount; ?>; // Counter for the number of '2' cells that are not red yet

        // JavaScript function to handle click events and show the number of surrounding '2's
        function showNumber(i, j) {
            // Get the map from PHP session
            var map = <?php echo json_encode($map); ?>;
            var side1 = <?php echo json_encode($side1); ?>;
            var side2 = <?php echo json_encode($side2); ?>;

            // If the clicked cell contains a '2', display "Game Over"
            if (map[i][j] === 2) {
                alert("Game Over! You clicked on a 2.");
                resetGrid();
                return;
            }

            // Count the number of '2's around the clicked cell
            var count = 0;
            for (var x = -1; x <= 1; x++) {
                for (var y = -1; y <= 1; y++) {
                    var ni = i + x;
                    var nj = j + y;

                    // Check if the new position is within bounds
                    if (ni >= 0 && ni < side2 && nj >= 0 && nj < side1) {
                        if (map[ni][nj] === 2) {
                            count++; // Increment count if a '2' is found
                        }
                    }
                }
            }

            // Update the clicked cell with the count of surrounding '2's
            document.getElementById("cell-" + i + "-" + j).innerHTML = count;
            clickedCells[i + "-" + j] = true; // Mark the cell as clicked
            checkVictory(); // Check for victory after each click
        }

        // Handle right-click functionality with toggle
        function rightClick(i, j, event) {
            event.preventDefault(); // Prevent the default right-click menu from showing

            // Get the button element
            var button = document.getElementById("cell-" + i + "-" + j);
            var map = <?php echo json_encode($map); ?>;

            // Toggle the button color and functionality on right-click
            if (button.classList.contains("right-clicked")) {
                // If it's red, turn it back to original
                button.classList.remove("right-clicked");
                button.style.backgroundColor = "";  // Reset background color
                button.style.color = "";  // Reset text color
                redCells[i + "-" + j] = false; // Mark as not red

                // If it was a '2', increase the counter
                if (map[i][j] === 2) {
                    totalTwosNotRed++;
                }
            } else {
                // If it's not red, turn it red
                button.classList.add("right-clicked");
                button.style.backgroundColor = "red";  // Set background color to red
                button.style.color = "white";  // Set text color to white
                redCells[i + "-" + j] = true; // Mark as red

                // If it was a '2', decrease the counter
                if (map[i][j] === 2) {
                    totalTwosNotRed--;
                }
            }

            // Update the counter display
            updateCounter();

            checkVictory(); // Check for victory after right-click
        }

        // Function to update the counter display
        function updateCounter() {
            var counterElement = document.getElementById("counter");
            counterElement.innerHTML = "Twos not red: " + totalTwosNotRed;
        }

        // Function to check if all '0' cells are clicked and all '2' cells are red
        function checkVictory() {
            var totalCells = <?php echo $side1 * $side2; ?>;
            var clickedOrRedCells = 0;
            var allZeroCellsClicked = true;
            var allTwoCellsRed = true;

            // Iterate over all cells to check the victory conditions
            for (var i = 0; i < <?php echo $side2; ?>; i++) {
                for (var j = 0; j < <?php echo $side1; ?>; j++) {
                    var cellId = i + "-" + j;
                    var cellValue = <?php echo json_encode($map); ?>[i][j];
                    
                    if (cellValue === 0) {
                        // Check if all '0' cells are clicked
                        if (!clickedCells[cellId]) {
                            allZeroCellsClicked = false;
                        }
                    } else if (cellValue === 2) {
                        // Check if all '2' cells are red
                        if (!redCells[cellId]) {
                            allTwoCellsRed = false;
                        }
                    }
                    
                    // Count cells that are either clicked or red
                    if (clickedCells[cellId] || redCells[cellId]) {
                        clickedOrRedCells++;
                    }
                }
            }

            // Check if victory conditions are met
            if (clickedOrRedCells === totalCells && allZeroCellsClicked && allTwoCellsRed) {
                alert("Victory! All '0' cells are clicked and all '2' cells are red.");
                resetGrid(); // Reset grid after victory
            } else if (clickedOrRedCells === totalCells) {
                alert("Wrong! Not all '0' cells are clicked or '2' cells are red.");
                resetGrid(); // Reset grid after wrong
            }
        }

        // Function to reset the grid
        function resetGrid() {
            // Clear the clicked and red states
            clickedCells = {};
            redCells = {};
            totalTwosNotRed = <?php echo $twosCount; ?>; // Reset to initial count of '2' cells

            // Get all button elements and reset their appearance
            var buttons = document.querySelectorAll("button");
            buttons.forEach(function(button) {
                button.innerHTML = "&nbsp;";  // Set back to blank
                button.classList.remove("right-clicked");  // Remove red
                button.style.backgroundColor = "";  // Reset background color
                button.style.color = "";  // Reset text color
            });

            // Reset the counter display
            updateCounter();
        }

        // Initialize counter display
        window.onload = function() {
            updateCounter();
        };
    </script>

    <!-- Display the counter for '2' cells not red -->
    <div id="counter">Twos not red: <?php echo $twosCount; ?></div>

    <?php if ($side1 > 0 && $side2 > 0) { ?>
        <div style="display: grid; grid-template-columns: repeat(<?php echo $side1; ?>, 50px); grid-gap: 5px;">
            <?php
            // Loop through each row and column to create the grid of clickable buttons
            for ($i = 0; $i < $side2; $i++) {
                for ($j = 0; $j < $side1; $j++) {
                    // Generate the button for each cell in the grid
                    echo "<button id='cell-$i-$j' onclick='showNumber($i, $j)' oncontextmenu='rightClick($i, $j, event)'>";
                    echo "&nbsp;"; // Initially empty (its a space)
                    echo "</button>";
                }
            }
            ?>
        </div>
    <?php } ?>
    <?php 
    echo "are you done? <br>";
    echo "here a way to go back <br>";
    ?>

<?php
// Set the link URL and text
$link = "http://localhost/start.php";
$link_text = "Click here to go back to my start page you will have to enter youre name";
?>
<br>

<!-- The clickable link in HTML -->
<a href="<?php echo $link; ?>" target="_blank"><?php echo $link_text; ?></a>

</body>
</html>
